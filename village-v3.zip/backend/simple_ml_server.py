#!/usr/bin/env python3
"""
Simple ML Prediction Server - No external dependencies except what's already installed
Integrates with actual CSV data and provides mock predictions based on real data patterns
"""

import os
import sys
import json
import csv
import math
from datetime import datetime, timedelta
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
import urllib.parse

class MLPredictionHandler(BaseHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        self.village_data = {}
        self.water_quality_data = []
        super().__init__(*args, **kwargs)

    def do_OPTIONS(self):
        """Handle CORS preflight requests"""
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.end_headers()

    def do_GET(self):
        """Handle GET requests"""
        parsed_url = urlparse(self.path)

        if parsed_url.path == '/api/villages':
            self.handle_villages()
        elif parsed_url.path == '/api/health':
            self.handle_health()
        else:
            self.send_error(404, "Endpoint not found")

    def do_POST(self):
        """Handle POST requests"""
        parsed_url = urlparse(self.path)

        if parsed_url.path == '/api/predict':
            self.handle_prediction()
        else:
            self.send_error(404, "Endpoint not found")

    def load_village_data(self):
        """Load village CSV data"""
        data_dir = os.path.join(os.path.dirname(__file__), '..', 'data')
        village_files = ['village_a.csv', 'village_b.csv', 'village_c.csv', 'village_d.csv',
                        'village_e.csv', 'village_f.csv', 'village_g.csv', 'village_h.csv',
                        'village_i.csv', 'village_j.csv', 'village_k.csv']

        for village_file in village_files:
            file_path = os.path.join(data_dir, village_file)
            if os.path.exists(file_path):
                try:
                    with open(file_path, 'r') as f:
                        reader = csv.DictReader(f)
                        rows = list(reader)

                        # Group by area column
                        for row in rows:
                            area = row.get('area', 'Unknown')
                            village_key = f"{village_file.replace('.csv', '')}_{area}"

                            if village_key not in self.village_data:
                                self.village_data[village_key] = []

                            # Convert numeric fields
                            for key, value in row.items():
                                if key not in ['date', 'area']:
                                    try:
                                        row[key] = float(value) if value else 0
                                    except ValueError:
                                        row[key] = 0

                            self.village_data[village_key].append(row)

                    print(f"✅ Loaded {village_file} - {len(rows)} records")
                except Exception as e:
                    print(f"❌ Error loading {village_file}: {e}")

        # Load water quality data
        water_file = os.path.join(data_dir, 'synthetic_water_quality_data.csv')
        if os.path.exists(water_file):
            try:
                with open(water_file, 'r') as f:
                    reader = csv.DictReader(f)
                    self.water_quality_data = list(reader)
                print(f"✅ Loaded water quality data - {len(self.water_quality_data)} records")
            except Exception as e:
                print(f"❌ Error loading water quality data: {e}")

    def find_data_for_date(self, village_key, target_date):
        """Find data for specific date and village"""
        if village_key not in self.village_data:
            return None

        village_records = self.village_data[village_key]

        # Try exact date match first
        for record in village_records:
            if record['date'] == target_date:
                return record

        # Find closest date
        target_dt = datetime.strptime(target_date, '%Y-%m-%d')
        closest_record = None
        min_diff = float('inf')

        for record in village_records:
            try:
                record_dt = datetime.strptime(record['date'], '%Y-%m-%d')
                diff = abs((target_dt - record_dt).days)
                if diff < min_diff:
                    min_diff = diff
                    closest_record = record
            except ValueError:
                continue

        return closest_record

    def calculate_risk_score(self, data):
        """Calculate outbreak risk based on data patterns from CSV"""
        if not data:
            return 0.1

        # Extract key risk factors from the CSV columns
        contamination = float(data.get('contamination_avg', 0))
        water_ph = float(data.get('water_ph_avg', 7.0))
        water_turbidity = float(data.get('water_turbidity_avg', 0))
        true_cases = float(data.get('true_cases', 0))
        temperature = float(data.get('temperature', 20))
        rainfall = float(data.get('rainfall_1d', 0))
        exposure_score = float(data.get('exposure_score', 0))
        syndromic_score = float(data.get('syndromic_score', 0))

        # Risk calculation based on multiple factors
        risk_score = 0

        # Contamination risk (0-1)
        risk_score += min(0.3, contamination * 0.1)

        # Water quality risk
        ph_deviation = abs(water_ph - 7.0)
        if ph_deviation > 1.0:
            risk_score += 0.15

        # Turbidity risk
        risk_score += min(0.15, water_turbidity * 0.05)

        # Cases trend risk
        risk_score += min(0.25, true_cases * 0.01)

        # Environmental factors
        if temperature > 30:
            risk_score += 0.1
        if rainfall > 10:
            risk_score += 0.08

        # Exposure and syndromic scores
        risk_score += min(0.15, exposure_score * 0.03)
        risk_score += min(0.12, syndromic_score * 0.02)

        # Apply sigmoid to get probability between 0 and 1
        probability = 1 / (1 + math.exp(-8 * (risk_score - 0.3)))

        return min(0.99, max(0.01, probability))

    def get_top_factors(self, data, risk_probability):
        """Identify top contributing risk factors"""
        factors = []

        contamination = float(data.get('contamination_avg', 0))
        water_ph = float(data.get('water_ph_avg', 7.0))
        water_turbidity = float(data.get('water_turbidity_avg', 0))
        true_cases = float(data.get('true_cases', 0))
        temperature = float(data.get('temperature', 20))
        exposure_score = float(data.get('exposure_score', 0))

        if contamination > 1.0:
            factors.append({
                'factor': 'Water Contamination',
                'importance': contamination * 0.1,
                'percentage': f"{min(100, contamination * 10):.1f}"
            })

        if abs(water_ph - 7.0) > 0.5:
            factors.append({
                'factor': 'Water pH Imbalance',
                'importance': abs(water_ph - 7.0) * 0.2,
                'percentage': f"{min(100, abs(water_ph - 7.0) * 20):.1f}"
            })

        if water_turbidity > 2.0:
            factors.append({
                'factor': 'High Water Turbidity',
                'importance': water_turbidity * 0.05,
                'percentage': f"{min(100, water_turbidity * 5):.1f}"
            })

        if true_cases > 10:
            factors.append({
                'factor': 'Existing Disease Cases',
                'importance': true_cases * 0.01,
                'percentage': f"{min(100, true_cases):.1f}"
            })

        if temperature > 28:
            factors.append({
                'factor': 'High Temperature',
                'importance': (temperature - 25) * 0.02,
                'percentage': f"{min(100, (temperature - 25) * 2):.1f}"
            })

        if exposure_score > 2.0:
            factors.append({
                'factor': 'Population Exposure',
                'importance': exposure_score * 0.03,
                'percentage': f"{min(100, exposure_score * 3):.1f}"
            })

        # Sort by importance and return top 5
        factors.sort(key=lambda x: x['importance'], reverse=True)
        return factors[:5]

    def handle_villages(self):
        """Handle /api/villages endpoint"""
        self.load_village_data()

        villages = []
        for village_key in self.village_data.keys():
            parts = village_key.split('_')
            if len(parts) >= 2:
                village_name = parts[0] + '_' + parts[1]
                area = parts[2] if len(parts) > 2 else 'Unknown'

                villages.append({
                    'key': village_key,
                    'area': area,
                    'display_name': f"Village {area}",
                    'records': len(self.village_data[village_key])
                })

        response = {
            'success': True,
            'villages': villages
        }

        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        self.wfile.write(json.dumps(response).encode())

    def handle_health(self):
        """Handle /api/health endpoint"""
        self.load_village_data()

        response = {
            'status': 'healthy',
            'models_loaded': ['lgbm_simulation'],
            'villages_loaded': len(self.village_data),
            'water_quality_records': len(self.water_quality_data)
        }

        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        self.wfile.write(json.dumps(response).encode())

    def handle_prediction(self):
        """Handle /api/predict endpoint"""
        try:
            content_length = int(self.headers['Content-Length'])
            post_data = self.rfile.read(content_length)
            data = json.loads(post_data.decode('utf-8'))

            target_date = data.get('date')
            village_key = data.get('village')

            if not target_date or not village_key:
                self.send_error(400, "Date and village are required")
                return

            self.load_village_data()

            # Find data for the specified date and village
            village_data = self.find_data_for_date(village_key, target_date)

            if not village_data:
                self.send_error(404, f"No data found for {village_key} on {target_date}")
                return

            # Calculate outbreak probability
            outbreak_probability = self.calculate_risk_score(village_data)

            # Determine risk level
            if outbreak_probability >= 0.7:
                risk_level = 'critical'
            elif outbreak_probability >= 0.5:
                risk_level = 'high'
            elif outbreak_probability >= 0.3:
                risk_level = 'medium'
            else:
                risk_level = 'low'

            # Get top contributing factors
            top_factors = self.get_top_factors(village_data, outbreak_probability)

            response = {
                'success': True,
                'prediction': {
                    'date': target_date,
                    'village': village_key,
                    'outbreak_probability': outbreak_probability,
                    'risk_level': risk_level,
                    'top_contributing_factors': top_factors,
                    'confidence_score': 0.82,
                    'model_used': 'lgbm_water_quality_model.pkl (simulated)',
                    'base_data': {
                        'temperature': float(village_data.get('temperature', 0)),
                        'rainfall_1d': float(village_data.get('rainfall_1d', 0)),
                        'contamination_avg': float(village_data.get('contamination_avg', 0)),
                        'water_ph_avg': float(village_data.get('water_ph_avg', 0)),
                        'water_turbidity_avg': float(village_data.get('water_turbidity_avg', 0)),
                        'true_cases': int(village_data.get('true_cases', 0)),
                        'reported_cases': int(village_data.get('reported_cases', 0))
                    }
                }
            }

            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            self.wfile.write(json.dumps(response).encode())

        except Exception as e:
            print(f"❌ Error in prediction: {e}")
            self.send_error(500, f"Internal server error: {str(e)}")

def run_server():
    """Run the ML prediction server"""
    server_address = ('', 5000)
    httpd = HTTPServer(server_address, MLPredictionHandler)

    print("🚀 Starting Simple ML Prediction Server...")
    print("📊 Using actual CSV data from data/ directory")
    print("🧠 Simulating LightGBM model predictions based on real data patterns")
    print("🌐 Server running on http://localhost:5000")
    print("📡 CORS enabled for frontend integration")
    print("\nEndpoints:")
    print("  GET  /api/health   - Server health check")
    print("  GET  /api/villages - List available villages")
    print("  POST /api/predict  - Run outbreak prediction")
    print("\nPress Ctrl+C to stop the server")

    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n🛑 Server stopped by user")
        httpd.server_close()

if __name__ == '__main__':
    run_server()