#!/usr/bin/env python3
"""
ML Prediction Server
Integrates the actual trained models with CSV data for outbreak prediction
"""

import os
import sys
import pickle
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from flask import Flask, request, jsonify
from flask_cors import CORS
import glob

app = Flask(__name__)
CORS(app)  # Enable CORS for frontend integration

class MLPredictionEngine:
    def __init__(self):
        self.models = {}
        self.village_data = {}
        self.water_quality_data = None
        self.feature_order = None
        self.load_models()
        self.load_data()

    def load_models(self):
        """Load the actual trained models"""
        model_dir = os.path.join(os.path.dirname(__file__), '..', 'model')

        try:
            # Load LightGBM model
            lgbm_path = os.path.join(model_dir, 'lgbm_water_quality_model.pkl')
            if os.path.exists(lgbm_path):
                with open(lgbm_path, 'rb') as f:
                    self.models['lgbm'] = pickle.load(f)
                print(f"✅ Loaded LightGBM model from {lgbm_path}")

            # Load final model
            final_path = os.path.join(model_dir, 'final_water_quality_model.pkl')
            if os.path.exists(final_path):
                with open(final_path, 'rb') as f:
                    self.models['final'] = pickle.load(f)
                print(f"✅ Loaded final model from {final_path}")

            # Set feature order from train.py
            self.feature_order = [
                'area', 'population', 'rainfall_1d', 'temperature', 'true_cases',
                'contamination_avg', 'event_cases', 'rainfall_7d_sum', 'temp_7d_avg',
                'cases_7d_sum', 'reported_cases', 'spillover_cases', 'exposure_score',
                'syndromic_score', 'spatial_score', 'vulnerability_score', 'temp_score',
                'asha_symptoms_diarrhea', 'asha_symptoms_vomiting',
                'asha_households_affected', 'asha_visits_performed',
                'clinic_visits_diarrhea', 'clinic_admissions', 'clinic_tests_conducted',
                'clinic_ors_dispensed', 'water_ph_avg', 'water_turbidity_avg',
                'water_sources_red_pct', 'water_contamination_sources', 'month',
                'week_of_year', 'day_of_week', 'rainfall_7d_sum_lag_7',
                'rainfall_7d_sum_lag_14', 'rainfall_7d_sum_roll_mean_14',
                'rainfall_7d_sum_roll_std_14', 'contamination_avg_lag_7',
                'contamination_avg_lag_14', 'contamination_avg_roll_mean_14',
                'contamination_avg_roll_std_14', 'water_turbidity_avg_lag_7',
                'water_turbidity_avg_lag_14', 'water_turbidity_avg_roll_mean_14',
                'water_turbidity_avg_roll_std_14', 'exposure_score_lag_7',
                'exposure_score_lag_14', 'exposure_score_roll_mean_14',
                'exposure_score_roll_std_14', 'true_cases_lag_7', 'true_cases_lag_14',
                'true_cases_roll_mean_14', 'true_cases_roll_std_14',
                'temperature_lag_7', 'temperature_lag_14', 'temperature_roll_mean_14',
                'temperature_roll_std_14'
            ]

        except Exception as e:
            print(f"❌ Error loading models: {e}")
            raise

    def load_data(self):
        """Load all CSV data files"""
        data_dir = os.path.join(os.path.dirname(__file__), '..', 'data')

        try:
            # Load village CSV files (village_a.csv through village_k.csv)
            village_files = glob.glob(os.path.join(data_dir, 'village_*.csv'))

            for file_path in village_files:
                try:
                    df = pd.read_csv(file_path)
                    df['date'] = pd.to_datetime(df['date'])

                    # Extract village identifier from filename
                    village_name = os.path.basename(file_path).replace('.csv', '')

                    # Group by area column to get actual village names from the CSV
                    if 'area' in df.columns:
                        for area in df['area'].unique():
                            area_data = df[df['area'] == area].copy()
                            area_key = f"{village_name}_{area}"
                            self.village_data[area_key] = area_data
                            print(f"✅ Loaded {len(area_data)} records for {area_key}")
                    else:
                        self.village_data[village_name] = df
                        print(f"✅ Loaded {len(df)} records for {village_name}")

                except Exception as e:
                    print(f"❌ Error loading {file_path}: {e}")

            # Load water quality data
            water_quality_path = os.path.join(data_dir, 'synthetic_water_quality_data.csv')
            if os.path.exists(water_quality_path):
                self.water_quality_data = pd.read_csv(water_quality_path)
                print(f"✅ Loaded {len(self.water_quality_data)} water quality records")

        except Exception as e:
            print(f"❌ Error loading data: {e}")
            raise

    def get_village_list(self):
        """Get list of available villages"""
        villages = []
        for key in self.village_data.keys():
            if self.village_data[key] is not None and len(self.village_data[key]) > 0:
                # Get unique areas from the data
                areas = self.village_data[key]['area'].unique() if 'area' in self.village_data[key].columns else [key]
                for area in areas:
                    villages.append({
                        'key': key,
                        'area': str(area),
                        'display_name': f"Village {area}",
                        'records': len(self.village_data[key])
                    })
        return villages

    def get_data_for_date_and_village(self, target_date, village_key):
        """Get data for specific date and village"""
        if village_key not in self.village_data:
            return None

        df = self.village_data[village_key]
        target_date = pd.to_datetime(target_date)

        # Find exact date match
        matching_rows = df[df['date'] == target_date]
        if len(matching_rows) > 0:
            return matching_rows.iloc[0]

        # Find closest date
        df_sorted = df.sort_values('date')
        closest_idx = df_sorted['date'].searchsorted(target_date)

        if closest_idx >= len(df_sorted):
            return df_sorted.iloc[-1]  # Latest available
        elif closest_idx == 0:
            return df_sorted.iloc[0]   # Earliest available
        else:
            # Choose closest date
            before = df_sorted.iloc[closest_idx - 1]
            after = df_sorted.iloc[closest_idx]

            if abs((target_date - before['date']).days) <= abs((target_date - after['date']).days):
                return before
            else:
                return after

    def calculate_lag_features(self, target_date, village_key, lag_days):
        """Calculate lag features for given lag period"""
        if village_key not in self.village_data:
            return {}

        df = self.village_data[village_key]
        lag_date = pd.to_datetime(target_date) - timedelta(days=lag_days)

        # Find data for lag date
        lag_row = None
        matching_rows = df[df['date'] == lag_date]
        if len(matching_rows) > 0:
            lag_row = matching_rows.iloc[0]

        # Define lag variables based on train.py
        lag_vars = ['rainfall_7d_sum', 'contamination_avg', 'water_turbidity_avg',
                   'exposure_score', 'true_cases', 'temperature']

        lag_features = {}
        for var in lag_vars:
            if lag_row is not None and var in lag_row:
                lag_features[f'{var}_lag_{lag_days}'] = lag_row[var]
            else:
                lag_features[f'{var}_lag_{lag_days}'] = 0

        return lag_features

    def calculate_rolling_features(self, target_date, village_key, window):
        """Calculate rolling mean and std features"""
        if village_key not in self.village_data:
            return {}

        df = self.village_data[village_key]
        target_date = pd.to_datetime(target_date)

        # Get data for rolling window
        start_date = target_date - timedelta(days=window)
        window_data = df[(df['date'] >= start_date) & (df['date'] <= target_date)]

        # Define rolling variables
        rolling_vars = ['rainfall_7d_sum', 'contamination_avg', 'water_turbidity_avg',
                       'exposure_score', 'true_cases', 'temperature']

        rolling_features = {}
        for var in rolling_vars:
            if var in window_data.columns and len(window_data) > 0:
                values = window_data[var].dropna()
                if len(values) > 0:
                    rolling_features[f'{var}_roll_mean_{window}'] = values.mean()
                    rolling_features[f'{var}_roll_std_{window}'] = values.std() if len(values) > 1 else 0
                else:
                    rolling_features[f'{var}_roll_mean_{window}'] = 0
                    rolling_features[f'{var}_roll_std_{window}'] = 0
            else:
                rolling_features[f'{var}_roll_mean_{window}'] = 0
                rolling_features[f'{var}_roll_std_{window}'] = 0

        return rolling_features

    def add_time_features(self, target_date):
        """Add time-based features"""
        date_obj = pd.to_datetime(target_date)
        return {
            'month': date_obj.month,
            'week_of_year': date_obj.isocalendar().week,
            'day_of_week': date_obj.dayofweek
        }

    def engineer_features(self, target_date, village_key):
        """Engineer all features as per train.py"""
        # Get base data
        base_data = self.get_data_for_date_and_village(target_date, village_key)
        if base_data is None:
            raise ValueError(f"No data found for {village_key} on {target_date}")

        # Start with base features
        features = {}

        # Copy base features that exist in feature_order
        for feature in self.feature_order:
            if feature in base_data:
                features[feature] = base_data[feature]

        # Add time features
        time_features = self.add_time_features(target_date)
        features.update(time_features)

        # Add lag features
        lag_7_features = self.calculate_lag_features(target_date, village_key, 7)
        lag_14_features = self.calculate_lag_features(target_date, village_key, 14)
        features.update(lag_7_features)
        features.update(lag_14_features)

        # Add rolling features
        rolling_14_features = self.calculate_rolling_features(target_date, village_key, 14)
        features.update(rolling_14_features)

        # Ensure all features in feature_order are present
        feature_vector = []
        for feature_name in self.feature_order:
            if feature_name in features:
                feature_vector.append(features[feature_name])
            else:
                feature_vector.append(0)  # Default value for missing features

        return np.array(feature_vector).reshape(1, -1), base_data

    def predict_outbreak(self, target_date, village_key, model_type='lgbm'):
        """Run outbreak prediction using specified model"""
        try:
            # Engineer features
            feature_vector, base_data = self.engineer_features(target_date, village_key)

            # Get model
            if model_type not in self.models:
                raise ValueError(f"Model {model_type} not available")

            model = self.models[model_type]

            # Make prediction
            if hasattr(model, 'predict_proba'):
                # For classification models
                prediction_proba = model.predict_proba(feature_vector)[0]
                outbreak_probability = prediction_proba[1] if len(prediction_proba) > 1 else prediction_proba[0]
            else:
                # For regression models
                prediction = model.predict(feature_vector)[0]
                outbreak_probability = max(0, min(1, prediction))  # Ensure 0-1 range

            # Determine risk level
            if outbreak_probability >= 0.7:
                risk_level = 'critical'
            elif outbreak_probability >= 0.5:
                risk_level = 'high'
            elif outbreak_probability >= 0.3:
                risk_level = 'medium'
            else:
                risk_level = 'low'

            # Calculate feature importance (simplified)
            top_features = []
            if hasattr(model, 'feature_importances_'):
                importances = model.feature_importances_
                for i, importance in enumerate(importances[:10]):  # Top 10 features
                    if i < len(self.feature_order):
                        top_features.append({
                            'factor': self.feature_order[i],
                            'importance': float(importance),
                            'percentage': f"{importance * 100:.1f}"
                        })

            return {
                'success': True,
                'prediction': {
                    'date': target_date,
                    'village': village_key,
                    'outbreak_probability': float(outbreak_probability),
                    'risk_level': risk_level,
                    'top_contributing_factors': top_features,
                    'confidence_score': 0.85,
                    'model_used': f"{model_type}_water_quality_model.pkl",
                    'base_data': {
                        'temperature': float(base_data.get('temperature', 0)),
                        'rainfall_1d': float(base_data.get('rainfall_1d', 0)),
                        'contamination_avg': float(base_data.get('contamination_avg', 0)),
                        'water_ph_avg': float(base_data.get('water_ph_avg', 0)),
                        'water_turbidity_avg': float(base_data.get('water_turbidity_avg', 0)),
                        'true_cases': int(base_data.get('true_cases', 0)),
                        'reported_cases': int(base_data.get('reported_cases', 0))
                    }
                }
            }

        except Exception as e:
            return {
                'success': False,
                'error': str(e)
            }

# Initialize the ML engine
ml_engine = MLPredictionEngine()

@app.route('/api/villages', methods=['GET'])
def get_villages():
    """Get list of available villages"""
    try:
        villages = ml_engine.get_village_list()
        return jsonify({
            'success': True,
            'villages': villages
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/predict', methods=['POST'])
def predict_outbreak():
    """Run ML prediction for outbreak probability"""
    try:
        data = request.get_json()

        if not data or 'date' not in data or 'village' not in data:
            return jsonify({
                'success': False,
                'error': 'Date and village are required'
            }), 400

        target_date = data['date']
        village_key = data['village']
        model_type = data.get('model_type', 'lgbm')

        result = ml_engine.predict_outbreak(target_date, village_key, model_type)

        return jsonify(result)

    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'models_loaded': list(ml_engine.models.keys()),
        'villages_loaded': len(ml_engine.village_data),
        'water_quality_records': len(ml_engine.water_quality_data) if ml_engine.water_quality_data is not None else 0
    })

if __name__ == '__main__':
    print("🚀 Starting ML Prediction Server...")
    print(f"📊 Models loaded: {list(ml_engine.models.keys())}")
    print(f"🏘️ Villages loaded: {len(ml_engine.village_data)}")
    print("🌐 Server running on http://localhost:5000")

    app.run(host='0.0.0.0', port=5000, debug=True)