import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.57.4';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface ASHAReportData {
  village: string;
  report_date: string;
  symptoms_diarrhea: number;
  symptoms_vomiting: number;
  symptoms_fever: number;
  symptoms_jaundice: number;
  households_visited: number;
  households_affected: number;
  notes?: string;
  photo_urls?: string[];
  gps_coordinates?: { x: number; y: number };
}

interface PHCReportData {
  clinic_name: string;
  report_date: string;
  total_visits: number;
  diarrhea_cases: number;
  cholera_cases: number;
  hepatitis_cases: number;
  typhoid_cases: number;
  admissions: number;
  tests_conducted: number;
  ors_dispensed: number;
  lab_results_uploaded: boolean;
}

interface WaterQualityData {
  village: string;
  date: string;
  ph_level: number;
  turbidity: number;
  chlorine_level: number;
  nitrates: number;
  sulphates: number;
  contamination_level: number;
  source_type: string;
  sample_location: string;
}

class ReportSubmissionHandler {
  private supabase: any;

  constructor() {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    this.supabase = createClient(supabaseUrl, supabaseKey);
  }

  async submitASHAReport(reportData: ASHAReportData, userId: string): Promise<any> {
    console.log('Submitting ASHA report for user:', userId);
    
    const { data, error } = await this.supabase
      .from('asha_reports')
      .insert({
        reporter_id: userId,
        village: reportData.village,
        report_date: reportData.report_date,
        symptoms_diarrhea: reportData.symptoms_diarrhea,
        symptoms_vomiting: reportData.symptoms_vomiting,
        symptoms_fever: reportData.symptoms_fever,
        symptoms_jaundice: reportData.symptoms_jaundice,
        households_visited: reportData.households_visited,
        households_affected: reportData.households_affected,
        notes: reportData.notes,
        photo_urls: reportData.photo_urls,
        gps_coordinates: reportData.gps_coordinates ? `POINT(${reportData.gps_coordinates.x} ${reportData.gps_coordinates.y})` : null
      })
      .select()
      .single();
    
    if (error) {
      console.error('Error submitting ASHA report:', error);
      throw new Error('Failed to submit ASHA report');
    }
    
    // Check if immediate alert is needed
    await this.checkForImmediateAlerts(reportData);
    
    console.log('ASHA report submitted successfully:', data.id);
    return data;
  }

  async submitPHCReport(reportData: PHCReportData, userId: string): Promise<any> {
    console.log('Submitting PHC report for user:', userId);
    
    const { data, error } = await this.supabase
      .from('clinic_reports')
      .insert({
        reporter_id: userId,
        clinic_name: reportData.clinic_name,
        report_date: reportData.report_date,
        total_visits: reportData.total_visits,
        diarrhea_cases: reportData.diarrhea_cases,
        cholera_cases: reportData.cholera_cases,
        hepatitis_cases: reportData.hepatitis_cases,
        typhoid_cases: reportData.typhoid_cases,
        admissions: reportData.admissions,
        tests_conducted: reportData.tests_conducted,
        ors_dispensed: reportData.ors_dispensed,
        lab_results_uploaded: reportData.lab_results_uploaded
      })
      .select()
      .single();
    
    if (error) {
      console.error('Error submitting PHC report:', error);
      throw new Error('Failed to submit PHC report');
    }
    
    // Update resource consumption
    await this.updateResourceConsumption(reportData);
    
    // Check for alert conditions
    await this.checkForHealthAlerts(reportData);
    
    console.log('PHC report submitted successfully:', data.id);
    return data;
  }

  async submitWaterQualityData(waterData: WaterQualityData, userId: string): Promise<any> {
    console.log('Submitting water quality data for user:', userId);
    
    const { data, error } = await this.supabase
      .from('water_quality')
      .insert({
        date: waterData.date,
        village: waterData.village,
        ph_level: waterData.ph_level,
        turbidity: waterData.turbidity,
        chlorine_level: waterData.chlorine_level,
        nitrates: waterData.nitrates,
        sulphates: waterData.sulphates,
        contamination_level: waterData.contamination_level,
        source_type: waterData.source_type,
        sample_location: waterData.sample_location,
        tested_by: userId
      })
      .select()
      .single();
    
    if (error) {
      console.error('Error submitting water quality data:', error);
      throw new Error('Failed to submit water quality data');
    }
    
    // Check for water quality alerts
    await this.checkForWaterQualityAlerts(waterData);
    
    console.log('Water quality data submitted successfully:', data.id);
    return data;
  }

  async checkForImmediateAlerts(reportData: ASHAReportData): Promise<void> {
    const totalSymptoms = reportData.symptoms_diarrhea + reportData.symptoms_vomiting + reportData.symptoms_fever + reportData.symptoms_jaundice;
    
    // Create alert if symptoms exceed threshold
    if (totalSymptoms > 20 || reportData.households_affected > 10) {
      const severity = totalSymptoms > 50 || reportData.households_affected > 20 ? 'critical' : 'high';
      
      await this.supabase
        .from('alerts')
        .insert({
          alert_type: 'symptom_surge',
          severity: severity,
          village: reportData.village,
          title: `High Symptom Count Reported in ${reportData.village}`,
          description: `ASHA report shows ${totalSymptoms} total symptoms affecting ${reportData.households_affected} households`,
          threshold_exceeded: {
            total_symptoms: totalSymptoms,
            affected_households: reportData.households_affected,
            threshold: severity === 'critical' ? 50 : 20
          }
        });
      
      console.log(`Created ${severity} alert for ${reportData.village}`);
    }
  }

  async checkForHealthAlerts(reportData: PHCReportData): Promise<void> {
    const totalWaterborneDeaths = reportData.diarrhea_cases + reportData.cholera_cases + reportData.hepatitis_cases + reportData.typhoid_cases;
    
    // Create alert for cholera cases
    if (reportData.cholera_cases > 0) {
      await this.supabase
        .from('alerts')
        .insert({
          alert_type: 'cholera_cases',
          severity: 'critical',
          village: 'Area covered by ' + reportData.clinic_name,
          title: 'Cholera Cases Detected',
          description: `${reportData.cholera_cases} cholera cases reported at ${reportData.clinic_name}`,
          threshold_exceeded: { cholera_cases: reportData.cholera_cases, threshold: 0 }
        });
    }
    
    // Create alert for high admissions
    if (reportData.admissions > 10) {
      await this.supabase
        .from('alerts')
        .insert({
          alert_type: 'high_admissions',
          severity: reportData.admissions > 20 ? 'critical' : 'high',
          village: 'Area covered by ' + reportData.clinic_name,
          title: 'High Hospital Admissions',
          description: `${reportData.admissions} admissions reported at ${reportData.clinic_name}`,
          threshold_exceeded: { admissions: reportData.admissions, threshold: 10 }
        });
    }
  }

  async checkForWaterQualityAlerts(waterData: WaterQualityData): Promise<void> {
    const alerts = [];
    
    // pH level check
    if (waterData.ph_level < 6.5 || waterData.ph_level > 8.5) {
      alerts.push({
        type: 'water_ph_unsafe',
        severity: waterData.ph_level < 6.0 || waterData.ph_level > 9.0 ? 'critical' : 'high',
        message: `Unsafe pH level: ${waterData.ph_level}`,
        threshold: waterData.ph_level < 6.5 ? 'low' : 'high'
      });
    }
    
    // Turbidity check
    if (waterData.turbidity > 5) {
      alerts.push({
        type: 'water_turbidity_high',
        severity: waterData.turbidity > 10 ? 'critical' : 'high',
        message: `High turbidity: ${waterData.turbidity} NTU`,
        threshold: 5
      });
    }
    
    // Contamination level check
    if (waterData.contamination_level > 3.0) {
      alerts.push({
        type: 'water_contamination_high',
        severity: waterData.contamination_level > 5.0 ? 'critical' : 'high',
        message: `High contamination level: ${waterData.contamination_level}`,
        threshold: 3.0
      });
    }
    
    // Nitrates check
    if (waterData.nitrates > 45) {
      alerts.push({
        type: 'water_nitrates_high',
        severity: waterData.nitrates > 50 ? 'critical' : 'high',
        message: `High nitrate levels: ${waterData.nitrates} mg/L`,
        threshold: 45
      });
    }
    
    // Create alerts in database
    for (const alert of alerts) {
      await this.supabase
        .from('alerts')
        .insert({
          alert_type: alert.type,
          severity: alert.severity,
          village: waterData.village,
          title: `Water Quality Alert - ${waterData.village}`,
          description: `${alert.message} at ${waterData.sample_location}`,
          threshold_exceeded: {
            value: waterData[alert.type.split('_')[1] as keyof WaterQualityData],
            threshold: alert.threshold
          }
        });
    }
    
    if (alerts.length > 0) {
      console.log(`Created ${alerts.length} water quality alerts for ${waterData.village}`);
    }
  }

  async updateResourceConsumption(reportData: PHCReportData): Promise<void> {
    if (reportData.ors_dispensed > 0) {
      // Update ORS stock
      const { data: orsResource } = await this.supabase
        .from('resources')
        .select('*')
        .eq('resource_type', 'ORS Packets')
        .single();
      
      if (orsResource) {
        const newStock = Math.max(0, orsResource.current_stock - reportData.ors_dispensed);
        
        await this.supabase
          .from('resources')
          .update({ current_stock: newStock })
          .eq('id', orsResource.id);
        
        // Create low stock alert if needed
        if (newStock <= orsResource.minimum_threshold) {
          await this.supabase
            .from('alerts')
            .insert({
              alert_type: 'low_stock',
              severity: newStock === 0 ? 'critical' : 'medium',
              village: orsResource.village,
              title: 'Low ORS Stock Alert',
              description: `ORS stock is ${newStock === 0 ? 'depleted' : 'running low'}: ${newStock} packets remaining`,
              threshold_exceeded: { current_stock: newStock, minimum_threshold: orsResource.minimum_threshold }
            });
        }
      }
    }
  }

  async triggerMLPredictionUpdate(village: string, date: string): Promise<void> {
    try {
      // Call ML prediction function to update predictions with new data
      const mlResponse = await fetch(`${Deno.env.get('SUPABASE_URL')}/functions/v1/ml-prediction`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')}`
        },
        body: JSON.stringify({ date, village })
      });
      
      if (mlResponse.ok) {
        console.log('ML prediction updated successfully');
      } else {
        console.warn('Failed to trigger ML prediction update');
      }
    } catch (error) {
      console.error('Error triggering ML prediction update:', error);
    }
  }
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const requestData = await req.json();
    const { type, data: reportData } = requestData;
    
    // Get user ID from JWT token
    const authHeader = req.headers.get('authorization');
    if (!authHeader) {
      throw new Error('Authorization header missing');
    }
    
    // Extract user ID from JWT (simplified - in production, properly decode JWT)
    const userId = authHeader.split('.')[1]; // This is a placeholder - implement proper JWT decoding
    
    console.log(`Processing ${type} report submission`);
    
    const handler = new ReportSubmissionHandler();
    let result;
    
    switch (type) {
      case 'asha_report':
        result = await handler.submitASHAReport(reportData as ASHAReportData, userId);
        // Trigger ML prediction update
        await handler.triggerMLPredictionUpdate(reportData.village, reportData.report_date);
        break;
        
      case 'phc_report':
        result = await handler.submitPHCReport(reportData as PHCReportData, userId);
        // Trigger ML prediction update for clinic area
        await handler.triggerMLPredictionUpdate('Village_B', reportData.report_date);
        break;
        
      case 'water_quality':
        result = await handler.submitWaterQualityData(reportData as WaterQualityData, userId);
        // Trigger ML prediction update
        await handler.triggerMLPredictionUpdate(reportData.village, reportData.date);
        break;
        
      default:
        throw new Error(`Unknown report type: ${type}`);
    }
    
    return new Response(JSON.stringify({
      success: true,
      data: result,
      message: `${type} submitted successfully`
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
    
  } catch (error) {
    console.error('Error in report submission:', error);
    return new Response(JSON.stringify({
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error'
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
});