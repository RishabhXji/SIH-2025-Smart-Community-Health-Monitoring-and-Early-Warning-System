import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.57.4';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface DashboardRequest {
  date: string;
  village?: string;
  role: 'asha' | 'phc' | 'district' | 'state';
  timeRange?: number; // days to look back
}

class DashboardDataProvider {
  private supabase: any;

  constructor() {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    this.supabase = createClient(supabaseUrl, supabaseKey);
  }

  async getHealthSurveillanceData(date: string, village?: string, days: number = 7): Promise<any> {
    const startDate = new Date(date);
    startDate.setDate(startDate.getDate() - days);
    
    let query = this.supabase
      .from('health_surveillance')
      .select('*')
      .gte('date', startDate.toISOString().split('T')[0])
      .lte('date', date)
      .order('date', { ascending: true });
    
    if (village) {
      query = query.eq('area', village);
    }
    
    const { data, error } = await query;
    
    if (error) throw error;
    return data || [];
  }

  async getWaterQualityData(date: string, village?: string, days: number = 7): Promise<any> {
    const startDate = new Date(date);
    startDate.setDate(startDate.getDate() - days);
    
    let query = this.supabase
      .from('water_quality')
      .select('*')
      .gte('date', startDate.toISOString().split('T')[0])
      .lte('date', date)
      .order('date', { ascending: true });
    
    if (village) {
      query = query.eq('village', village);
    }
    
    const { data, error } = await query;
    
    if (error) throw error;
    return data || [];
  }

  async getMLPredictions(date: string, village?: string): Promise<any> {
    let query = this.supabase
      .from('ml_predictions')
      .select('*')
      .eq('prediction_date', date)
      .order('created_at', { ascending: false });
    
    if (village) {
      query = query.eq('village', village);
    }
    
    const { data, error } = await query;
    
    if (error) throw error;
    return data || [];
  }

  async getActiveAlerts(village?: string): Promise<any> {
    let query = this.supabase
      .from('alerts')
      .select('*')
      .eq('status', 'active')
      .order('created_at', { ascending: false });
    
    if (village) {
      query = query.eq('village', village);
    }
    
    const { data, error } = await query;
    
    if (error) throw error;
    return data || [];
  }

  async getResources(village?: string): Promise<any> {
    let query = this.supabase
      .from('resources')
      .select('*')
      .order('resource_type');
    
    if (village) {
      query = query.eq('village', village);
    }
    
    const { data, error } = await query;
    
    if (error) throw error;
    return data || [];
  }

  async getASHAReports(date: string, village?: string, days: number = 7): Promise<any> {
    const startDate = new Date(date);
    startDate.setDate(startDate.getDate() - days);
    
    let query = this.supabase
      .from('asha_reports')
      .select('*')
      .gte('report_date', startDate.toISOString().split('T')[0])
      .lte('report_date', date)
      .order('report_date', { ascending: true });
    
    if (village) {
      query = query.eq('village', village);
    }
    
    const { data, error } = await query;
    
    if (error) throw error;
    return data || [];
  }

  async getClinicReports(date: string, village?: string, days: number = 7): Promise<any> {
    const startDate = new Date(date);
    startDate.setDate(startDate.getDate() - days);
    
    let query = this.supabase
      .from('clinic_reports')
      .select('*')
      .gte('report_date', startDate.toISOString().split('T')[0])
      .lte('report_date', date)
      .order('report_date', { ascending: true });
    
    const { data, error } = await query;
    
    if (error) throw error;
    return data || [];
  }

  calculateKPIs(healthData: any[], waterData: any[], predictions: any[], alerts: any[], resources: any[]): any {
    const latestHealth = healthData[healthData.length - 1] || {};
    const latestWater = waterData[waterData.length - 1] || {};
    const latestPrediction = predictions[0] || {};
    
    // Calculate 7-day totals
    const last7Days = healthData.slice(-7);
    const totalCases7d = last7Days.reduce((sum, day) => sum + (day.true_cases || 0), 0);
    const totalReported7d = last7Days.reduce((sum, day) => sum + (day.reported_cases || 0), 0);
    const totalDiarrhea7d = last7Days.reduce((sum, day) => sum + (day.asha_symptoms_diarrhea || 0), 0);
    const totalVomiting7d = last7Days.reduce((sum, day) => sum + (day.asha_symptoms_vomiting || 0), 0);
    const totalClinicVisits7d = last7Days.reduce((sum, day) => sum + (day.clinic_visits_diarrhea || 0), 0);
    const totalAdmissions7d = last7Days.reduce((sum, day) => sum + (day.clinic_admissions || 0), 0);
    const totalORSDispensed7d = last7Days.reduce((sum, day) => sum + (day.clinic_ors_dispensed || 0), 0);
    
    // Resource calculations
    const lowStockResources = resources.filter(r => r.current_stock <= r.minimum_threshold);
    const totalORS = resources.find(r => r.resource_type === 'ORS Packets')?.current_stock || 0;
    
    return {
      // Population & Basic Metrics
      population: latestHealth.population || 0,
      
      // Health Metrics (7-day totals)
      totalCases7d,
      totalReported7d,
      totalDiarrhea7d,
      totalVomiting7d,
      totalClinicVisits7d,
      totalAdmissions7d,
      totalORSDispensed7d,
      
      // Water Quality (latest)
      waterPH: latestWater.ph_level || latestHealth.water_ph_avg || 7.0,
      waterTurbidity: latestWater.turbidity || latestHealth.water_turbidity_avg || 0,
      waterChlorine: latestWater.chlorine_level || 0,
      waterNitrates: latestWater.nitrates || 0,
      waterSulphates: latestWater.sulphates || 0,
      waterContamination: latestWater.contamination_level || latestHealth.contamination_avg || 0,
      
      // Environmental (latest)
      rainfall24h: latestHealth.rainfall_1d || 0,
      temperature: latestHealth.temperature || 0,
      rainfall7d: latestHealth.rainfall_7d_sum || 0,
      
      // Risk Scores (latest)
      exposureScore: latestHealth.exposure_score || 0,
      syndromicScore: latestHealth.syndromic_score || 0,
      vulnerabilityScore: latestHealth.vulnerability_score || 0,
      
      // ML Prediction
      outbreakProbability: latestPrediction.outbreak_probability || 0,
      riskLevel: latestPrediction.risk_level || 'low',
      
      // Alerts & Resources
      activeAlertsCount: alerts.length,
      criticalAlertsCount: alerts.filter(a => a.severity === 'critical').length,
      lowStockResourcesCount: lowStockResources.length,
      totalORSStock: totalORS,
      
      // Calculated Indicators
      waterQualityStatus: this.getWaterQualityStatus(latestWater.ph_level || latestHealth.water_ph_avg || 7.0, latestWater.turbidity || latestHealth.water_turbidity_avg || 0),
      healthTrend: this.calculateHealthTrend(last7Days),
      riskIndicators: this.calculateRiskIndicators(latestHealth, latestWater, latestPrediction)
    };
  }

  getWaterQualityStatus(ph: number, turbidity: number): string {
    if (ph < 6.5 || ph > 8.5 || turbidity > 5) return 'Poor';
    if (ph < 7.0 || ph > 8.0 || turbidity > 2) return 'Fair';
    return 'Good';
  }

  calculateHealthTrend(last7Days: any[]): string {
    if (last7Days.length < 2) return 'stable';
    
    const firstHalf = last7Days.slice(0, Math.floor(last7Days.length / 2));
    const secondHalf = last7Days.slice(Math.floor(last7Days.length / 2));
    
    const firstHalfAvg = firstHalf.reduce((sum, day) => sum + (day.true_cases || 0), 0) / firstHalf.length;
    const secondHalfAvg = secondHalf.reduce((sum, day) => sum + (day.true_cases || 0), 0) / secondHalf.length;
    
    const change = ((secondHalfAvg - firstHalfAvg) / Math.max(firstHalfAvg, 1)) * 100;
    
    if (change > 20) return 'increasing';
    if (change < -20) return 'decreasing';
    return 'stable';
  }

  calculateRiskIndicators(healthData: any, waterData: any, prediction: any): any[] {
    const indicators = [];
    
    if ((prediction.outbreak_probability || 0) > 0.5) {
      indicators.push({
        type: 'outbreak_risk',
        level: 'high',
        message: `High outbreak probability: ${((prediction.outbreak_probability || 0) * 100).toFixed(1)}%`
      });
    }
    
    if ((healthData.contamination_avg || 0) > 5.0) {
      indicators.push({
        type: 'water_contamination',
        level: 'critical',
        message: 'Water contamination levels are critically high'
      });
    }
    
    if ((healthData.cases_7d_sum || 0) > 100) {
      indicators.push({
        type: 'case_surge',
        level: 'warning',
        message: 'Significant increase in reported cases'
      });
    }
    
    const ph = waterData.ph_level || healthData.water_ph_avg || 7.0;
    if (ph < 6.5 || ph > 8.5) {
      indicators.push({
        type: 'water_ph',
        level: 'warning',
        message: `Water pH out of safe range: ${ph.toFixed(2)}`
      });
    }
    
    return indicators;
  }

  generateChartData(healthData: any[], waterData: any[], timeRange: number): any {
    const dates = healthData.map(d => d.date);
    
    return {
      casesTimeline: {
        labels: dates,
        datasets: [
          {
            label: 'True Cases',
            data: healthData.map(d => d.true_cases || 0),
            borderColor: 'hsl(var(--destructive))',
            backgroundColor: 'hsl(var(--destructive) / 0.1)',
          },
          {
            label: 'Reported Cases',
            data: healthData.map(d => d.reported_cases || 0),
            borderColor: 'hsl(var(--warning))',
            backgroundColor: 'hsl(var(--warning) / 0.1)',
          }
        ]
      },
      
      waterQualityTimeline: {
        labels: dates,
        datasets: [
          {
            label: 'pH Level',
            data: healthData.map(d => d.water_ph_avg || 7.0),
            borderColor: 'hsl(var(--primary))',
            backgroundColor: 'hsl(var(--primary) / 0.1)',
            yAxisID: 'y'
          },
          {
            label: 'Turbidity',
            data: healthData.map(d => d.water_turbidity_avg || 0),
            borderColor: 'hsl(var(--secondary))',
            backgroundColor: 'hsl(var(--secondary) / 0.1)',
            yAxisID: 'y1'
          }
        ]
      },
      
      environmentalTimeline: {
        labels: dates,
        datasets: [
          {
            label: 'Temperature (°C)',
            data: healthData.map(d => d.temperature || 0),
            borderColor: 'hsl(var(--chart-1))',
            backgroundColor: 'hsl(var(--chart-1) / 0.1)',
            yAxisID: 'y'
          },
          {
            label: 'Rainfall (mm)',
            data: healthData.map(d => d.rainfall_1d || 0),
            borderColor: 'hsl(var(--chart-2))',
            backgroundColor: 'hsl(var(--chart-2) / 0.1)',
            yAxisID: 'y1'
          }
        ]
      },
      
      symptomsTrend: {
        labels: dates,
        datasets: [
          {
            label: 'Diarrhea Cases',
            data: healthData.map(d => d.asha_symptoms_diarrhea || 0),
            borderColor: 'hsl(var(--chart-3))',
            backgroundColor: 'hsl(var(--chart-3) / 0.1)'
          },
          {
            label: 'Vomiting Cases',
            data: healthData.map(d => d.asha_symptoms_vomiting || 0),
            borderColor: 'hsl(var(--chart-4))',
            backgroundColor: 'hsl(var(--chart-4) / 0.1)'
          }
        ]
      }
    };
  }
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { date, village, role, timeRange = 7 }: DashboardRequest = await req.json();
    
    if (!date || !role) {
      throw new Error('Date and role are required');
    }
    
    console.log(`Fetching dashboard data for ${role} role, date: ${date}, village: ${village}`);
    
    const provider = new DashboardDataProvider();
    
    // Fetch all required data in parallel
    const [
      healthData,
      waterData,
      predictions,
      alerts,
      resources,
      ashaReports,
      clinicReports
    ] = await Promise.all([
      provider.getHealthSurveillanceData(date, village, timeRange),
      provider.getWaterQualityData(date, village, timeRange),
      provider.getMLPredictions(date, village),
      provider.getActiveAlerts(village),
      provider.getResources(village),
      provider.getASHAReports(date, village, timeRange),
      provider.getClinicReports(date, village, timeRange)
    ]);
    
    // Calculate KPIs
    const kpis = provider.calculateKPIs(healthData, waterData, predictions, alerts, resources);
    
    // Generate chart data
    const charts = provider.generateChartData(healthData, waterData, timeRange);
    
    return new Response(JSON.stringify({
      success: true,
      data: {
        kpis,
        charts,
        rawData: {
          healthSurveillance: healthData,
          waterQuality: waterData,
          predictions,
          alerts,
          resources,
          ashaReports,
          clinicReports
        },
        metadata: {
          date,
          village: village || 'All Villages',
          role,
          timeRange,
          dataPoints: healthData.length,
          lastUpdated: new Date().toISOString()
        }
      }
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
    
  } catch (error) {
    console.error('Error fetching dashboard data:', error);
    return new Response(JSON.stringify({
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error'
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
});