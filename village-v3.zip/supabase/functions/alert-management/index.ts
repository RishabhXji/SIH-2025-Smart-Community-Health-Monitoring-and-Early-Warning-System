import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.57.4';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface AlertAction {
  action: 'acknowledge' | 'resolve' | 'escalate' | 'assign';
  alert_id: string;
  user_id?: string;
  notes?: string;
  escalate_to?: 'phc' | 'district' | 'state';
}

class AlertManager {
  private supabase: any;

  constructor() {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    this.supabase = createClient(supabaseUrl, supabaseKey);
  }

  async acknowledgeAlert(alertId: string, userId: string): Promise<any> {
    console.log(`Acknowledging alert ${alertId} by user ${userId}`);
    
    const { data, error } = await this.supabase
      .from('alerts')
      .update({
        status: 'acknowledged',
        acknowledged_by: userId,
        acknowledged_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      })
      .eq('id', alertId)
      .select()
      .single();
    
    if (error) {
      console.error('Error acknowledging alert:', error);
      throw new Error('Failed to acknowledge alert');
    }
    
    console.log('Alert acknowledged successfully');
    return data;
  }

  async resolveAlert(alertId: string, userId: string, notes?: string): Promise<any> {
    console.log(`Resolving alert ${alertId} by user ${userId}`);
    
    const { data, error } = await this.supabase
      .from('alerts')
      .update({
        status: 'resolved',
        resolved_by: userId,
        resolved_at: new Date().toISOString(),
        resolution_notes: notes,
        updated_at: new Date().toISOString()
      })
      .eq('id', alertId)
      .select()
      .single();
    
    if (error) {
      console.error('Error resolving alert:', error);
      throw new Error('Failed to resolve alert');
    }
    
    console.log('Alert resolved successfully');
    return data;
  }

  async escalateAlert(alertId: string, escalateTo: string, userId: string): Promise<any> {
    console.log(`Escalating alert ${alertId} to ${escalateTo} by user ${userId}`);
    
    const { data, error } = await this.supabase
      .from('alerts')
      .update({
        escalated_to: escalateTo,
        escalated_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      })
      .eq('id', alertId)
      .select()
      .single();
    
    if (error) {
      console.error('Error escalating alert:', error);
      throw new Error('Failed to escalate alert');
    }
    
    // Create notification for escalated level
    await this.createEscalationNotification(data, escalateTo);
    
    console.log('Alert escalated successfully');
    return data;
  }

  async assignAlert(alertId: string, assignToUserId: string, assignedByUserId: string): Promise<any> {
    console.log(`Assigning alert ${alertId} to user ${assignToUserId} by user ${assignedByUserId}`);
    
    const { data, error } = await this.supabase
      .from('alerts')
      .update({
        assigned_to: assignToUserId,
        updated_at: new Date().toISOString()
      })
      .eq('id', alertId)
      .select()
      .single();
    
    if (error) {
      console.error('Error assigning alert:', error);
      throw new Error('Failed to assign alert');
    }
    
    console.log('Alert assigned successfully');
    return data;
  }

  async createEscalationNotification(alert: any, escalatedTo: string): Promise<void> {
    // In a real implementation, this would send notifications via email, SMS, or push notifications
    // For now, we'll create a system alert
    
    await this.supabase
      .from('alerts')
      .insert({
        alert_type: 'escalation_notification',
        severity: 'medium',
        village: alert.village,
        title: `Alert Escalated to ${escalatedTo.toUpperCase()}`,
        description: `Alert "${alert.title}" has been escalated to ${escalatedTo} level for immediate attention`,
        threshold_exceeded: { escalated_from: alert.id },
        triggered_by_prediction: false
      });
  }

  async getAlertSummary(role: string, village?: string): Promise<any> {
    let query = this.supabase
      .from('alerts')
      .select('*')
      .order('created_at', { ascending: false });
    
    // Apply role-based filtering
    if (role === 'asha' && village) {
      query = query.eq('village', village);
    } else if (role === 'phc' && village) {
      query = query.eq('village', village);
    }
    // District and state users can see all alerts
    
    const { data: alerts, error } = await query;
    
    if (error) {
      throw new Error('Failed to fetch alerts');
    }
    
    // Calculate summary statistics
    const summary = {
      total: alerts.length,
      active: alerts.filter((a: any) => a.status === 'active').length,
      acknowledged: alerts.filter((a: any) => a.status === 'acknowledged').length,
      resolved: alerts.filter((a: any) => a.status === 'resolved').length,
      critical: alerts.filter((a: any) => a.severity === 'critical' && a.status === 'active').length,
      high: alerts.filter((a: any) => a.severity === 'high' && a.status === 'active').length,
      medium: alerts.filter((a: any) => a.severity === 'medium' && a.status === 'active').length,
      low: alerts.filter((a: any) => a.severity === 'low' && a.status === 'active').length,
      byType: this.groupAlertsByType(alerts.filter((a: any) => a.status === 'active')),
      recentAlerts: alerts.slice(0, 10) // Last 10 alerts
    };
    
    return summary;
  }

  groupAlertsByType(alerts: any[]): any {
    const grouped = alerts.reduce((acc: any, alert: any) => {
      if (!acc[alert.alert_type]) {
        acc[alert.alert_type] = 0;
      }
      acc[alert.alert_type]++;
      return acc;
    }, {});
    
    return grouped;
  }

  async getAlertHistory(alertId: string): Promise<any> {
    // Get the alert details
    const { data: alert, error: alertError } = await this.supabase
      .from('alerts')
      .select('*')
      .eq('id', alertId)
      .single();
    
    if (alertError) {
      throw new Error('Alert not found');
    }
    
    // Get audit logs for this alert
    const { data: auditLogs, error: auditError } = await this.supabase
      .from('audit_logs')
      .select('*')
      .eq('record_id', alertId)
      .order('created_at', { ascending: true });
    
    if (auditError) {
      console.warn('Failed to fetch audit logs:', auditError);
    }
    
    return {
      alert,
      history: auditLogs || [],
      timeline: this.buildAlertTimeline(alert, auditLogs || [])
    };
  }

  buildAlertTimeline(alert: any, auditLogs: any[]): any[] {
    const timeline = [];
    
    // Add creation event
    timeline.push({
      timestamp: alert.created_at,
      event: 'created',
      description: 'Alert created',
      user: null,
      severity: alert.severity
    });
    
    // Add acknowledgment event
    if (alert.acknowledged_at) {
      timeline.push({
        timestamp: alert.acknowledged_at,
        event: 'acknowledged',
        description: 'Alert acknowledged',
        user: alert.acknowledged_by,
        severity: alert.severity
      });
    }
    
    // Add escalation event
    if (alert.escalated_at) {
      timeline.push({
        timestamp: alert.escalated_at,
        event: 'escalated',
        description: `Alert escalated to ${alert.escalated_to}`,
        user: null,
        severity: alert.severity
      });
    }
    
    // Add resolution event
    if (alert.resolved_at) {
      timeline.push({
        timestamp: alert.resolved_at,
        event: 'resolved',
        description: 'Alert resolved',
        user: alert.resolved_by,
        notes: alert.resolution_notes,
        severity: alert.severity
      });
    }
    
    return timeline.sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
  }

  async createManualAlert(alertData: any, createdBy: string): Promise<any> {
    console.log('Creating manual alert:', alertData.title);
    
    const { data, error } = await this.supabase
      .from('alerts')
      .insert({
        alert_type: alertData.alert_type || 'manual',
        severity: alertData.severity,
        village: alertData.village,
        title: alertData.title,
        description: alertData.description,
        threshold_exceeded: alertData.threshold_exceeded || {},
        triggered_by_prediction: false
      })
      .select()
      .single();
    
    if (error) {
      console.error('Error creating manual alert:', error);
      throw new Error('Failed to create alert');
    }
    
    console.log('Manual alert created successfully:', data.id);
    return data;
  }
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const url = new URL(req.url);
    const path = url.pathname.split('/').pop();
    
    const manager = new AlertManager();
    
    if (req.method === 'GET') {
      // Handle GET requests for alert summaries and history
      if (path === 'summary') {
        const role = url.searchParams.get('role') || 'district';
        const village = url.searchParams.get('village');
        
        const summary = await manager.getAlertSummary(role, village || undefined);
        
        return new Response(JSON.stringify({
          success: true,
          data: summary
        }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
      } else if (path === 'history') {
        const alertId = url.searchParams.get('alert_id');
        if (!alertId) {
          throw new Error('Alert ID is required');
        }
        
        const history = await manager.getAlertHistory(alertId);
        
        return new Response(JSON.stringify({
          success: true,
          data: history
        }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
      }
    } else if (req.method === 'POST') {
      // Handle POST requests for alert actions
      const requestData = await req.json();
      
      if (path === 'action') {
        const { action, alert_id, user_id, notes, escalate_to }: AlertAction = requestData;
        
        let result;
        switch (action) {
          case 'acknowledge':
            result = await manager.acknowledgeAlert(alert_id, user_id!);
            break;
          case 'resolve':
            result = await manager.resolveAlert(alert_id, user_id!, notes);
            break;
          case 'escalate':
            result = await manager.escalateAlert(alert_id, escalate_to!, user_id!);
            break;
          case 'assign':
            const assignTo = requestData.assign_to;
            result = await manager.assignAlert(alert_id, assignTo, user_id!);
            break;
          default:
            throw new Error(`Unknown action: ${action}`);
        }
        
        return new Response(JSON.stringify({
          success: true,
          data: result,
          message: `Alert ${action} completed successfully`
        }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
      } else if (path === 'create') {
        const { alert_data, created_by } = requestData;
        const result = await manager.createManualAlert(alert_data, created_by);
        
        return new Response(JSON.stringify({
          success: true,
          data: result,
          message: 'Manual alert created successfully'
        }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
      }
    }
    
    throw new Error('Invalid request path or method');
    
  } catch (error) {
    console.error('Error in alert management:', error);
    return new Response(JSON.stringify({
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error'
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
});