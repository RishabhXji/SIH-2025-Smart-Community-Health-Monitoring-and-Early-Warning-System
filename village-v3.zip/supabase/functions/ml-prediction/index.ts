import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.57.4';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface MLPredictionRequest {
  date: string;
  village: string;
}

interface FeatureVector {
  [key: string]: number;
}

// Feature names in the exact order expected by the LightGBM model
const FEATURE_NAMES = [
  'population', 'rainfall_1d', 'temperature', 'contamination_avg', 'event_cases',
  'rainfall_7d_sum', 'temp_7d_avg', 'cases_7d_sum', 'reported_cases', 'spillover_cases',
  'exposure_score', 'syndromic_score', 'spatial_score', 'vulnerability_score', 'temp_score',
  'asha_symptoms_diarrhea', 'asha_symptoms_vomiting', 'asha_households_affected', 'asha_visits_performed',
  'clinic_visits_diarrhea', 'clinic_admissions', 'clinic_tests_conducted', 'clinic_ors_dispensed',
  'water_ph_avg', 'water_turbidity_avg', 'water_sources_red_pct', 'water_contamination_sources',
  // Lag features (7-day)
  'rainfall_lag_7', 'contamination_lag_7', 'temperature_lag_7', 'turbidity_lag_7', 'exposure_lag_7', 'true_cases_lag_7',
  // Lag features (14-day)
  'rainfall_lag_14', 'contamination_lag_14', 'temperature_lag_14', 'turbidity_lag_14', 'exposure_lag_14', 'true_cases_lag_14',
  // Rolling mean features (14-day)
  'rainfall_rolling_mean_14', 'contamination_rolling_mean_14', 'temperature_rolling_mean_14', 'turbidity_rolling_mean_14', 'exposure_rolling_mean_14', 'true_cases_rolling_mean_14',
  // Rolling std features (14-day)
  'rainfall_rolling_std_14', 'contamination_rolling_std_14', 'temperature_rolling_std_14', 'turbidity_rolling_std_14', 'exposure_rolling_std_14', 'true_cases_rolling_std_14',
  // Time-based features
  'month', 'week_of_year', 'day_of_week'
];

class MLPredictor {
  private excelData: any[] = [];
  private supabase: any;

  constructor() {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    this.supabase = createClient(supabaseUrl, supabaseKey);
  }

  async loadExcelData(): Promise<void> {
    try {
      console.log('Loading health surveillance data from database...');
      const { data, error } = await this.supabase
        .from('health_surveillance')
        .select('*')
        .order('date', { ascending: true });
      
      if (error) throw error;
      
      // Convert database format to Excel-like format for compatibility
      this.excelData = data.map((row: any) => ({
        date: new Date(row.date).toLocaleDateString('en-US', {
          month: '2-digit',
          day: '2-digit', 
          year: 'numeric'
        }),
        area: row.area,
        ...row
      }));
      
      console.log(`Loaded ${this.excelData.length} rows from database`);
    } catch (error) {
      console.error('Error loading data:', error);
      throw new Error('Failed to load health surveillance data');
    }
  }

  getDataForDate(targetDate: string, village: string): any {
    const formattedDate = new Date(targetDate).toLocaleDateString('en-US', {
      month: '2-digit',
      day: '2-digit', 
      year: 'numeric'
    });
    
    let record = this.excelData.find((row: any) => 
      row.date === formattedDate && row.area === village
    );
    
    if (!record) {
      // Try to find the closest available date for the village
      const villageData = this.excelData.filter((row: any) => row.area === village);
      if (villageData.length > 0) {
        console.log(`No data for ${formattedDate}, using closest available date for ${village}`);
        record = villageData[villageData.length - 1]; // Use latest available data
      } else {
        // Use default values if no data exists for the village
        console.log(`No data found for village ${village}, using default values`);
        record = {
          area: village,
          date: formattedDate,
          population: 3000,
          rainfall_1d: 0,
          temperature: 25,
          contamination_avg: 0.1,
          event_cases: 0,
          rainfall_7d_sum: 0,
          temp_7d_avg: 25,
          cases_7d_sum: 0,
          reported_cases: 0,
          spillover_cases: 0,
          exposure_score: 0.2,
          syndromic_score: 0,
          spatial_score: 0.1,
          vulnerability_score: 0.3,
          temp_score: 0.1,
          asha_symptoms_diarrhea: 0,
          asha_symptoms_vomiting: 0,
          asha_households_affected: 0,
          asha_visits_performed: 0,
          clinic_visits_diarrhea: 0,
          clinic_admissions: 0,
          clinic_tests_conducted: 0,
          clinic_ors_dispensed: 0,
          water_ph_avg: 7.0,
          water_turbidity_avg: 5,
          water_sources_red_pct: 10,
          water_contamination_sources: 1,
          true_cases: 0
        };
      }
    }
    
    return record;
  }

  calculateLagFeatures(targetDate: string, village: string, days: number): { [key: string]: number } {
    const targetDateObj = new Date(targetDate);
    const lagDate = new Date(targetDateObj);
    lagDate.setDate(lagDate.getDate() - days);
    
    const lagDateStr = lagDate.toLocaleDateString('en-US', {
      month: '2-digit',
      day: '2-digit', 
      year: 'numeric'
    });
    
    const lagRecord = this.excelData.find((row: any) => 
      row.date === lagDateStr && row.area === village
    );
    
    if (!lagRecord) {
      // Return zeros if no data found for lag period
      return {
        [`rainfall_lag_${days}`]: 0,
        [`contamination_lag_${days}`]: 0,
        [`temperature_lag_${days}`]: 0,
        [`turbidity_lag_${days}`]: 0,
        [`exposure_lag_${days}`]: 0,
        [`true_cases_lag_${days}`]: 0,
      };
    }
    
    return {
      [`rainfall_lag_${days}`]: lagRecord.rainfall_1d || 0,
      [`contamination_lag_${days}`]: lagRecord.contamination_avg || 0,
      [`temperature_lag_${days}`]: lagRecord.temperature || 0,
      [`turbidity_lag_${days}`]: lagRecord.water_turbidity_avg || 0,
      [`exposure_lag_${days}`]: lagRecord.exposure_score || 0,
      [`true_cases_lag_${days}`]: lagRecord.true_cases || 0,
    };
  }

  calculateRollingFeatures(targetDate: string, village: string, window: number): { [key: string]: number } {
    const targetDateObj = new Date(targetDate);
    const values: {
      rainfall: number[];
      contamination: number[];
      temperature: number[];
      turbidity: number[];
      exposure: number[];
      true_cases: number[];
    } = {
      rainfall: [],
      contamination: [],
      temperature: [],
      turbidity: [],
      exposure: [],
      true_cases: []
    };
    
    // Collect data for the window period
    for (let i = 0; i < window; i++) {
      const dateObj = new Date(targetDateObj);
      dateObj.setDate(dateObj.getDate() - i);
      const dateStr = dateObj.toLocaleDateString('en-US', {
        month: '2-digit',
        day: '2-digit', 
        year: 'numeric'
      });
      
      const record = this.excelData.find((row: any) => 
        row.date === dateStr && row.area === village
      );
      
      if (record) {
        values.rainfall.push(record.rainfall_1d || 0);
        values.contamination.push(record.contamination_avg || 0);
        values.temperature.push(record.temperature || 0);
        values.turbidity.push(record.water_turbidity_avg || 0);
        values.exposure.push(record.exposure_score || 0);
        values.true_cases.push(record.true_cases || 0);
      }
    }
    
    // Calculate mean and std
    const calculateMean = (arr: number[]) => arr.length > 0 ? arr.reduce((a, b) => a + b, 0) / arr.length : 0;
    const calculateStd = (arr: number[]) => {
      if (arr.length <= 1) return 0;
      const mean = calculateMean(arr);
      const variance = arr.reduce((acc, val) => acc + Math.pow(val - mean, 2), 0) / (arr.length - 1);
      return Math.sqrt(variance);
    };
    
    return {
      [`rainfall_rolling_mean_${window}`]: calculateMean(values.rainfall),
      [`contamination_rolling_mean_${window}`]: calculateMean(values.contamination),
      [`temperature_rolling_mean_${window}`]: calculateMean(values.temperature),
      [`turbidity_rolling_mean_${window}`]: calculateMean(values.turbidity),
      [`exposure_rolling_mean_${window}`]: calculateMean(values.exposure),
      [`true_cases_rolling_mean_${window}`]: calculateMean(values.true_cases),
      [`rainfall_rolling_std_${window}`]: calculateStd(values.rainfall),
      [`contamination_rolling_std_${window}`]: calculateStd(values.contamination),
      [`temperature_rolling_std_${window}`]: calculateStd(values.temperature),
      [`turbidity_rolling_std_${window}`]: calculateStd(values.turbidity),
      [`exposure_rolling_std_${window}`]: calculateStd(values.exposure),
      [`true_cases_rolling_std_${window}`]: calculateStd(values.true_cases),
    };
  }

  calculateTimeFeatures(date: string): { [key: string]: number } {
    const dateObj = new Date(date);
    const month = dateObj.getMonth() + 1;
    const weekOfYear = Math.ceil((dateObj.getTime() - new Date(dateObj.getFullYear(), 0, 1).getTime()) / (7 * 24 * 60 * 60 * 1000));
    const dayOfWeek = dateObj.getDay();
    
    return {
      month,
      week_of_year: weekOfYear,
      day_of_week: dayOfWeek
    };
  }

  engineerFeatures(targetDate: string, village: string): FeatureVector {
    console.log(`Engineering features for ${targetDate}, ${village}`);
    
    // Get base data for the target date
    const baseData = this.getDataForDate(targetDate, village);
    
    // Calculate lag features
    const lag7Features = this.calculateLagFeatures(targetDate, village, 7);
    const lag14Features = this.calculateLagFeatures(targetDate, village, 14);
    
    // Calculate rolling features
    const rolling14Features = this.calculateRollingFeatures(targetDate, village, 14);
    
    // Calculate time features
    const timeFeatures = this.calculateTimeFeatures(targetDate);
    
    // Combine all features in the exact order expected by the model
    const features: FeatureVector = {
      // Base features
      population: baseData.population || 3000,
      rainfall_1d: baseData.rainfall_1d || 0,
      temperature: baseData.temperature || 0,
      contamination_avg: baseData.contamination_avg || 0,
      event_cases: baseData.event_cases || 0,
      rainfall_7d_sum: baseData.rainfall_7d_sum || 0,
      temp_7d_avg: baseData.temp_7d_avg || 0,
      cases_7d_sum: baseData.cases_7d_sum || 0,
      reported_cases: baseData.reported_cases || 0,
      spillover_cases: baseData.spillover_cases || 0,
      exposure_score: baseData.exposure_score || 0,
      syndromic_score: baseData.syndromic_score || 0,
      spatial_score: baseData.spatial_score || 0,
      vulnerability_score: baseData.vulnerability_score || 0,
      temp_score: baseData.temp_score || 0,
      asha_symptoms_diarrhea: baseData.asha_symptoms_diarrhea || 0,
      asha_symptoms_vomiting: baseData.asha_symptoms_vomiting || 0,
      asha_households_affected: baseData.asha_households_affected || 0,
      asha_visits_performed: baseData.asha_visits_performed || 0,
      clinic_visits_diarrhea: baseData.clinic_visits_diarrhea || 0,
      clinic_admissions: baseData.clinic_admissions || 0,
      clinic_tests_conducted: baseData.clinic_tests_conducted || 0,
      clinic_ors_dispensed: baseData.clinic_ors_dispensed || 0,
      water_ph_avg: baseData.water_ph_avg || 7.0,
      water_turbidity_avg: baseData.water_turbidity_avg || 0,
      water_sources_red_pct: baseData.water_sources_red_pct || 0,
      water_contamination_sources: baseData.water_contamination_sources || 0,
      
      // Lag features
      ...lag7Features,
      ...lag14Features,
      
      // Rolling features
      ...rolling14Features,
      
      // Time features
      ...timeFeatures
    };
    
    console.log('Engineered features:', Object.keys(features).length, 'features');
    return features;
  }

  // Mock ML prediction (replace with actual LightGBM model inference)
  async predictOutbreak(features: FeatureVector): Promise<{ probability: number, topFactors: any[], featureImportance: any }> {
    console.log('Running ML prediction...');
    
    // Mock implementation - replace with actual LightGBM model
    // For demonstration, using a simple heuristic based on key features
    const riskFactors = {
      contamination: (features.contamination_avg || 0) * 0.3,
      water_quality: Math.max(0, (7.5 - (features.water_ph_avg || 7.0)) * 0.1 + (features.water_turbidity_avg || 0) * 0.05),
      cases_trend: (features.cases_7d_sum || 0) * 0.002,
      exposure: (features.exposure_score || 0) * 0.2,
      syndromic: (features.syndromic_score || 0) * 0.01,
      rainfall: Math.min(0.1, (features.rainfall_7d_sum || 0) * 0.02)
    };
    
    const totalRisk = Object.values(riskFactors).reduce((sum, val) => sum + val, 0);
    const probability = Math.min(0.99, Math.max(0.01, totalRisk));
    
    // Identify top contributing factors
    const sortedFactors = Object.entries(riskFactors)
      .sort(([,a], [,b]) => b - a)
      .slice(0, 5)
      .map(([factor, contribution]) => ({ factor, contribution, percentage: (contribution / totalRisk * 100).toFixed(1) }));
    
    const featureImportance = {
      contamination_avg: riskFactors.contamination / totalRisk,
      water_ph_avg: riskFactors.water_quality / totalRisk * 0.6,
      water_turbidity_avg: riskFactors.water_quality / totalRisk * 0.4,
      cases_7d_sum: riskFactors.cases_trend / totalRisk,
      exposure_score: riskFactors.exposure / totalRisk,
      syndromic_score: riskFactors.syndromic / totalRisk,
      rainfall_7d_sum: riskFactors.rainfall / totalRisk
    };
    
    console.log(`Prediction complete: ${(probability * 100).toFixed(2)}% outbreak probability`);
    
    return {
      probability,
      topFactors: sortedFactors,
      featureImportance
    };
  }

  getRiskLevel(probability: number): string {
    if (probability >= 0.7) return 'critical';
    if (probability >= 0.5) return 'high';
    if (probability >= 0.3) return 'medium';
    return 'low';
  }

  async storePrediction(predictionDate: string, village: string, probability: number, topFactors: any[], featureImportance: any): Promise<void> {
    const riskLevel = this.getRiskLevel(probability);
    
    const { error } = await this.supabase
      .from('ml_predictions')
      .upsert({
        prediction_date: predictionDate,
        village: village,
        outbreak_probability: probability,
        risk_level: riskLevel,
        top_contributing_factors: topFactors,
        feature_importance: featureImportance,
        model_version: 'lgbm_v1_mock',
        prediction_horizon_days: 7,
        confidence_score: 0.85
      });
    
    if (error) {
      console.error('Error storing prediction:', error);
      throw new Error('Failed to store prediction');
    }
    
    console.log('Prediction stored successfully');
    
    // Create alert if risk is high
    if (probability >= 0.5) {
      await this.createAlert(village, probability, riskLevel, topFactors);
    }
  }

  async createAlert(village: string, probability: number, riskLevel: string, topFactors: any[]): Promise<void> {
    const severity = probability >= 0.7 ? 'critical' : 'high';
    const title = `High Outbreak Risk Detected - ${village}`;
    const description = `ML model predicts ${(probability * 100).toFixed(1)}% outbreak probability. Top factors: ${topFactors.slice(0, 3).map(f => f.factor).join(', ')}`;
    
    const { error } = await this.supabase
      .from('alerts')
      .insert({
        alert_type: 'outbreak_prediction',
        severity: severity,
        village: village,
        title: title,
        description: description,
        threshold_exceeded: { outbreak_probability: probability, threshold: 0.5 },
        triggered_by_prediction: true
      });
    
    if (error) {
      console.error('Error creating alert:', error);
    } else {
      console.log(`Alert created for ${village} with ${severity} severity`);
    }
  }
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { date, village }: MLPredictionRequest = await req.json();
    
    if (!date || !village) {
      throw new Error('Date and village are required');
    }
    
    console.log(`Processing ML prediction request for ${date}, ${village}`);
    
    const predictor = new MLPredictor();
    await predictor.loadExcelData();
    
    // Engineer features
    const features = predictor.engineerFeatures(date, village);
    
    // Run ML prediction
    const prediction = await predictor.predictOutbreak(features);
    
    // Store prediction in database
    await predictor.storePrediction(date, village, prediction.probability, prediction.topFactors, prediction.featureImportance);
    
    return new Response(JSON.stringify({
      success: true,
      prediction: {
        date,
        village,
        outbreak_probability: prediction.probability,
        risk_level: predictor.getRiskLevel(prediction.probability),
        top_contributing_factors: prediction.topFactors,
        feature_importance: prediction.featureImportance,
        confidence_score: 0.85
      }
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
    
  } catch (error) {
    console.error('Error in ML prediction:', error);
    return new Response(JSON.stringify({
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error'
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
});