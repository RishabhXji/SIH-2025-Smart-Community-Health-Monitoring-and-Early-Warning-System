-- ===============================
-- RLS Policies for SHSEWS
-- ===============================

-- Helper function to get current user role (security definer to avoid RLS recursion)
CREATE OR REPLACE FUNCTION public.get_current_user_role()
RETURNS TEXT AS $$
  SELECT role::text FROM public.profiles WHERE user_id = auth.uid();
$$ LANGUAGE SQL SECURITY DEFINER STABLE SET search_path = public;

-- Helper function to get current user village/district access
CREATE OR REPLACE FUNCTION public.get_user_access_level()
RETURNS TABLE(role TEXT, village TEXT, district TEXT, state TEXT) AS $$
  SELECT role::text, village, district, state 
  FROM public.profiles 
  WHERE user_id = auth.uid();
$$ LANGUAGE SQL SECURITY DEFINER STABLE SET search_path = public;

-- ===============================
-- Profiles RLS Policies
-- ===============================

-- Users can view their own profile
CREATE POLICY "Users can view own profile" ON public.profiles
FOR SELECT USING (user_id = auth.uid());

-- Users can update their own profile
CREATE POLICY "Users can update own profile" ON public.profiles
FOR UPDATE USING (user_id = auth.uid());

-- Users can insert their own profile
CREATE POLICY "Users can insert own profile" ON public.profiles
FOR INSERT WITH CHECK (user_id = auth.uid());

-- ===============================
-- Health Surveillance RLS Policies  
-- ===============================

-- All authenticated users can view health surveillance data (government transparency)
CREATE POLICY "All authenticated users can view health data" ON public.health_surveillance
FOR SELECT TO authenticated USING (true);

-- Only PHC, District, and State users can insert/update
CREATE POLICY "PHC+ users can modify health data" ON public.health_surveillance
FOR ALL TO authenticated USING (
  public.get_current_user_role() IN ('phc', 'district', 'state')
);

-- ===============================
-- ASHA Reports RLS Policies
-- ===============================

-- ASHA users can view their own reports
CREATE POLICY "ASHA can view own reports" ON public.asha_reports
FOR SELECT USING (
  reporter_id = auth.uid() OR 
  public.get_current_user_role() IN ('phc', 'district', 'state')
);

-- Only ASHA users can insert their own reports
CREATE POLICY "ASHA can insert own reports" ON public.asha_reports
FOR INSERT WITH CHECK (reporter_id = auth.uid() AND public.get_current_user_role() = 'asha');

-- ASHA can update their own unvalidated reports
CREATE POLICY "ASHA can update own unvalidated reports" ON public.asha_reports
FOR UPDATE USING (
  reporter_id = auth.uid() AND 
  validated_by IS NULL AND 
  public.get_current_user_role() = 'asha'
);

-- PHC+ users can validate reports
CREATE POLICY "PHC+ can validate reports" ON public.asha_reports
FOR UPDATE USING (public.get_current_user_role() IN ('phc', 'district', 'state'));

-- ===============================
-- Clinic Reports RLS Policies
-- ===============================

-- PHC users can view/modify their own reports
CREATE POLICY "PHC can manage own reports" ON public.clinic_reports
FOR ALL USING (
  reporter_id = auth.uid() OR 
  public.get_current_user_role() IN ('district', 'state')
);

-- Only PHC+ users can insert clinic reports
CREATE POLICY "PHC+ can insert clinic reports" ON public.clinic_reports
FOR INSERT WITH CHECK (
  reporter_id = auth.uid() AND 
  public.get_current_user_role() IN ('phc', 'district', 'state')
);

-- ===============================
-- ML Predictions RLS Policies
-- ===============================

-- All authenticated users can view ML predictions
CREATE POLICY "All authenticated can view predictions" ON public.ml_predictions
FOR SELECT TO authenticated USING (true);

-- Only system/district+ users can insert predictions
CREATE POLICY "District+ can insert predictions" ON public.ml_predictions
FOR INSERT WITH CHECK (public.get_current_user_role() IN ('district', 'state'));

-- ===============================
-- Alerts RLS Policies
-- ===============================

-- Users can view alerts relevant to their access level
CREATE POLICY "Users can view relevant alerts" ON public.alerts
FOR SELECT TO authenticated USING (
  CASE 
    WHEN public.get_current_user_role() = 'asha' THEN 
      village IN (SELECT village FROM public.profiles WHERE user_id = auth.uid())
    WHEN public.get_current_user_role() = 'phc' THEN 
      village IN (SELECT village FROM public.profiles WHERE user_id = auth.uid() AND village IS NOT NULL)
    ELSE true  -- district and state can see all
  END
);

-- PHC+ users can insert alerts
CREATE POLICY "PHC+ can insert alerts" ON public.alerts
FOR INSERT WITH CHECK (public.get_current_user_role() IN ('phc', 'district', 'state'));

-- Users can update alerts assigned to them
CREATE POLICY "Users can update assigned alerts" ON public.alerts
FOR UPDATE USING (
  assigned_to = auth.uid() OR 
  public.get_current_user_role() IN ('district', 'state')
);

-- ===============================
-- Resources & Other Tables RLS Policies
-- ===============================

-- Resources - village-level access control
CREATE POLICY "Village-level resource access" ON public.resources
FOR SELECT TO authenticated USING (
  CASE 
    WHEN public.get_current_user_role() IN ('asha', 'phc') THEN 
      village IN (SELECT village FROM public.profiles WHERE user_id = auth.uid())
    ELSE true  -- district and state can see all
  END
);

-- PHC+ can modify resources
CREATE POLICY "PHC+ can modify resources" ON public.resources
FOR ALL USING (public.get_current_user_role() IN ('phc', 'district', 'state'));

-- Water quality - all authenticated can view
CREATE POLICY "All authenticated can view water quality" ON public.water_quality
FOR SELECT TO authenticated USING (true);

-- PHC+ can insert water quality data
CREATE POLICY "PHC+ can insert water quality" ON public.water_quality
FOR INSERT WITH CHECK (public.get_current_user_role() IN ('phc', 'district', 'state'));

-- Environmental data - all authenticated can view
CREATE POLICY "All authenticated can view environmental" ON public.environmental_data
FOR SELECT TO authenticated USING (true);

-- District+ can modify environmental data
CREATE POLICY "District+ can modify environmental" ON public.environmental_data
FOR ALL USING (public.get_current_user_role() IN ('district', 'state'));

-- RRT deployments - district+ access
CREATE POLICY "District+ can manage RRT" ON public.rrt_deployments
FOR ALL USING (public.get_current_user_role() IN ('district', 'state'));

-- Audit logs - state level only
CREATE POLICY "State users can view audit logs" ON public.audit_logs
FOR SELECT USING (public.get_current_user_role() = 'state');

-- ===============================
-- Sample Data for Testing
-- ===============================

-- Insert some sample health surveillance data from Excel
INSERT INTO public.health_surveillance (
    date, area, population, rainfall_1d, temperature, true_cases, 
    contamination_avg, event_cases, rainfall_7d_sum, temp_7d_avg, 
    cases_7d_sum, reported_cases, spillover_cases, exposure_score,
    syndromic_score, spatial_score, vulnerability_score, temp_score,
    asha_symptoms_diarrhea, asha_symptoms_vomiting, asha_households_affected,
    asha_visits_performed, clinic_visits_diarrhea, clinic_admissions,
    clinic_tests_conducted, clinic_ors_dispensed, water_ph_avg,
    water_turbidity_avg, water_sources_red_pct, water_contamination_sources,
    outbreak_label_h7
) VALUES 
('2025-01-01', 'Village_B', 3000, 2.3, 10.7, 14, 0.38, 0, 2.3, 10.7, 14, 0, 0, 0.61, 0, 0, 0.45, -0.43, 9, 5, 3, 36, 2, 1, 0, 3, 7.12, 1.84, 0, 0, 0),
('2025-01-02', 'Village_B', 3000, 0.96, 13.9, 24, 0.77, 0, 3.26, 12.3, 38, 11, 0, 0.86, 1.1, 0, 0.45, -0.11, 18, 11, 7, 36, 7, 1, 3, 5, 6.84, 1.8, 0, 0, 0.1),
('2025-01-03', 'Village_B', 3000, 2.75, 14.16, 14, 1.85, 3, 6.01, 12.92, 52, 0, 0, 2.13, 1.1, 0, 0.45, -0.08, 8, 6, 0, 36, 7, 3, 3, 4, 7.1, 3.71, 100, 10, 0.05),
('2025-01-04', 'Village_B', 3000, 2.94, 10.15, 23, 2.98, 0, 8.95, 12.23, 75, 0, 0, 3.28, 1.1, 0, 0.45, -0.48, 19, 14, 2, 36, 7, 0, 4, 1, 6.66, 2.26, 100, 10, 0.27),
('2025-01-05', 'Village_B', 3000, 0.05, 10.34, 16, 2.82, 0, 9, 11.85, 91, 24, 0, 2.82, 3.5, 0, 0.45, -0.47, 11, 9, 3, 36, 7, 0, 2, 3, 7.05, 1.43, 80, 8, 0.31);

-- Insert sample resources
INSERT INTO public.resources (resource_type, village, total_available, current_stock, minimum_threshold) VALUES 
('ORS Packets', 'Village_B', 1000, 750, 100),
('Chlorine Tablets', 'Village_B', 500, 200, 50),
('Test Kits', 'Village_B', 50, 30, 10),
('Medical Supplies', 'Village_B', 200, 150, 25);

-- Insert sample water quality data
INSERT INTO public.water_quality (date, village, ph_level, turbidity, chlorine_level, nitrates, sulphates, contamination_level, source_type) VALUES 
('2025-01-01', 'Village_B', 7.12, 1.84, 0.5, 10, 15, 0.38, 'Hand Pump'),
('2025-01-02', 'Village_B', 6.84, 1.80, 0.3, 12, 18, 0.77, 'Hand Pump'),
('2025-01-03', 'Village_B', 7.10, 3.71, 0.2, 15, 20, 1.85, 'Hand Pump'),
('2025-01-04', 'Village_B', 6.66, 2.26, 0.1, 18, 22, 2.98, 'Hand Pump'),
('2025-01-05', 'Village_B', 7.05, 1.43, 0.4, 14, 16, 2.82, 'Hand Pump');