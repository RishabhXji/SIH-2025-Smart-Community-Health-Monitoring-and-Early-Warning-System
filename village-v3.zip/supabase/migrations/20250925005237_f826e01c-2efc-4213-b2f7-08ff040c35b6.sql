-- ===============================
-- SHSEWS Database Schema Setup
-- ===============================

-- Create enums for roles and status
CREATE TYPE public.user_role AS ENUM ('asha', 'phc', 'district', 'state');
CREATE TYPE public.alert_severity AS ENUM ('low', 'medium', 'high', 'critical');
CREATE TYPE public.alert_status AS ENUM ('active', 'acknowledged', 'resolved');

-- ===============================
-- User Management Tables
-- ===============================

-- User profiles table
CREATE TABLE public.profiles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
    role user_role NOT NULL,
    full_name TEXT NOT NULL,
    phone TEXT,
    village TEXT,
    block TEXT,
    district TEXT,
    state TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
    UNIQUE(user_id)
);

-- ===============================
-- Health Surveillance Data
-- ===============================

-- Main health surveillance data table (matches Excel structure)
CREATE TABLE public.health_surveillance (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    date DATE NOT NULL,
    area TEXT NOT NULL,
    population INTEGER NOT NULL,
    rainfall_1d DECIMAL(10,2),
    temperature DECIMAL(10,2),
    true_cases INTEGER,
    contamination_avg DECIMAL(10,4),
    event_cases INTEGER,
    rainfall_7d_sum DECIMAL(10,2),
    temp_7d_avg DECIMAL(10,2),
    cases_7d_sum INTEGER,
    reported_cases INTEGER,
    spillover_cases INTEGER,
    exposure_score DECIMAL(10,4),
    syndromic_score DECIMAL(10,2),
    spatial_score DECIMAL(10,2),
    vulnerability_score DECIMAL(10,2),
    temp_score DECIMAL(10,2),
    asha_symptoms_diarrhea INTEGER,
    asha_symptoms_vomiting INTEGER,
    asha_households_affected INTEGER,
    asha_visits_performed INTEGER,
    clinic_visits_diarrhea INTEGER,
    clinic_admissions INTEGER,
    clinic_tests_conducted INTEGER,
    clinic_ors_dispensed INTEGER,
    water_ph_avg DECIMAL(10,2),
    water_turbidity_avg DECIMAL(10,2),
    water_sources_red_pct INTEGER,
    water_contamination_sources INTEGER,
    outbreak_label_h7 DECIMAL(10,2),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
    UNIQUE(date, area)
);

-- Water quality detailed tracking
CREATE TABLE public.water_quality (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    date DATE NOT NULL,
    village TEXT NOT NULL,
    ph_level DECIMAL(4,2),
    turbidity DECIMAL(10,2),
    chlorine_level DECIMAL(10,2),
    nitrates DECIMAL(10,2),
    sulphates DECIMAL(10,2),
    contamination_level DECIMAL(10,4),
    source_type TEXT,
    sample_location TEXT,
    tested_by UUID REFERENCES auth.users(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL
);

-- Environmental data
CREATE TABLE public.environmental_data (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    date DATE NOT NULL,
    village TEXT NOT NULL,
    rainfall_24h DECIMAL(10,2),
    temperature_avg DECIMAL(10,2),
    humidity DECIMAL(5,2),
    flood_risk_level INTEGER CHECK (flood_risk_level BETWEEN 0 AND 5),
    weather_alerts TEXT[],
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL
);

-- ===============================
-- Health Reports & Data Collection
-- ===============================

-- ASHA reports
CREATE TABLE public.asha_reports (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    reporter_id UUID REFERENCES auth.users(id) NOT NULL,
    village TEXT NOT NULL,
    report_date DATE NOT NULL,
    symptoms_diarrhea INTEGER DEFAULT 0,
    symptoms_vomiting INTEGER DEFAULT 0,
    symptoms_fever INTEGER DEFAULT 0,
    symptoms_jaundice INTEGER DEFAULT 0,
    households_visited INTEGER DEFAULT 0,
    households_affected INTEGER DEFAULT 0,
    photo_urls TEXT[],
    notes TEXT,
    gps_coordinates POINT,
    validated_by UUID REFERENCES auth.users(id),
    validated_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL
);

-- PHC/Clinic reports
CREATE TABLE public.clinic_reports (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    reporter_id UUID REFERENCES auth.users(id) NOT NULL,
    clinic_name TEXT NOT NULL,
    report_date DATE NOT NULL,
    total_visits INTEGER DEFAULT 0,
    diarrhea_cases INTEGER DEFAULT 0,
    cholera_cases INTEGER DEFAULT 0,
    hepatitis_cases INTEGER DEFAULT 0,
    typhoid_cases INTEGER DEFAULT 0,
    admissions INTEGER DEFAULT 0,
    tests_conducted INTEGER DEFAULT 0,
    ors_dispensed INTEGER DEFAULT 0,
    lab_results_uploaded BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL
);

-- ===============================
-- ML Predictions & Analytics
-- ===============================

-- ML predictions table
CREATE TABLE public.ml_predictions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    prediction_date DATE NOT NULL,
    village TEXT NOT NULL,
    outbreak_probability DECIMAL(5,4) NOT NULL CHECK (outbreak_probability BETWEEN 0 AND 1),
    risk_level TEXT NOT NULL CHECK (risk_level IN ('low', 'medium', 'high', 'critical')),
    top_contributing_factors JSONB,
    feature_importance JSONB,
    model_version TEXT DEFAULT 'lgbm_v1',
    prediction_horizon_days INTEGER DEFAULT 7,
    confidence_score DECIMAL(5,4),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
    UNIQUE(prediction_date, village)
);

-- ===============================
-- Alert Management System
-- ===============================

-- Alerts table
CREATE TABLE public.alerts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    alert_type TEXT NOT NULL,
    severity alert_severity NOT NULL,
    status alert_status DEFAULT 'active',
    village TEXT NOT NULL,
    title TEXT NOT NULL,
    description TEXT NOT NULL,
    threshold_exceeded JSONB,
    triggered_by_prediction BOOLEAN DEFAULT FALSE,
    assigned_to UUID REFERENCES auth.users(id),
    acknowledged_by UUID REFERENCES auth.users(id),
    acknowledged_at TIMESTAMP WITH TIME ZONE,
    resolved_by UUID REFERENCES auth.users(id),
    resolved_at TIMESTAMP WITH TIME ZONE,
    resolution_notes TEXT,
    escalated_to user_role,
    escalated_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL
);

-- ===============================
-- Resource Management
-- ===============================

-- Resources tracking
CREATE TABLE public.resources (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    resource_type TEXT NOT NULL,
    village TEXT NOT NULL,
    total_available INTEGER NOT NULL DEFAULT 0,
    current_stock INTEGER NOT NULL DEFAULT 0,
    minimum_threshold INTEGER DEFAULT 10,
    last_restocked_date DATE,
    expiry_date DATE,
    managed_by UUID REFERENCES auth.users(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL
);

-- RRT (Rapid Response Team) deployments
CREATE TABLE public.rrt_deployments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    village TEXT NOT NULL,
    deployment_date DATE NOT NULL,
    team_members TEXT[],
    deployment_reason TEXT,
    alert_id UUID REFERENCES public.alerts(id),
    status TEXT DEFAULT 'deployed' CHECK (status IN ('deployed', 'in_progress', 'completed')),
    completion_date DATE,
    outcome_report TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL
);

-- ===============================
-- Audit & Logging
-- ===============================

-- Audit logs for user actions
CREATE TABLE public.audit_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES auth.users(id),
    action TEXT NOT NULL,
    table_name TEXT,
    record_id UUID,
    old_values JSONB,
    new_values JSONB,
    ip_address INET,
    user_agent TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL
);

-- ===============================
-- Indexes for Performance
-- ===============================

-- Health surveillance indexes
CREATE INDEX idx_health_surveillance_date ON public.health_surveillance(date);
CREATE INDEX idx_health_surveillance_area ON public.health_surveillance(area);
CREATE INDEX idx_health_surveillance_date_area ON public.health_surveillance(date, area);

-- Water quality indexes
CREATE INDEX idx_water_quality_date ON public.water_quality(date);
CREATE INDEX idx_water_quality_village ON public.water_quality(village);

-- ML predictions indexes
CREATE INDEX idx_ml_predictions_date ON public.ml_predictions(prediction_date);
CREATE INDEX idx_ml_predictions_village ON public.ml_predictions(village);
CREATE INDEX idx_ml_predictions_risk ON public.ml_predictions(risk_level);

-- Alerts indexes
CREATE INDEX idx_alerts_status ON public.alerts(status);
CREATE INDEX idx_alerts_severity ON public.alerts(severity);
CREATE INDEX idx_alerts_village ON public.alerts(village);
CREATE INDEX idx_alerts_created ON public.alerts(created_at);

-- Reports indexes
CREATE INDEX idx_asha_reports_date ON public.asha_reports(report_date);
CREATE INDEX idx_asha_reports_village ON public.asha_reports(village);
CREATE INDEX idx_clinic_reports_date ON public.clinic_reports(report_date);

-- ===============================
-- Enable Row Level Security
-- ===============================

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.health_surveillance ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.water_quality ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.environmental_data ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.asha_reports ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.clinic_reports ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ml_predictions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.alerts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.resources ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.rrt_deployments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;

-- ===============================
-- Trigger Functions
-- ===============================

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION public.handle_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger for updated_at on various tables
CREATE TRIGGER handle_updated_at_profiles
    BEFORE UPDATE ON public.profiles
    FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();

CREATE TRIGGER handle_updated_at_health_surveillance
    BEFORE UPDATE ON public.health_surveillance
    FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();

CREATE TRIGGER handle_updated_at_alerts
    BEFORE UPDATE ON public.alerts
    FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();

CREATE TRIGGER handle_updated_at_resources
    BEFORE UPDATE ON public.resources
    FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();

-- Function to create audit log entries
CREATE OR REPLACE FUNCTION public.create_audit_log()
RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO public.audit_logs (
        user_id,
        action,
        table_name,
        record_id,
        old_values,
        new_values
    ) VALUES (
        auth.uid(),
        TG_OP,
        TG_TABLE_NAME,
        COALESCE(NEW.id, OLD.id),
        CASE WHEN TG_OP = 'DELETE' THEN to_jsonb(OLD) ELSE NULL END,
        CASE WHEN TG_OP = 'INSERT' OR TG_OP = 'UPDATE' THEN to_jsonb(NEW) ELSE NULL END
    );
    RETURN COALESCE(NEW, OLD);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Apply audit triggers to sensitive tables
CREATE TRIGGER audit_asha_reports
    AFTER INSERT OR UPDATE OR DELETE ON public.asha_reports
    FOR EACH ROW EXECUTE FUNCTION public.create_audit_log();

CREATE TRIGGER audit_clinic_reports
    AFTER INSERT OR UPDATE OR DELETE ON public.clinic_reports
    FOR EACH ROW EXECUTE FUNCTION public.create_audit_log();

CREATE TRIGGER audit_alerts
    AFTER INSERT OR UPDATE OR DELETE ON public.alerts
    FOR EACH ROW EXECUTE FUNCTION public.create_audit_log();