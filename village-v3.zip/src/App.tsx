import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Home from "./pages/Home";
import ASHADashboard from "./pages/ASHADashboard";
import PHCDashboard from "./pages/PHCDashboard";  
import DistrictDashboard from "./pages/DistrictDashboard";
import StateDashboard from "./pages/StateDashboard";
import MLPrediction from "./pages/MLPrediction";
import Login from "./pages/Login";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/login/:role" element={<Login />} />
          <Route path="/dashboard/asha" element={<ASHADashboard />} />
          <Route path="/dashboard/phc" element={<PHCDashboard />} />
          <Route path="/dashboard/district" element={<DistrictDashboard />} />
          <Route path="/dashboard/state" element={<StateDashboard />} />
          <Route path="/ml-prediction" element={<MLPrediction />} />
          {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;