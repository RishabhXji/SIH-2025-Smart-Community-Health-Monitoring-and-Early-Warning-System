import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { 
  Users, 
  Heart, 
  Home, 
  Thermometer, 
  Droplets,
  Camera,
  AlertTriangle,
  TrendingUp,
  MapPin,
  LogOut
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const ASHADashboard = () => {
  const navigate = useNavigate();
  const [reportData, setReportData] = useState({
    diarrhea: '',
    fever: '',
    vomiting: '',
    jaundice: ''
  });

  const villageSummary = {
    population: 2847,
    activeCases: 12,
    recentRainfall: 45.2,
    temperature: 28.5,
    waterRiskLevel: 'Medium',
    householdVisits: 45
  };

  const educationalTips = [
    "Boil water for at least 1 minute before drinking",
    "Wash hands with soap for 20 seconds",
    "Use ORS for dehydration treatment",
    "Keep food covered and eat fresh meals"
  ];

  const handleReportSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle form submission
    console.log('Report submitted:', reportData);
  };

  return (
    <div className="min-h-screen bg-dashboard">
      {/* Header */}
      <header className="bg-gradient-government text-white shadow-government">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Heart className="h-8 w-8" />
              <div>
                <h1 className="text-xl font-bold">ASHA Worker Dashboard</h1>
                <p className="text-sm text-white/80">Rampur Village, Block: Sadar</p>
              </div>
            </div>
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => navigate('/')}
              className="border-white/30 text-white hover:bg-white/20"
            >
              <LogOut className="h-4 w-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-6">
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Village Summary */}
          <div className="lg:col-span-2 space-y-6">
            <Card className="gov-card">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <MapPin className="h-5 w-5 text-primary" />
                  <span>Village Summary</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  <div className="kpi-card">
                    <div className="kpi-number">{villageSummary.population.toLocaleString()}</div>
                    <p className="text-sm text-muted-foreground">Total Population</p>
                  </div>
                  <div className="kpi-card">
                    <div className="kpi-number text-warning">{villageSummary.activeCases}</div>
                    <p className="text-sm text-muted-foreground">Active Cases (7-day)</p>
                  </div>
                  <div className="kpi-card">
                    <div className="kpi-number">{villageSummary.householdVisits}</div>
                    <p className="text-sm text-muted-foreground">Household Visits</p>
                  </div>
                </div>
                
                <div className="grid sm:grid-cols-2 gap-4 mt-4">
                  <div className="flex items-center justify-between p-4 bg-secondary-light rounded-lg">
                    <div className="flex items-center space-x-3">
                      <Droplets className="h-5 w-5 text-secondary" />
                      <span className="font-medium">Rainfall</span>
                    </div>
                    <span className="font-bold">{villageSummary.recentRainfall}mm</span>
                  </div>
                  <div className="flex items-center justify-between p-4 bg-accent-light rounded-lg">
                    <div className="flex items-center space-x-3">
                      <Thermometer className="h-5 w-5 text-accent" />
                      <span className="font-medium">Temperature</span>
                    </div>
                    <span className="font-bold">{villageSummary.temperature}°C</span>
                  </div>
                </div>

                <div className="mt-4 p-4 bg-muted rounded-lg">
                  <div className="flex items-center justify-between">
                    <span className="font-medium">Water Source Risk Level</span>
                    <Badge className="status-warning">{villageSummary.waterRiskLevel}</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Symptom Reporting */}
            <Card className="gov-card">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Heart className="h-5 w-5 text-primary" />
                  <span>Daily Symptom Report</span>
                </CardTitle>
                <CardDescription>Report number of people with symptoms in your area</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleReportSubmit} className="space-y-4">
                  <div className="grid sm:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="diarrhea">People with Diarrhea</Label>
                      <Input
                        id="diarrhea"
                        type="number"
                        placeholder="0"
                        value={reportData.diarrhea}
                        onChange={(e) => setReportData(prev => ({...prev, diarrhea: e.target.value}))}
                      />
                    </div>
                    <div>
                      <Label htmlFor="fever">People with Fever</Label>
                      <Input
                        id="fever"
                        type="number"
                        placeholder="0"
                        value={reportData.fever}
                        onChange={(e) => setReportData(prev => ({...prev, fever: e.target.value}))}
                      />
                    </div>
                    <div>
                      <Label htmlFor="vomiting">People with Vomiting</Label>
                      <Input
                        id="vomiting"
                        type="number"
                        placeholder="0"
                        value={reportData.vomiting}
                        onChange={(e) => setReportData(prev => ({...prev, vomiting: e.target.value}))}
                      />
                    </div>
                    <div>
                      <Label htmlFor="jaundice">People with Jaundice</Label>
                      <Input
                        id="jaundice"
                        type="number"
                        placeholder="0"
                        value={reportData.jaundice}
                        onChange={(e) => setReportData(prev => ({...prev, jaundice: e.target.value}))}
                      />
                    </div>
                  </div>
                  <div className="flex space-x-3">
                    <Button type="submit" className="btn-government">
                      Submit Report
                    </Button>
                    <Button type="button" variant="outline" className="flex items-center space-x-2">
                      <Camera className="h-4 w-4" />
                      <span>Upload Photos</span>
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Alerts */}
            <Card className="gov-card border-warning/20">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2 text-warning">
                  <AlertTriangle className="h-5 w-5" />
                  <span>Active Alerts</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="p-3 bg-warning-light rounded-lg border border-warning/20">
                  <p className="font-medium text-sm">Water Quality Alert</p>
                  <p className="text-xs text-muted-foreground">Hand pump near school showing high turbidity</p>
                  <p className="text-xs text-warning font-medium mt-1">2 hours ago</p>
                </div>
                <div className="p-3 bg-success-light rounded-lg border border-success/20">
                  <p className="font-medium text-sm">Resolved</p>
                  <p className="text-xs text-muted-foreground">Chlorine tablets distributed</p>
                  <p className="text-xs text-success font-medium mt-1">Yesterday</p>
                </div>
              </CardContent>
            </Card>

            {/* Educational Tips */}
            <Card className="gov-card">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <TrendingUp className="h-5 w-5 text-secondary" />
                  <span>Prevention Tips</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {educationalTips.map((tip, index) => (
                    <div key={index} className="flex items-start space-x-3 p-2">
                      <div className="w-2 h-2 bg-secondary rounded-full mt-2 flex-shrink-0" />
                      <p className="text-sm text-foreground">{tip}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card className="gov-card">
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button className="w-full btn-secondary-gov">
                  <Home className="h-4 w-4 mr-2" />
                  Log Household Visit
                </Button>
                <Button variant="outline" className="w-full">
                  <Users className="h-4 w-4 mr-2" />
                  Community Meeting
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ASHADashboard;