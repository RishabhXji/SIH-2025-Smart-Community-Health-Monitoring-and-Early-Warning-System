import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  Globe, 
  Heart, 
  TrendingUp,
  AlertTriangle,
  BarChart3,
  Users,
  LogOut,
  Brain,
  FileText,
  Shield,
  Activity
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const StateDashboard = () => {
  const navigate = useNavigate();

  const stateSummary = {
    totalDistricts: 24,
    activeOutbreaks: 5,
    populationAtRisk: 2847500,
    mlPredictionAccuracy: 89.4,
    resourcesAllocated: 94,
    casesLastMonth: 1847
  };

  const districtComparison = [
    { name: 'Sadar', population: 284750, riskScore: 0.72, outbreaks: 2, trend: '+15%' },
    { name: 'Central', population: 432100, riskScore: 0.45, outbreaks: 1, trend: '-8%' },
    { name: 'North', population: 321850, riskScore: 0.63, outbreaks: 1, trend: '+5%' },
    { name: 'South', population: 198670, riskScore: 0.34, outbreaks: 0, trend: '-12%' },
    { name: 'East', population: 276430, riskScore: 0.58, outbreaks: 1, trend: '+3%' }
  ];

  const mlPredictions = [
    { 
      district: 'Sadar', 
      outbreakProbability: 78, 
      timeframe: '7-14 days',
      primaryFactors: ['Rainfall', 'Water Contamination', 'Population Density'],
      confidence: 89
    },
    { 
      district: 'North', 
      outbreakProbability: 45, 
      timeframe: '14-21 days',
      primaryFactors: ['Temperature', 'Sanitation', 'Historical Pattern'],
      confidence: 82
    }
  ];

  const resourceAllocation = {
    orsKits: { allocated: 45000, required: 50000, gap: 5000 },
    doctors: { allocated: 340, required: 400, gap: 60 },
    rrts: { allocated: 25, required: 30, gap: 5 },
    chlorine: { allocated: 85000, required: 90000, gap: 5000 }
  };

  const getRiskColor = (score: number) => {
    if (score >= 0.7) return 'text-destructive';
    if (score >= 0.5) return 'text-warning';
    return 'text-success';
  };

  const getRiskBadge = (score: number) => {
    if (score >= 0.7) return 'status-critical';
    if (score >= 0.5) return 'status-warning';
    return 'status-good';
  };

  return (
    <div className="min-h-screen bg-dashboard">
      {/* Header */}
      <header className="bg-gradient-government text-white shadow-government">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Globe className="h-8 w-8" />
              <div>
                <h1 className="text-xl font-bold">State/National Authority Dashboard</h1>
                <p className="text-sm text-white/80">Multi-District Health Surveillance Command Center</p>
              </div>
            </div>
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => navigate('/')}
              className="border-white/30 text-white hover:bg-white/20"
            >
              <LogOut className="h-4 w-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-6">
        {/* KPI Cards */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-6">
          <div className="kpi-card">
            <div className="kpi-number">{stateSummary.totalDistricts}</div>
            <p className="text-sm text-muted-foreground">Districts</p>
          </div>
          <div className="kpi-card">
            <div className="kpi-number text-destructive">{stateSummary.activeOutbreaks}</div>
            <p className="text-sm text-muted-foreground">Active Outbreaks</p>
          </div>
          <div className="kpi-card">
            <div className="kpi-number">{(stateSummary.populationAtRisk / 1000000).toFixed(1)}M</div>
            <p className="text-sm text-muted-foreground">Population at Risk</p>
          </div>
          <div className="kpi-card">
            <div className="kpi-number text-secondary">{stateSummary.mlPredictionAccuracy}%</div>
            <p className="text-sm text-muted-foreground">ML Accuracy</p>
          </div>
          <div className="kpi-card">
            <div className="kpi-number">{stateSummary.resourcesAllocated}%</div>
            <p className="text-sm text-muted-foreground">Resources</p>
          </div>
          <div className="kpi-card">
            <div className="kpi-number">{(stateSummary.casesLastMonth / 1000).toFixed(1)}K</div>
            <p className="text-sm text-muted-foreground">Cases (30-day)</p>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* State Heatmap Placeholder */}
            <Card className="gov-card">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <BarChart3 className="h-5 w-5 text-primary" />
                  <span>State-Level Outbreak Intensity Heatmap</span>
                </CardTitle>
                <CardDescription>Comparative outbreak intensity across all districts</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-64 bg-gradient-subtle rounded-lg flex items-center justify-center border-2 border-dashed border-border">
                  <div className="text-center">
                    <BarChart3 className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                    <p className="text-muted-foreground">Interactive State Heatmap</p>
                    <p className="text-sm text-muted-foreground">District-wise risk visualization</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* District Comparison */}
            <Card className="gov-card">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Activity className="h-5 w-5 text-secondary" />
                  <span>District Comparative Analytics</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {districtComparison.map((district, index) => (
                    <div key={index} className="grid grid-cols-2 md:grid-cols-5 gap-3 p-4 bg-muted rounded-lg hover:bg-muted/80 transition-colors cursor-pointer">
                      <div>
                        <p className="font-medium">{district.name}</p>
                        <p className="text-xs text-muted-foreground">{district.population.toLocaleString()} people</p>
                      </div>
                      <div>
                        <p className={`font-bold ${getRiskColor(district.riskScore)}`}>
                          {(district.riskScore * 100).toFixed(0)}%
                        </p>
                        <p className="text-xs text-muted-foreground">Risk Score</p>
                      </div>
                      <div>
                        <Badge className={getRiskBadge(district.riskScore)} variant="outline">
                          {district.outbreaks} outbreaks
                        </Badge>
                      </div>
                      <div>
                        <span className={`text-sm font-medium ${
                          district.trend.startsWith('+') ? 'text-warning' : 'text-success'
                        }`}>
                          {district.trend}
                        </span>
                        <p className="text-xs text-muted-foreground">30-day trend</p>
                      </div>
                      <div>
                        <Button variant="outline" size="sm">View Details</Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Resource Allocation Tool */}
            <Card className="gov-card">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Shield className="h-5 w-5 text-accent" />
                  <span>Resource Allocation & Gap Analysis</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid sm:grid-cols-2 gap-4">
                  {Object.entries(resourceAllocation).map(([resource, data]) => (
                    <div key={resource} className="p-4 bg-muted rounded-lg">
                      <div className="flex items-center justify-between mb-3">
                        <p className="font-medium capitalize">
                          {resource.replace(/([A-Z])/g, ' $1')}
                        </p>
                        <Badge className={data.gap > 0 ? 'status-warning' : 'status-good'}>
                          {data.gap > 0 ? `Gap: ${data.gap.toLocaleString()}` : 'Adequate'}
                        </Badge>
                      </div>
                      <div className="space-y-1 text-sm">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Allocated:</span>
                          <span className="font-medium">{data.allocated.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Required:</span>
                          <span className="font-medium">{data.required.toLocaleString()}</span>
                        </div>
                      </div>
                      <div className="w-full bg-border rounded-full h-2 mt-3">
                        <div 
                          className={`h-2 rounded-full ${data.gap > 0 ? 'bg-warning' : 'bg-success'}`}
                          style={{ width: `${(data.allocated / data.required) * 100}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* ML Predictions */}
            <Card className="gov-card border-secondary/20">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2 text-secondary">
                  <Brain className="h-5 w-5" />
                  <span>ML Predictions</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {mlPredictions.map((prediction, index) => (
                  <div key={index} className="p-4 bg-secondary-light border border-secondary/20 rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <p className="font-medium">{prediction.district}</p>
                      <Badge className="status-warning">
                        {prediction.outbreakProbability}%
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground mb-2">
                      Outbreak probability in {prediction.timeframe}
                    </p>
                    <div className="space-y-1">
                      <p className="text-xs font-medium">Key Factors:</p>
                      {prediction.primaryFactors.map((factor, idx) => (
                        <div key={idx} className="flex items-center text-xs">
                          <div className="w-1.5 h-1.5 bg-secondary rounded-full mr-2" />
                          {factor}
                        </div>
                      ))}
                    </div>
                    <div className="flex items-center justify-between mt-3 text-xs">
                      <span className="text-muted-foreground">Confidence:</span>
                      <span className="font-medium">{prediction.confidence}%</span>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Historical Trends Alert */}
            <Card className="gov-card border-warning/20">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2 text-warning">
                  <TrendingUp className="h-5 w-5" />
                  <span>Trend Alerts</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="p-3 bg-warning-light border border-warning/20 rounded-lg">
                  <p className="font-medium text-sm">Seasonal Pattern Alert</p>
                  <p className="text-xs text-muted-foreground">Cholera cases increasing 25% faster than historical average</p>
                  <p className="text-xs text-warning font-medium mt-1">Monsoon period</p>
                </div>
                <div className="p-3 bg-accent-light border border-accent/20 rounded-lg">
                  <p className="font-medium text-sm">Resource Depletion</p>
                  <p className="text-xs text-muted-foreground">ORS kits running low in 3 high-risk districts</p>
                  <p className="text-xs text-accent font-medium mt-1">Requires immediate action</p>
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card className="gov-card">
              <CardHeader>
                <CardTitle>Executive Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button 
                  className="w-full btn-government"
                  onClick={() => {
                    console.log('ML Prediction button clicked from State Dashboard');
                    navigate('/ml-prediction');
                  }}
                >
                  <Brain className="h-4 w-4 mr-2" />
                  ML Outbreak Prediction
                </Button>
                <Button className="w-full btn-secondary-gov">
                  <FileText className="h-4 w-4 mr-2" />
                  Generate State Report
                </Button>
                <Button className="w-full btn-secondary-gov">
                  <Shield className="h-4 w-4 mr-2" />
                  Resource Reallocation
                </Button>
                <Button variant="outline" className="w-full">
                  <Users className="h-4 w-4 mr-2" />
                  Audit Trail
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StateDashboard;