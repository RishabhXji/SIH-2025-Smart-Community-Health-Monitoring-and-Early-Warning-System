import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  MapPin, 
  Heart, 
  TrendingUp,
  AlertTriangle,
  Users,
  Shield,
  LogOut,
  Map,
  BarChart3,
  Activity,
  Brain
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const DistrictDashboard = () => {
  const navigate = useNavigate();

  const districtSummary = {
    totalPopulation: 284750,
    activeOutbreaks: 2,
    highRiskVillages: 8,
    rrtsDeployed: 3,
    resourcesDeployed: 89,
    casesLastWeek: 234
  };

  const villageRiskData = [
    { name: 'Rampur', population: 2847, riskLevel: 'High', activeCases: 12, waterQuality: 'Poor' },
    { name: 'Kolkata', population: 3421, riskLevel: 'Medium', activeCases: 5, waterQuality: 'Fair' },
    { name: 'Madanpur', population: 1876, riskLevel: 'Low', activeCases: 2, waterQuality: 'Good' },
    { name: 'Sitapur', population: 2134, riskLevel: 'Medium', activeCases: 7, waterQuality: 'Fair' },
  ];

  const resourceStatus = {
    orsKits: { available: 2340, required: 3000, percentage: 78 },
    chlorineTablets: { available: 4500, required: 5000, percentage: 90 },
    doctors: { available: 45, required: 60, percentage: 75 },
    nurses: { available: 120, required: 150, percentage: 80 }
  };

  const getRiskColor = (level: string) => {
    switch (level) {
      case 'High': return 'status-critical';
      case 'Medium': return 'status-warning';
      case 'Low': return 'status-good';
      default: return 'status-good';
    }
  };

  return (
    <div className="min-h-screen bg-dashboard">
      {/* Header */}
      <header className="bg-gradient-government text-white shadow-government">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <MapPin className="h-8 w-8" />
              <div>
                <h1 className="text-xl font-bold">District Dashboard</h1>
                <p className="text-sm text-white/80">Sadar District Health Administration</p>
              </div>
            </div>
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => navigate('/')}
              className="border-white/30 text-white hover:bg-white/20"
            >
              <LogOut className="h-4 w-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-6">
        {/* KPI Cards */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-6">
          <div className="kpi-card">
            <div className="kpi-number">{(districtSummary.totalPopulation / 1000).toFixed(0)}K</div>
            <p className="text-sm text-muted-foreground">Population</p>
          </div>
          <div className="kpi-card">
            <div className="kpi-number text-destructive">{districtSummary.activeOutbreaks}</div>
            <p className="text-sm text-muted-foreground">Active Outbreaks</p>
          </div>
          <div className="kpi-card">
            <div className="kpi-number text-warning">{districtSummary.highRiskVillages}</div>
            <p className="text-sm text-muted-foreground">High Risk Villages</p>
          </div>
          <div className="kpi-card">
            <div className="kpi-number text-secondary">{districtSummary.rrtsDeployed}</div>
            <p className="text-sm text-muted-foreground">RRTs Deployed</p>
          </div>
          <div className="kpi-card">
            <div className="kpi-number">{districtSummary.resourcesDeployed}%</div>
            <p className="text-sm text-muted-foreground">Resources</p>
          </div>
          <div className="kpi-card">
            <div className="kpi-number">{districtSummary.casesLastWeek}</div>
            <p className="text-sm text-muted-foreground">Cases (7-day)</p>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* GIS Map Placeholder */}
            <Card className="gov-card">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Map className="h-5 w-5 text-primary" />
                  <span>District Risk Map</span>
                </CardTitle>
                <CardDescription>Village-level color-coded outbreak risk assessment</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-64 bg-gradient-subtle rounded-lg flex items-center justify-center border-2 border-dashed border-border">
                  <div className="text-center">
                    <Map className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                    <p className="text-muted-foreground">Interactive GIS Map</p>
                    <p className="text-sm text-muted-foreground">Click villages for detailed metrics</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Village Risk Assessment */}
            <Card className="gov-card">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <BarChart3 className="h-5 w-5 text-secondary" />
                  <span>Village Risk Assessment</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {villageRiskData.map((village, index) => (
                    <div key={index} className="grid grid-cols-2 md:grid-cols-5 gap-3 p-4 bg-muted rounded-lg hover:bg-muted/80 transition-colors cursor-pointer">
                      <div>
                        <p className="font-medium">{village.name}</p>
                        <p className="text-xs text-muted-foreground">{village.population.toLocaleString()} people</p>
                      </div>
                      <div>
                        <Badge className={getRiskColor(village.riskLevel)}>
                          {village.riskLevel} Risk
                        </Badge>
                      </div>
                      <div>
                        <p className="font-medium">{village.activeCases}</p>
                        <p className="text-xs text-muted-foreground">Active Cases</p>
                      </div>
                      <div>
                        <Badge variant="outline" className="text-xs">{village.waterQuality}</Badge>
                        <p className="text-xs text-muted-foreground mt-1">Water Quality</p>
                      </div>
                      <div>
                        <Button variant="outline" size="sm">View Details</Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Resource Availability */}
            <Card className="gov-card">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Shield className="h-5 w-5 text-accent" />
                  <span>Resource Availability</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid sm:grid-cols-2 gap-4">
                  {Object.entries(resourceStatus).map(([key, resource]) => (
                    <div key={key} className="p-4 bg-muted rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <p className="font-medium capitalize">{key.replace(/([A-Z])/g, ' $1')}</p>
                        <Badge className={resource.percentage >= 80 ? 'status-good' : resource.percentage >= 60 ? 'status-warning' : 'status-critical'}>
                          {resource.percentage}%
                        </Badge>
                      </div>
                      <div className="flex items-center justify-between text-sm text-muted-foreground">
                        <span>{resource.available.toLocaleString()} available</span>
                        <span>{resource.required.toLocaleString()} required</span>
                      </div>
                      <div className="w-full bg-border rounded-full h-2 mt-2">
                        <div 
                          className={`h-2 rounded-full ${resource.percentage >= 80 ? 'bg-success' : resource.percentage >= 60 ? 'bg-warning' : 'bg-destructive'}`}
                          style={{ width: `${resource.percentage}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Critical Alerts */}
            <Card className="gov-card border-destructive/20">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2 text-destructive">
                  <AlertTriangle className="h-5 w-5" />
                  <span>Critical Alerts</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="p-3 bg-destructive-foreground border border-destructive/20 rounded-lg">
                  <p className="font-medium text-sm text-destructive">Outbreak Alert</p>
                  <p className="text-xs text-muted-foreground">Cholera outbreak in Rampur village - 12 confirmed cases</p>
                  <p className="text-xs text-destructive font-medium mt-1">1 hour ago</p>
                </div>
                <div className="p-3 bg-warning-light border border-warning/20 rounded-lg">
                  <p className="font-medium text-sm">Water Contamination</p>
                  <p className="text-xs text-muted-foreground">Multiple villages reporting high turbidity levels</p>
                  <p className="text-xs text-warning font-medium mt-1">3 hours ago</p>
                </div>
              </CardContent>
            </Card>

            {/* RRT Deployment */}
            <Card className="gov-card">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Users className="h-5 w-5 text-secondary" />
                  <span>RRT Status</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between p-3 bg-secondary-light rounded-lg">
                  <div>
                    <p className="font-medium text-sm">Team Alpha</p>
                    <p className="text-xs text-muted-foreground">Rampur Village</p>
                  </div>
                  <Badge className="status-good">Active</Badge>
                </div>
                <div className="flex items-center justify-between p-3 bg-secondary-light rounded-lg">
                  <div>
                    <p className="font-medium text-sm">Team Beta</p>
                    <p className="text-xs text-muted-foreground">Sitapur Village</p>
                  </div>
                  <Badge className="status-good">Active</Badge>
                </div>
                <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
                  <div>
                    <p className="font-medium text-sm">Team Gamma</p>
                    <p className="text-xs text-muted-foreground">On Standby</p>
                  </div>
                  <Badge variant="outline">Ready</Badge>
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card className="gov-card">
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button 
                  className="w-full btn-government"
                  onClick={() => {
                    console.log('ML Prediction button clicked from District Dashboard');
                    navigate('/ml-prediction');
                  }}
                >
                  <Brain className="h-4 w-4 mr-2" />
                  ML Outbreak Prediction
                </Button>
                <Button className="w-full btn-secondary-gov">
                  <AlertTriangle className="h-4 w-4 mr-2" />
                  Deploy RRT
                </Button>
                <Button className="w-full btn-secondary-gov">
                  <Activity className="h-4 w-4 mr-2" />
                  Generate Report
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DistrictDashboard;