import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  Users,
  Building2,
  MapPin,
  Globe,
  Phone,
  Mail,
  AlertTriangle,
  Shield,
  Heart,
  Droplets,
  Brain,
  Search,
  Bell,
  Menu,
  ChevronRight,
  Activity,
  TrendingUp,
  Database,
  Zap,
  Award,
  Calendar,
  FileText,
  ExternalLink
} from 'lucide-react';
import MLPredictionSection from '@/components/MLPredictionSection';
import MergedVillageReportsSection from '@/components/MergedVillageReportsSection';
import { useNavigate } from 'react-router-dom';

const Home = () => {
  const navigate = useNavigate();
  const [language, setLanguage] = useState<'en' | 'hi'>('en');
  const [currentSlide, setCurrentSlide] = useState(0);

  const heroImages = [
    {
      url: "https://images.unsplash.com/photo-1559827260-dc66d52bef19?w=1200&h=600&fit=crop",
      title: "Advanced Water Quality Monitoring",
      subtitle: "Real-time surveillance across 50,000+ water sources nationwide"
    },
    {
      url: "https://images.unsplash.com/photo-1584464491033-06628f3a6b7b?w=1200&h=600&fit=crop",
      title: "AI-Powered Disease Prevention",
      subtitle: "Machine learning algorithms predict outbreaks 7 days in advance"
    },
    {
      url: "https://images.unsplash.com/photo-1576091160399-112ba8d25d1f?w=1200&h=600&fit=crop",
      title: "Community Health Empowerment",
      subtitle: "Connecting 2 million ASHA workers through digital health platforms"
    },
    {
      url: "https://images.unsplash.com/photo-1559757148-5c350d0d3c56?w=1200&h=600&fit=crop",
      title: "National Health Security",
      subtitle: "Protecting India's 1.4 billion citizens from waterborne diseases"
    }
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % heroImages.length);
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  const content = {
    en: {
      title: "Smart Health Surveillance & Early Warning System",
      subtitle: "National Mission for Waterborne Disease Prevention & Control",
      tagline: "Government of India | Ministry of Health & Family Welfare"
    },
    hi: {
      title: "स्मार्ट स्वास्थ्य निगरानी और प्रारंभिक चेतावनी प्रणाली",
      subtitle: "जल जनित रोग रोकथाम और नियंत्रण के लिए राष्ट्रीय मिशन",
      tagline: "भारत सरकार | स्वास्थ्य और परिवार कल्याण मंत्रालय"
    }
  };

  const roles = [
    {
      title: "ASHA Workers",
      subtitle: "Community Health Surveillance",
      description: "Ground-level health monitoring and reporting",
      icon: Users,
      role: "asha",
      count: "2.1M+",
      features: [
        "Real-time symptom reporting",
        "Digital health records",
        "GPS-enabled field surveys",
        "Multilingual interface",
        "Offline data sync"
      ]
    },
    {
      title: "Primary Health Centers",
      subtitle: "Clinical Data Management",
      description: "Healthcare facility management and coordination",
      icon: Building2,
      role: "phc",
      count: "25,000+",
      features: [
        "Patient flow analytics",
        "Lab integration systems",
        "Resource optimization",
        "Quality assurance tools",
        "Performance dashboards"
      ]
    },
    {
      title: "District Health Officers",
      subtitle: "Regional Command & Control",
      description: "District-level health administration oversight",
      icon: MapPin,
      role: "district",
      count: "700+",
      features: [
        "GIS mapping & risk zones",
        "Resource allocation tools",
        "Multi-village analytics",
        "Emergency response coordination",
        "Policy implementation tracking"
      ]
    },
    {
      title: "State/National Authority",
      subtitle: "Strategic Health Intelligence",
      description: "High-level policy and resource planning",
      icon: Globe,
      role: "state",
      count: "36",
      features: [
        "National health indicators",
        "Predictive modeling suite",
        "Cross-state comparisons",
        "Budget optimization tools",
        "International reporting"
      ]
    }
  ];

  const achievements = [
    {
      icon: Award,
      number: "99.7%",
      label: "System Uptime",
      description: "Mission-critical reliability"
    },
    {
      icon: Activity,
      number: "47%",
      label: "Outbreak Reduction",
      description: "Since system deployment"
    },
    {
      icon: Database,
      number: "50M+",
      label: "Data Points",
      description: "Processed daily"
    },
    {
      icon: Zap,
      number: "3.2s",
      label: "Alert Response",
      description: "Average notification time"
    }
  ];

  const govLinks = [
    { name: "Digital India", url: "#" },
    { name: "MyGov Portal", url: "#" },
    { name: "Aarogya Setu", url: "#" },
    { name: "National Health Portal", url: "#" },
    { name: "ICMR Guidelines", url: "#" },
    { name: "WHO Protocols", url: "#" }
  ];

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Government Header Bar */}
      <div className="bg-orange-600 text-white py-1">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between text-xs">
            <div className="flex items-center space-x-4">
              <span>🇮🇳 भारत सरकार • Government of India</span>
              <span>•</span>
              <span>स्वास्थ्य मंत्रालय • Ministry of Health</span>
            </div>
            <div className="flex items-center space-x-3">
              <a href="#" className="hover:underline">Skip to main content</a>
              <span>|</span>
              <a href="#" className="hover:underline">Screen Reader</a>
              <span>|</span>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setLanguage(language === 'en' ? 'hi' : 'en')}
                className="text-white hover:bg-orange-700 text-xs h-6 px-2"
              >
                {language === 'en' ? 'हिन्दी' : 'English'}
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Navigation Header */}
      <header className="bg-white border-b-4 border-blue-800 shadow-lg">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between py-4">
            {/* Logo Section */}
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-3">
                <img
                  src="https://upload.wikimedia.org/wikipedia/commons/5/55/Emblem_of_India.svg"
                  alt="Government of India"
                  className="h-12 w-12"
                />
                <div className="border-l-2 border-gray-300 pl-3">
                  <h1 className="text-xl font-bold text-blue-900">SHSEWS</h1>
                  <p className="text-xs text-gray-600 uppercase tracking-wide">Health Surveillance System</p>
                </div>
              </div>
            </div>

            {/* Navigation Menu */}
            <nav className="hidden lg:flex items-center space-x-8">
              <a href="#" className="text-gray-700 hover:text-blue-800 font-medium transition-colors">Home</a>
              <a href="#" className="text-gray-700 hover:text-blue-800 font-medium transition-colors">Dashboards</a>
              <a href="#" className="text-gray-700 hover:text-blue-800 font-medium transition-colors">Reports</a>
              <a href="#" className="text-gray-700 hover:text-blue-800 font-medium transition-colors">Guidelines</a>
              <a href="#" className="text-gray-700 hover:text-blue-800 font-medium transition-colors">Support</a>
            </nav>

            {/* Action Buttons */}
            <div className="flex items-center space-x-3">
              <Button variant="outline" size="sm" className="hidden md:flex items-center space-x-2">
                <Search className="h-4 w-4" />
                <span>Search</span>
              </Button>
              <Button variant="outline" size="sm" className="hidden md:flex items-center space-x-2">
                <Bell className="h-4 w-4" />
                <span>Alerts</span>
              </Button>
              <Button size="sm" className="bg-blue-800 hover:bg-blue-900">
                Login
              </Button>
              <Button variant="ghost" size="sm" className="lg:hidden">
                <Menu className="h-5 w-5" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section with Auto-sliding Images */}
      <section className="relative h-[500px] overflow-hidden">
        {heroImages.map((image, index) => (
          <div
            key={index}
            className={`absolute inset-0 transition-opacity duration-1000 ${
              index === currentSlide ? 'opacity-100' : 'opacity-0'
            }`}
            style={{
              backgroundImage: `linear-gradient(rgba(0, 0, 0, 0.4), rgba(0, 0, 0, 0.6)), url(${image.url})`,
              backgroundSize: 'cover',
              backgroundPosition: 'center',
            }}
          >
            <div className="container mx-auto px-4 h-full flex items-center">
              <div className="text-white max-w-2xl">
                <Badge variant="secondary" className="mb-4 bg-white/20 text-white border-white/30">
                  Ministry of Health & Family Welfare
                </Badge>
                <h1 className="text-5xl md:text-6xl font-bold mb-4 leading-tight">
                  {image.title}
                </h1>
                <p className="text-xl md:text-2xl mb-8 opacity-90">
                  {image.subtitle}
                </p>
                <div className="flex flex-col sm:flex-row gap-4">
                  <Button size="lg" className="bg-blue-600 hover:bg-blue-700 text-lg px-8 py-3">
                    Access Dashboard
                    <ChevronRight className="ml-2 h-5 w-5" />
                  </Button>
                  <Button variant="outline" size="lg" className="border-white text-[#333] hover:bg-white/20 text-lg px-8 py-3">
                    View Documentation
                    <ExternalLink className="ml-2 h-5 w-5" />
                  </Button>
                </div>
              </div>
            </div>
          </div>
        ))}

        {/* Slide Indicators */}
        <div className="absolute bottom-6 left-1/2 transform -translate-x-1/2 flex space-x-2">
          {heroImages.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentSlide(index)}
              className={`w-3 h-3 rounded-full transition-all ${
                index === currentSlide ? 'bg-white' : 'bg-white/50'
              }`}
            />
          ))}
        </div>
      </section>

      {/* Key Achievements Bar */}
      <section className="bg-blue-800 text-white py-8">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-6">
            {achievements.map((achievement, index) => (
              <div key={index} className="text-center">
                <div className="flex items-center justify-center mb-2">
                  <achievement.icon className="h-8 w-8 mr-2" />
                  <span className="text-3xl font-bold">{achievement.number}</span>
                </div>
                <h3 className="font-semibold mb-1">{achievement.label}</h3>
                <p className="text-sm text-blue-200">{achievement.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Mission Statement */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4 text-center">
          <Badge variant="outline" className="mb-4 border-blue-200 text-blue-800">
            National Health Mission 2024
          </Badge>
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            {content[language].title}
          </h2>
          <p className="text-xl md:text-2xl text-gray-600 mb-8 max-w-4xl mx-auto leading-relaxed">
            {content[language].subtitle}
          </p>
          <div className="flex items-center justify-center space-x-8 text-sm text-gray-500">
            <div className="flex items-center space-x-2">
              <Calendar className="h-4 w-4" />
              <span>Launched: January 2024</span>
            </div>
            <div className="flex items-center space-x-2">
              <FileText className="h-4 w-4" />
              <span>Policy No: MoHFW/2024/SHSEWS</span>
            </div>
            <div className="flex items-center space-x-2">
              <TrendingUp className="h-4 w-4" />
              <span>Phase: National Rollout</span>
            </div>
          </div>
        </div>
      </section>

      {/* ML Prediction Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <MLPredictionSection />
        </div>
      </section>

      {/* Merged Village AI Reports Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <MergedVillageReportsSection />
        </div>
      </section>

      {/* Role Access Dashboard */}
      <section className="py-16 bg-gradient-to-br from-blue-50 to-indigo-100">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Stakeholder Access Portals
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Secure, role-based access to health surveillance tools and real-time data analytics
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {roles.map((role, index) => (
              <Card key={index} className="group hover:shadow-2xl transition-all duration-300 cursor-pointer border-0 shadow-lg">
                <CardHeader className="text-center pb-2">
                  <div className="mx-auto w-16 h-16 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                    <role.icon className="h-8 w-8 text-white" />
                  </div>
                  <CardTitle className="text-lg mb-1">{role.title}</CardTitle>
                  <p className="text-sm text-blue-600 font-medium">{role.subtitle}</p>
                  <Badge variant="secondary" className="mt-2 bg-blue-100 text-blue-800">
                    {role.count} Active Users
                  </Badge>
                </CardHeader>
                <CardContent className="pt-0">
                  <p className="text-sm text-gray-600 mb-4 text-center">{role.description}</p>
                  <ul className="space-y-2 text-xs text-gray-500">
                    {role.features.map((feature, idx) => (
                      <li key={idx} className="flex items-center space-x-2">
                        <div className="w-1.5 h-1.5 bg-blue-500 rounded-full" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                  <Button
                    className="w-full mt-4 bg-blue-600 hover:bg-blue-700"
                    onClick={() => navigate(`/login/${role.role}`)}
                  >
                    Access Portal
                    <ChevronRight className="ml-2 h-4 w-4" />
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Government Footer */}
      <footer className="bg-gray-900 text-white">
        <div className="container mx-auto px-4 py-12">
          <div className="grid md:grid-cols-4 gap-8">
            {/* Government Identity */}
            <div>
              <div className="flex items-center space-x-3 mb-4">
                <img
                  src="https://upload.wikimedia.org/wikipedia/commons/5/55/Emblem_of_India.svg"
                  alt="Government of India"
                  className="h-8 w-8 invert"
                />
                <div>
                  <h3 className="font-bold">SHSEWS</h3>
                  <p className="text-xs text-gray-400">भारत सरकार</p>
                </div>
              </div>
              <p className="text-sm text-gray-300 mb-4">
                Smart Health Surveillance & Early Warning System - A flagship initiative under Digital India and Ayushman Bharat.
              </p>
              <div className="text-xs text-gray-400">
                <p>© 2024 Government of India</p>
                <p>All Rights Reserved</p>
              </div>
            </div>

            {/* Quick Links */}
            <div>
              <h3 className="font-bold mb-4">Government Links</h3>
              <ul className="space-y-2 text-sm">
                {govLinks.map((link, index) => (
                  <li key={index}>
                    <a href={link.url} className="text-gray-300 hover:text-white transition-colors flex items-center space-x-1">
                      <span>{link.name}</span>
                      <ExternalLink className="h-3 w-3" />
                    </a>
                  </li>
                ))}
              </ul>
            </div>

            {/* Contact Information */}
            <div>
              <h3 className="font-bold mb-4">Contact & Support</h3>
              <div className="space-y-3 text-sm">
                <div className="flex items-center space-x-2">
                  <Phone className="h-4 w-4 text-green-400" />
                  <div>
                    <p className="font-medium">National Helpline</p>
                    <p className="text-gray-300">1075 (Toll Free)</p>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <Mail className="h-4 w-4 text-blue-400" />
                  <div>
                    <p className="font-medium">Email Support</p>
                    <p className="text-gray-300">support@shsews.gov.in</p>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <Globe className="h-4 w-4 text-orange-400" />
                  <div>
                    <p className="font-medium">Emergency Response</p>
                    <p className="text-gray-300">24/7 Monitoring Center</p>
                  </div>
                </div>
              </div>
            </div>

            {/* System Status */}
            <div>
              <h3 className="font-bold mb-4">System Status</h3>
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-300">Platform Health</span>
                  <Badge className="bg-green-600 text-white border-0">Operational</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-300">Data Processing</span>
                  <Badge className="bg-green-600 text-white border-0">Real-time</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-300">Alert System</span>
                  <Badge className="bg-green-600 text-white border-0">Active</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-300">API Services</span>
                  <Badge className="bg-green-600 text-white border-0">99.7% Uptime</Badge>
                </div>
              </div>
            </div>
          </div>

          {/* Footer Bottom */}
          <div className="border-t border-gray-700 mt-8 pt-8 text-center text-sm text-gray-400">
            <div className="flex flex-col md:flex-row justify-between items-center space-y-2 md:space-y-0">
              <p>Website designed and developed under Digital India initiative</p>
              <div className="flex items-center space-x-4">
                <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
                <span>|</span>
                <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
                <span>|</span>
                <a href="#" className="hover:text-white transition-colors">Accessibility</a>
                <span>|</span>
                <a href="#" className="hover:text-white transition-colors">RTI</a>
              </div>
            </div>
            <p className="mt-2">Last updated: {new Date().toLocaleDateString('en-IN')}</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Home;