import React, { useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { ArrowLeft, Heart, Lock, User } from 'lucide-react';

const Login = () => {
  const { role } = useParams<{ role: string }>();
  const navigate = useNavigate();
  const [credentials, setCredentials] = useState({ username: '', password: '' });

  const roleInfo = {
    asha: { title: 'ASHA Worker Login', description: 'Community Health Worker Access' },
    phc: { title: 'PHC Staff Login', description: 'Primary Health Center Access' },
    district: { title: 'District Official Login', description: 'District Administration Access' },
    state: { title: 'State Authority Login', description: 'State/National Level Access' }
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    // For demo purposes, navigate directly to dashboard
    navigate(`/dashboard/${role}`);
  };

  const currentRole = roleInfo[role as keyof typeof roleInfo];

  return (
    <div className="min-h-screen bg-gradient-subtle flex items-center justify-center px-4">
      <div className="w-full max-w-md">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="mx-auto mb-4 h-16 w-16 bg-gradient-government rounded-lg flex items-center justify-center">
            <Heart className="h-10 w-10 text-white" />
          </div>
          <h1 className="text-2xl font-bold text-foreground">SHSEWS Portal</h1>
          <p className="text-muted-foreground">Smart Health Surveillance System</p>
        </div>

        {/* Login Card */}
        <Card className="gov-card-elevated">
          <CardHeader className="text-center">
            <CardTitle className="text-xl">{currentRole?.title}</CardTitle>
            <CardDescription>{currentRole?.description}</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <Label htmlFor="username" className="flex items-center space-x-2 mb-2">
                  <User className="h-4 w-4" />
                  <span>Username</span>
                </Label>
                <Input
                  id="username"
                  type="text"
                  placeholder="Enter your username"
                  value={credentials.username}
                  onChange={(e) => setCredentials(prev => ({ ...prev, username: e.target.value }))}
                  required
                />
              </div>
              <div>
                <Label htmlFor="password" className="flex items-center space-x-2 mb-2">
                  <Lock className="h-4 w-4" />
                  <span>Password</span>
                </Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="Enter your password"
                  value={credentials.password}
                  onChange={(e) => setCredentials(prev => ({ ...prev, password: e.target.value }))}
                  required
                />
              </div>
              <Button type="submit" className="w-full btn-government">
                Access Dashboard
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* Back Button */}
        <div className="text-center mt-6">
          <Button 
            variant="ghost" 
            onClick={() => navigate('/')}
            className="text-muted-foreground hover:text-foreground"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Home
          </Button>
        </div>
      </div>
    </div>
  );
};

export default Login;