import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  Building2, 
  Heart, 
  Users, 
  TrendingUp,
  AlertTriangle,
  CheckCircle,
  ClipboardList,
  LogOut,
  BarChart3,
  MapPin
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const PHCDashboard = () => {
  const navigate = useNavigate();

  const blockSummary = {
    totalPatients: 1247,
    dailyAdmissions: 23,
    orsDispensed: 156,
    activeASHAs: 45,
    reportsValidated: 38,
    pendingValidation: 7
  };

  const waterQualityData = [
    { village: 'Rampur', ph: 7.2, turbidity: 'High', chlorine: 'Low', status: 'Warning' },
    { village: 'Kolkata', ph: 6.8, turbidity: 'Normal', chlorine: 'Normal', status: 'Good' },
    { village: 'Madanpur', ph: 8.1, turbidity: 'Normal', chlorine: 'Normal', status: 'Good' },
    { village: 'Sitapur', ph: 6.5, turbidity: 'Medium', chlorine: 'Low', status: 'Warning' }
  ];

  const diseaseData = [
    { disease: 'Diarrhea', cases: 45, trend: '+12%', severity: 'warning' },
    { disease: 'Cholera', cases: 3, trend: '-5%', severity: 'critical' },
    { disease: 'Hepatitis A', cases: 8, trend: '+8%', severity: 'warning' },
    { disease: 'Typhoid', cases: 12, trend: '-15%', severity: 'good' }
  ];

  return (
    <div className="min-h-screen bg-dashboard">
      {/* Header */}
      <header className="bg-gradient-government text-white shadow-government">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Building2 className="h-8 w-8" />
              <div>
                <h1 className="text-xl font-bold">PHC Dashboard</h1>
                <p className="text-sm text-white/80">Primary Health Center - Sadar Block</p>
              </div>
            </div>
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => navigate('/')}
              className="border-white/30 text-white hover:bg-white/20"
            >
              <LogOut className="h-4 w-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-6">
        {/* KPI Cards */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-6">
          <div className="kpi-card">
            <div className="kpi-number">{blockSummary.totalPatients.toLocaleString()}</div>
            <p className="text-sm text-muted-foreground">Total Patients</p>
          </div>
          <div className="kpi-card">
            <div className="kpi-number text-warning">{blockSummary.dailyAdmissions}</div>
            <p className="text-sm text-muted-foreground">Daily Admissions</p>
          </div>
          <div className="kpi-card">
            <div className="kpi-number text-secondary">{blockSummary.orsDispensed}</div>
            <p className="text-sm text-muted-foreground">ORS Dispensed</p>
          </div>
          <div className="kpi-card">
            <div className="kpi-number">{blockSummary.activeASHAs}</div>
            <p className="text-sm text-muted-foreground">Active ASHAs</p>
          </div>
          <div className="kpi-card">
            <div className="kpi-number text-success">{blockSummary.reportsValidated}</div>
            <p className="text-sm text-muted-foreground">Reports Validated</p>
          </div>
          <div className="kpi-card">
            <div className="kpi-number text-warning">{blockSummary.pendingValidation}</div>
            <p className="text-sm text-muted-foreground">Pending</p>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Disease Trends */}
            <Card className="gov-card">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <BarChart3 className="h-5 w-5 text-primary" />
                  <span>Block-Level Disease Trends</span>
                </CardTitle>
                <CardDescription>7-day rolling trends for waterborne diseases</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {diseaseData.map((disease, index) => (
                    <div key={index} className="flex items-center justify-between p-4 bg-muted rounded-lg">
                      <div className="flex items-center space-x-4">
                        <div className="w-3 h-3 bg-primary rounded-full" />
                        <div>
                          <p className="font-medium">{disease.disease}</p>
                          <p className="text-sm text-muted-foreground">{disease.cases} active cases</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-3">
                        <span className={`text-sm font-medium ${
                          disease.severity === 'critical' ? 'text-destructive' :
                          disease.severity === 'warning' ? 'text-warning' : 'text-success'
                        }`}>
                          {disease.trend}
                        </span>
                        <Badge className={`status-${disease.severity}`}>
                          {disease.severity === 'critical' ? 'Critical' : 
                           disease.severity === 'warning' ? 'Watch' : 'Normal'}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Water Quality Status */}
            <Card className="gov-card">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <MapPin className="h-5 w-5 text-secondary" />
                  <span>Village Water Quality Status</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {waterQualityData.map((village, index) => (
                    <div key={index} className="grid grid-cols-2 md:grid-cols-5 gap-3 p-4 bg-muted rounded-lg">
                      <div>
                        <p className="font-medium">{village.village}</p>
                        <p className="text-xs text-muted-foreground">Village</p>
                      </div>
                      <div>
                        <p className="font-medium">{village.ph}</p>
                        <p className="text-xs text-muted-foreground">pH Level</p>
                      </div>
                      <div>
                        <Badge variant="outline" className="text-xs">{village.turbidity}</Badge>
                        <p className="text-xs text-muted-foreground mt-1">Turbidity</p>
                      </div>
                      <div>
                        <Badge variant="outline" className="text-xs">{village.chlorine}</Badge>
                        <p className="text-xs text-muted-foreground mt-1">Chlorine</p>
                      </div>
                      <div>
                        <Badge className={`status-${village.status === 'Good' ? 'good' : 'warning'}`}>
                          {village.status}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* ASHA Performance */}
            <Card className="gov-card">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Users className="h-5 w-5 text-primary" />
                  <span>ASHA Performance</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between p-3 bg-success-light rounded-lg">
                  <div>
                    <p className="font-medium text-sm">Reports Completed</p>
                    <p className="text-xs text-muted-foreground">This week</p>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-success">85%</p>
                    <CheckCircle className="h-4 w-4 text-success ml-auto" />
                  </div>
                </div>
                <div className="flex items-center justify-between p-3 bg-warning-light rounded-lg">
                  <div>
                    <p className="font-medium text-sm">Pending Tasks</p>
                    <p className="text-xs text-muted-foreground">Requires attention</p>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-warning">7</p>
                    <AlertTriangle className="h-4 w-4 text-warning ml-auto" />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Alerts Panel */}
            <Card className="gov-card border-warning/20">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2 text-warning">
                  <AlertTriangle className="h-5 w-5" />
                  <span>Active Alerts</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="p-3 bg-destructive-foreground border border-destructive/20 rounded-lg">
                  <p className="font-medium text-sm text-destructive">Critical Water Source</p>
                  <p className="text-xs text-muted-foreground">Rampur village hand pump contaminated</p>
                  <p className="text-xs text-destructive font-medium mt-1">2 hours ago</p>
                </div>
                <div className="p-3 bg-warning-light border border-warning/20 rounded-lg">
                  <p className="font-medium text-sm">Lab Results Pending</p>
                  <p className="text-xs text-muted-foreground">5 water samples awaiting analysis</p>
                  <p className="text-xs text-warning font-medium mt-1">1 day ago</p>
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card className="gov-card">
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button className="w-full btn-government">
                  <ClipboardList className="h-4 w-4 mr-2" />
                  Patient Log Entry
                </Button>
                <Button className="w-full btn-secondary-gov">
                  <TrendingUp className="h-4 w-4 mr-2" />
                  Validate ASHA Reports
                </Button>
                <Button variant="outline" className="w-full">
                  <Heart className="h-4 w-4 mr-2" />
                  Upload Lab Results
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PHCDashboard;