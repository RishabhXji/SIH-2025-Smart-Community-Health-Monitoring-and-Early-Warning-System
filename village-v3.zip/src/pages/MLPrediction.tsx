import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { 
  ArrowLeft, 
  Calendar as CalendarIcon,
  Brain,
  TrendingUp,
  Droplets,
  Thermometer,
  AlertTriangle,
  Shield,
  Activity,
  BarChart3,
  Download,
  Gauge
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { format } from 'date-fns';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import {
  LineChart,
  Line,
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend
} from 'recharts';

interface PredictionData {
  date: string;
  village: string;
  outbreak_probability: number;
  risk_level: string;
  top_contributing_factors: any[];
  feature_importance: any;
  confidence_score: number;
}

interface HealthData {
  date: string;
  temperature: number;
  rainfall_1d: number;
  rainfall_7d_sum: number;
  contamination_avg: number;
  water_ph_avg: number;
  water_turbidity_avg: number;
  asha_symptoms_diarrhea: number;
  asha_symptoms_vomiting: number;
  clinic_visits_diarrhea: number;
  clinic_admissions: number;
  exposure_score: number;
  syndromic_score: number;
  vulnerability_score: number;
  true_cases: number;
  reported_cases: number;
}

const MLPrediction = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [selectedDate, setSelectedDate] = useState<Date>(new Date('2025-01-03'));
  const [prediction, setPrediction] = useState<PredictionData | null>(null);
  const [healthTrendData, setHealthTrendData] = useState<HealthData[]>([]);
  const [loading, setLoading] = useState(false);
  const [village] = useState('Village_B'); // Default village

  console.log('ML Prediction page loaded'); // Debug log

  // Fetch 7-day trend data for visualizations
  const fetchHealthTrendData = async (targetDate: Date) => {
    try {
      const endDate = format(targetDate, 'yyyy-MM-dd');
      const startDate = format(new Date(targetDate.getTime() - 7 * 24 * 60 * 60 * 1000), 'yyyy-MM-dd');
      
      const { data, error } = await supabase
        .from('health_surveillance')
        .select('*')
        .eq('area', village)
        .gte('date', startDate)
        .lte('date', endDate)
        .order('date', { ascending: true });
      
      if (error) throw error;
      setHealthTrendData(data || []);
    } catch (error) {
      console.error('Error fetching trend data:', error);
    }
  };

  // Run ML prediction using your LightGBM model and Excel data
  const runPrediction = async () => {
    if (!selectedDate) {
      toast({
        title: "Date Required",
        description: "Please select a date for prediction",
        variant: "destructive"
      });
      return;
    }

    setLoading(true);
    console.log('Running ML prediction for date:', format(selectedDate, 'yyyy-MM-dd'));
    
    try {
      const { data, error } = await supabase.functions.invoke('ml-prediction', {
        body: {
          date: format(selectedDate, 'yyyy-MM-dd'),
          village: village
        }
      });

      console.log('ML prediction response:', data);

      if (error) {
        console.error('ML prediction error:', error);
        throw error;
      }
      
      if (data.success) {
        setPrediction(data.prediction);
        await fetchHealthTrendData(selectedDate);
        toast({
          title: "Prediction Complete",
          description: `Risk Level: ${data.prediction.risk_level.toUpperCase()} - Probability: ${(data.prediction.outbreak_probability * 100).toFixed(1)}%`,
          variant: data.prediction.risk_level === 'high' || data.prediction.risk_level === 'critical' ? "destructive" : "default"
        });
      } else {
        throw new Error(data.error || 'Failed to run prediction');
      }
    } catch (error) {
      console.error('Error running prediction:', error);
      toast({
        title: "Prediction Failed",
        description: error instanceof Error ? error.message : "Failed to run prediction. Please check console for details.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const getRiskColor = (riskLevel: string) => {
    switch (riskLevel) {
      case 'critical': return 'status-critical';
      case 'high': return 'status-critical';
      case 'medium': return 'status-warning';
      case 'low': return 'status-good';
      default: return 'status-good';
    }
  };

  const getRiskDescription = (probability: number) => {
    if (probability > 0.5) return 'Outbreak Likely - Immediate Action Required';
    if (probability >= 0.4) return 'Outbreak Possible - Enhanced Monitoring';
    if (probability >= 0.35) return 'Very Less Chance - Monitor Closely';
    return 'Safe - Continue Regular Monitoring';
  };

  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8'];

  return (
    <div className="min-h-screen bg-dashboard">
      {/* Header */}
      <header className="bg-gradient-government text-white shadow-government">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Button
                variant="outline"
                size="sm"
                onClick={() => navigate(-1)}
                className="border-white/30 text-white hover:bg-white/20"
              >
                <ArrowLeft className="h-4 w-4" />
              </Button>
              <Brain className="h-8 w-8" />
              <div>
                <h1 className="text-xl font-bold">ML Outbreak Prediction</h1>
                <p className="text-sm text-white/80">AI-Powered Disease Outbreak Forecasting System</p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <Button variant="outline" size="sm" className="border-white/30 text-white hover:bg-white/20">
                <Download className="h-4 w-4 mr-2" />
                Export Report
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-6">
        {/* Prediction Controls */}
        <Card className="gov-card mb-6">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <CalendarIcon className="h-5 w-5 text-primary" />
              <span>Prediction Configuration</span>
            </CardTitle>
            <CardDescription>Select a date to generate outbreak probability prediction</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center space-x-4">
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className="w-64 justify-start text-left font-normal"
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {selectedDate ? format(selectedDate, 'PPP') : 'Pick a date for prediction'}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={selectedDate}
                    onSelect={setSelectedDate}
                    initialFocus
                    className="pointer-events-auto"
                  />
                </PopoverContent>
              </Popover>
              <Button 
                onClick={runPrediction} 
                disabled={!selectedDate || loading}
                className="btn-government"
              >
                {loading ? 'Processing ML Model...' : 'Run LightGBM Prediction'}
              </Button>
              <div className="text-sm text-muted-foreground">
                <p>Using: lgbm_model.pkl</p>
                <p>Data: Village_B_2.xls</p>
                <p className="text-warning font-medium">Available dates: Jan 1-5, 2025</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {prediction && (
          <>
            {/* Prediction Results */}
            <div className="grid lg:grid-cols-3 gap-6 mb-6">
              {/* Main Gauge */}
              <Card className="gov-card-elevated">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Gauge className="h-5 w-5 text-secondary" />
                    <span>Outbreak Probability</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="text-center">
                  <div className="mb-4">
                    <div className="text-6xl font-bold mb-2" style={{color: `hsl(var(--${prediction.outbreak_probability > 0.5 ? 'destructive' : prediction.outbreak_probability > 0.35 ? 'warning' : 'success'}))`}}>
                      {(prediction.outbreak_probability * 100).toFixed(1)}%
                    </div>
                    <Badge className={getRiskColor(prediction.risk_level)} variant="outline">
                      {prediction.risk_level.toUpperCase()}
                    </Badge>
                  </div>
                  <p className="text-sm text-muted-foreground mb-4">
                    {getRiskDescription(prediction.outbreak_probability)}
                  </p>
                  <div className="flex items-center justify-between text-xs text-muted-foreground">
                    <span>Confidence: {(prediction.confidence_score * 100).toFixed(1)}%</span>
                    <span>7-day horizon</span>
                  </div>
                </CardContent>
              </Card>

              {/* Risk Interpretation */}
              <Card className="gov-card">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <AlertTriangle className="h-5 w-5 text-warning" />
                    <span>Risk Assessment</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="grid grid-cols-4 gap-2 text-center text-xs">
                    <div className="p-2 bg-success/10 rounded">
                      <div className="font-medium text-success">&lt;35%</div>
                      <div>Safe</div>
                    </div>
                    <div className="p-2 bg-warning/10 rounded">
                      <div className="font-medium text-warning">35-40%</div>
                      <div>Monitor</div>
                    </div>
                    <div className="p-2 bg-warning/10 rounded">
                      <div className="font-medium text-warning">40-50%</div>
                      <div>Possible</div>
                    </div>
                    <div className="p-2 bg-destructive/10 rounded">
                      <div className="font-medium text-destructive">&gt;50%</div>
                      <div>Likely</div>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <h4 className="font-medium text-sm">Recommended Actions:</h4>
                    {prediction.outbreak_probability > 0.5 ? (
                      <ul className="text-xs space-y-1 text-destructive">
                        <li>• Deploy RRT immediately</li>
                        <li>• Increase water quality monitoring</li>
                        <li>• Alert community health workers</li>
                        <li>• Prepare emergency supplies</li>
                      </ul>
                    ) : prediction.outbreak_probability > 0.35 ? (
                      <ul className="text-xs space-y-1 text-warning">
                        <li>• Enhanced surveillance</li>
                        <li>• Check water sources</li>
                        <li>• Review ASHA reports</li>
                        <li>• Monitor symptoms closely</li>
                      </ul>
                    ) : (
                      <ul className="text-xs space-y-1 text-success">
                        <li>• Continue routine monitoring</li>
                        <li>• Maintain preventive measures</li>
                        <li>• Regular data collection</li>
                      </ul>
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* Top Contributing Factors */}
              <Card className="gov-card">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <TrendingUp className="h-5 w-5 text-accent" />
                    <span>Key Risk Factors</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {prediction.top_contributing_factors.slice(0, 5).map((factor, index) => (
                      <div key={index} className="flex items-center justify-between">
                        <span className="text-sm font-medium">{factor.factor}</span>
                        <div className="flex items-center space-x-2">
                          <div className="w-16 bg-muted rounded-full h-2">
                            <div 
                              className="h-2 rounded-full bg-primary"
                              style={{ width: `${parseFloat(factor.percentage)}%` }}
                            />
                          </div>
                          <span className="text-xs text-muted-foreground w-10">
                            {factor.percentage}%
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Environmental Trends */}
            <div className="grid lg:grid-cols-2 gap-6 mb-6">
              {/* Temperature & Rainfall Trends */}
              <Card className="gov-card">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Thermometer className="h-5 w-5 text-destructive" />
                    <span>Environmental Factors (7-day trend)</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <LineChart data={healthTrendData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis 
                        dataKey="date" 
                        tickFormatter={(value) => format(new Date(value), 'MM/dd')}
                      />
                      <YAxis yAxisId="temp" orientation="left" />
                      <YAxis yAxisId="rain" orientation="right" />
                      <Tooltip 
                        labelFormatter={(value) => format(new Date(value), 'PPP')}
                      />
                      <Line 
                        yAxisId="temp"
                        type="monotone" 
                        dataKey="temperature" 
                        stroke="hsl(var(--destructive))" 
                        strokeWidth={2}
                        name="Temperature (°C)"
                      />
                      <Line 
                        yAxisId="rain"
                        type="monotone" 
                        dataKey="rainfall_1d" 
                        stroke="hsl(var(--primary))" 
                        strokeWidth={2}
                        name="Rainfall (mm)"
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              {/* Water Quality Trends */}
              <Card className="gov-card">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Droplets className="h-5 w-5 text-primary" />
                    <span>Water Quality Indicators</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <LineChart data={healthTrendData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis 
                        dataKey="date" 
                        tickFormatter={(value) => format(new Date(value), 'MM/dd')}
                      />
                      <YAxis yAxisId="ph" orientation="left" domain={[0, 14]} />
                      <YAxis yAxisId="turbidity" orientation="right" />
                      <Tooltip 
                        labelFormatter={(value) => format(new Date(value), 'PPP')}
                      />
                      <Line 
                        yAxisId="ph"
                        type="monotone" 
                        dataKey="water_ph_avg" 
                        stroke="hsl(var(--secondary))" 
                        strokeWidth={2}
                        name="pH Level"
                      />
                      <Line 
                        yAxisId="turbidity"
                        type="monotone" 
                        dataKey="water_turbidity_avg" 
                        stroke="hsl(var(--warning))" 
                        strokeWidth={2}
                        name="Turbidity (NTU)"
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>

            {/* Health & Cases Trends */}
            <div className="grid lg:grid-cols-2 gap-6 mb-6">
              {/* Cases Comparison */}
              <Card className="gov-card">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Activity className="h-5 w-5 text-secondary" />
                    <span>Case Reports Trend</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <AreaChart data={healthTrendData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis 
                        dataKey="date" 
                        tickFormatter={(value) => format(new Date(value), 'MM/dd')}
                      />
                      <YAxis />
                      <Tooltip 
                        labelFormatter={(value) => format(new Date(value), 'PPP')}
                      />
                      <Area 
                        type="monotone" 
                        dataKey="reported_cases" 
                        stackId="1"
                        stroke="hsl(var(--primary))" 
                        fill="hsl(var(--primary) / 0.3)"
                        name="Reported Cases"
                      />
                      <Area 
                        type="monotone" 
                        dataKey="true_cases" 
                        stackId="2"
                        stroke="hsl(var(--destructive))" 
                        fill="hsl(var(--destructive) / 0.3)"
                        name="Confirmed Cases"
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              {/* Symptom Distribution */}
              <Card className="gov-card">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <BarChart3 className="h-5 w-5 text-accent" />
                    <span>Symptom Reports (Current)</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={healthTrendData.slice(-1)}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="date" hide />
                      <YAxis />
                      <Tooltip />
                      <Bar 
                        dataKey="asha_symptoms_diarrhea" 
                        fill="hsl(var(--primary))"
                        name="Diarrhea"
                      />
                      <Bar 
                        dataKey="asha_symptoms_vomiting" 
                        fill="hsl(var(--secondary))"
                        name="Vomiting"
                      />
                      <Bar 
                        dataKey="clinic_visits_diarrhea" 
                        fill="hsl(var(--accent))"
                        name="Clinic Visits"
                      />
                      <Bar 
                        dataKey="clinic_admissions" 
                        fill="hsl(var(--destructive))"
                        name="Admissions"
                      />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>

            {/* Risk Scores */}
            <Card className="gov-card">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Shield className="h-5 w-5 text-success" />
                  <span>Risk Score Analysis</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={400}>
                  <LineChart data={healthTrendData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis 
                      dataKey="date" 
                      tickFormatter={(value) => format(new Date(value), 'MM/dd')}
                    />
                    <YAxis />
                    <Tooltip 
                      labelFormatter={(value) => format(new Date(value), 'PPP')}
                    />
                    <Legend />
                    <Line 
                      type="monotone" 
                      dataKey="exposure_score" 
                      stroke={COLORS[0]} 
                      strokeWidth={2}
                      name="Exposure Score"
                    />
                    <Line 
                      type="monotone" 
                      dataKey="syndromic_score" 
                      stroke={COLORS[1]} 
                      strokeWidth={2}
                      name="Syndromic Score"
                    />
                    <Line 
                      type="monotone" 
                      dataKey="vulnerability_score" 
                      stroke={COLORS[2]} 
                      strokeWidth={2}
                      name="Vulnerability Score"
                    />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </>
        )}

        {!prediction && (
          <Card className="gov-card">
            <CardContent className="flex flex-col items-center justify-center py-16">
              <Brain className="h-16 w-16 text-primary mb-4 pulse-government" />
              <h3 className="text-xl font-semibold mb-2">ML Prediction System Ready</h3>
              <p className="text-muted-foreground text-center max-w-md mb-4">
                Select a date above and click "Run LightGBM Prediction" to generate comprehensive outbreak probability analysis using your trained model.
              </p>
              <div className="grid grid-cols-2 gap-4 text-sm text-muted-foreground">
                <div className="text-center p-4 bg-muted rounded-lg">
                  <Shield className="h-8 w-8 mx-auto mb-2 text-primary" />
                  <strong>Model:</strong> lgbm_model.pkl
                </div>
                <div className="text-center p-4 bg-muted rounded-lg">
                  <BarChart3 className="h-8 w-8 mx-auto mb-2 text-secondary" />
                  <strong>Data:</strong> Village_B_2.xls
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
};

export default MLPrediction;