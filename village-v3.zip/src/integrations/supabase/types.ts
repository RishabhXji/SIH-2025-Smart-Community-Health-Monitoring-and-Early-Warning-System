export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "13.0.5"
  }
  public: {
    Tables: {
      alerts: {
        Row: {
          acknowledged_at: string | null
          acknowledged_by: string | null
          alert_type: string
          assigned_to: string | null
          created_at: string
          description: string
          escalated_at: string | null
          escalated_to: Database["public"]["Enums"]["user_role"] | null
          id: string
          resolution_notes: string | null
          resolved_at: string | null
          resolved_by: string | null
          severity: Database["public"]["Enums"]["alert_severity"]
          status: Database["public"]["Enums"]["alert_status"] | null
          threshold_exceeded: Json | null
          title: string
          triggered_by_prediction: boolean | null
          updated_at: string
          village: string
        }
        Insert: {
          acknowledged_at?: string | null
          acknowledged_by?: string | null
          alert_type: string
          assigned_to?: string | null
          created_at?: string
          description: string
          escalated_at?: string | null
          escalated_to?: Database["public"]["Enums"]["user_role"] | null
          id?: string
          resolution_notes?: string | null
          resolved_at?: string | null
          resolved_by?: string | null
          severity: Database["public"]["Enums"]["alert_severity"]
          status?: Database["public"]["Enums"]["alert_status"] | null
          threshold_exceeded?: Json | null
          title: string
          triggered_by_prediction?: boolean | null
          updated_at?: string
          village: string
        }
        Update: {
          acknowledged_at?: string | null
          acknowledged_by?: string | null
          alert_type?: string
          assigned_to?: string | null
          created_at?: string
          description?: string
          escalated_at?: string | null
          escalated_to?: Database["public"]["Enums"]["user_role"] | null
          id?: string
          resolution_notes?: string | null
          resolved_at?: string | null
          resolved_by?: string | null
          severity?: Database["public"]["Enums"]["alert_severity"]
          status?: Database["public"]["Enums"]["alert_status"] | null
          threshold_exceeded?: Json | null
          title?: string
          triggered_by_prediction?: boolean | null
          updated_at?: string
          village?: string
        }
        Relationships: []
      }
      asha_reports: {
        Row: {
          created_at: string
          gps_coordinates: unknown | null
          households_affected: number | null
          households_visited: number | null
          id: string
          notes: string | null
          photo_urls: string[] | null
          report_date: string
          reporter_id: string
          symptoms_diarrhea: number | null
          symptoms_fever: number | null
          symptoms_jaundice: number | null
          symptoms_vomiting: number | null
          validated_at: string | null
          validated_by: string | null
          village: string
        }
        Insert: {
          created_at?: string
          gps_coordinates?: unknown | null
          households_affected?: number | null
          households_visited?: number | null
          id?: string
          notes?: string | null
          photo_urls?: string[] | null
          report_date: string
          reporter_id: string
          symptoms_diarrhea?: number | null
          symptoms_fever?: number | null
          symptoms_jaundice?: number | null
          symptoms_vomiting?: number | null
          validated_at?: string | null
          validated_by?: string | null
          village: string
        }
        Update: {
          created_at?: string
          gps_coordinates?: unknown | null
          households_affected?: number | null
          households_visited?: number | null
          id?: string
          notes?: string | null
          photo_urls?: string[] | null
          report_date?: string
          reporter_id?: string
          symptoms_diarrhea?: number | null
          symptoms_fever?: number | null
          symptoms_jaundice?: number | null
          symptoms_vomiting?: number | null
          validated_at?: string | null
          validated_by?: string | null
          village?: string
        }
        Relationships: []
      }
      audit_logs: {
        Row: {
          action: string
          created_at: string
          id: string
          ip_address: unknown | null
          new_values: Json | null
          old_values: Json | null
          record_id: string | null
          table_name: string | null
          user_agent: string | null
          user_id: string | null
        }
        Insert: {
          action: string
          created_at?: string
          id?: string
          ip_address?: unknown | null
          new_values?: Json | null
          old_values?: Json | null
          record_id?: string | null
          table_name?: string | null
          user_agent?: string | null
          user_id?: string | null
        }
        Update: {
          action?: string
          created_at?: string
          id?: string
          ip_address?: unknown | null
          new_values?: Json | null
          old_values?: Json | null
          record_id?: string | null
          table_name?: string | null
          user_agent?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
      clinic_reports: {
        Row: {
          admissions: number | null
          cholera_cases: number | null
          clinic_name: string
          created_at: string
          diarrhea_cases: number | null
          hepatitis_cases: number | null
          id: string
          lab_results_uploaded: boolean | null
          ors_dispensed: number | null
          report_date: string
          reporter_id: string
          tests_conducted: number | null
          total_visits: number | null
          typhoid_cases: number | null
        }
        Insert: {
          admissions?: number | null
          cholera_cases?: number | null
          clinic_name: string
          created_at?: string
          diarrhea_cases?: number | null
          hepatitis_cases?: number | null
          id?: string
          lab_results_uploaded?: boolean | null
          ors_dispensed?: number | null
          report_date: string
          reporter_id: string
          tests_conducted?: number | null
          total_visits?: number | null
          typhoid_cases?: number | null
        }
        Update: {
          admissions?: number | null
          cholera_cases?: number | null
          clinic_name?: string
          created_at?: string
          diarrhea_cases?: number | null
          hepatitis_cases?: number | null
          id?: string
          lab_results_uploaded?: boolean | null
          ors_dispensed?: number | null
          report_date?: string
          reporter_id?: string
          tests_conducted?: number | null
          total_visits?: number | null
          typhoid_cases?: number | null
        }
        Relationships: []
      }
      environmental_data: {
        Row: {
          created_at: string
          date: string
          flood_risk_level: number | null
          humidity: number | null
          id: string
          rainfall_24h: number | null
          temperature_avg: number | null
          village: string
          weather_alerts: string[] | null
        }
        Insert: {
          created_at?: string
          date: string
          flood_risk_level?: number | null
          humidity?: number | null
          id?: string
          rainfall_24h?: number | null
          temperature_avg?: number | null
          village: string
          weather_alerts?: string[] | null
        }
        Update: {
          created_at?: string
          date?: string
          flood_risk_level?: number | null
          humidity?: number | null
          id?: string
          rainfall_24h?: number | null
          temperature_avg?: number | null
          village?: string
          weather_alerts?: string[] | null
        }
        Relationships: []
      }
      health_surveillance: {
        Row: {
          area: string
          asha_households_affected: number | null
          asha_symptoms_diarrhea: number | null
          asha_symptoms_vomiting: number | null
          asha_visits_performed: number | null
          cases_7d_sum: number | null
          clinic_admissions: number | null
          clinic_ors_dispensed: number | null
          clinic_tests_conducted: number | null
          clinic_visits_diarrhea: number | null
          contamination_avg: number | null
          created_at: string
          date: string
          event_cases: number | null
          exposure_score: number | null
          id: string
          outbreak_label_h7: number | null
          population: number
          rainfall_1d: number | null
          rainfall_7d_sum: number | null
          reported_cases: number | null
          spatial_score: number | null
          spillover_cases: number | null
          syndromic_score: number | null
          temp_7d_avg: number | null
          temp_score: number | null
          temperature: number | null
          true_cases: number | null
          updated_at: string
          vulnerability_score: number | null
          water_contamination_sources: number | null
          water_ph_avg: number | null
          water_sources_red_pct: number | null
          water_turbidity_avg: number | null
        }
        Insert: {
          area: string
          asha_households_affected?: number | null
          asha_symptoms_diarrhea?: number | null
          asha_symptoms_vomiting?: number | null
          asha_visits_performed?: number | null
          cases_7d_sum?: number | null
          clinic_admissions?: number | null
          clinic_ors_dispensed?: number | null
          clinic_tests_conducted?: number | null
          clinic_visits_diarrhea?: number | null
          contamination_avg?: number | null
          created_at?: string
          date: string
          event_cases?: number | null
          exposure_score?: number | null
          id?: string
          outbreak_label_h7?: number | null
          population: number
          rainfall_1d?: number | null
          rainfall_7d_sum?: number | null
          reported_cases?: number | null
          spatial_score?: number | null
          spillover_cases?: number | null
          syndromic_score?: number | null
          temp_7d_avg?: number | null
          temp_score?: number | null
          temperature?: number | null
          true_cases?: number | null
          updated_at?: string
          vulnerability_score?: number | null
          water_contamination_sources?: number | null
          water_ph_avg?: number | null
          water_sources_red_pct?: number | null
          water_turbidity_avg?: number | null
        }
        Update: {
          area?: string
          asha_households_affected?: number | null
          asha_symptoms_diarrhea?: number | null
          asha_symptoms_vomiting?: number | null
          asha_visits_performed?: number | null
          cases_7d_sum?: number | null
          clinic_admissions?: number | null
          clinic_ors_dispensed?: number | null
          clinic_tests_conducted?: number | null
          clinic_visits_diarrhea?: number | null
          contamination_avg?: number | null
          created_at?: string
          date?: string
          event_cases?: number | null
          exposure_score?: number | null
          id?: string
          outbreak_label_h7?: number | null
          population?: number
          rainfall_1d?: number | null
          rainfall_7d_sum?: number | null
          reported_cases?: number | null
          spatial_score?: number | null
          spillover_cases?: number | null
          syndromic_score?: number | null
          temp_7d_avg?: number | null
          temp_score?: number | null
          temperature?: number | null
          true_cases?: number | null
          updated_at?: string
          vulnerability_score?: number | null
          water_contamination_sources?: number | null
          water_ph_avg?: number | null
          water_sources_red_pct?: number | null
          water_turbidity_avg?: number | null
        }
        Relationships: []
      }
      ml_predictions: {
        Row: {
          confidence_score: number | null
          created_at: string
          feature_importance: Json | null
          id: string
          model_version: string | null
          outbreak_probability: number
          prediction_date: string
          prediction_horizon_days: number | null
          risk_level: string
          top_contributing_factors: Json | null
          village: string
        }
        Insert: {
          confidence_score?: number | null
          created_at?: string
          feature_importance?: Json | null
          id?: string
          model_version?: string | null
          outbreak_probability: number
          prediction_date: string
          prediction_horizon_days?: number | null
          risk_level: string
          top_contributing_factors?: Json | null
          village: string
        }
        Update: {
          confidence_score?: number | null
          created_at?: string
          feature_importance?: Json | null
          id?: string
          model_version?: string | null
          outbreak_probability?: number
          prediction_date?: string
          prediction_horizon_days?: number | null
          risk_level?: string
          top_contributing_factors?: Json | null
          village?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          block: string | null
          created_at: string
          district: string | null
          full_name: string
          id: string
          phone: string | null
          role: Database["public"]["Enums"]["user_role"]
          state: string | null
          updated_at: string
          user_id: string
          village: string | null
        }
        Insert: {
          block?: string | null
          created_at?: string
          district?: string | null
          full_name: string
          id?: string
          phone?: string | null
          role: Database["public"]["Enums"]["user_role"]
          state?: string | null
          updated_at?: string
          user_id: string
          village?: string | null
        }
        Update: {
          block?: string | null
          created_at?: string
          district?: string | null
          full_name?: string
          id?: string
          phone?: string | null
          role?: Database["public"]["Enums"]["user_role"]
          state?: string | null
          updated_at?: string
          user_id?: string
          village?: string | null
        }
        Relationships: []
      }
      resources: {
        Row: {
          created_at: string
          current_stock: number
          expiry_date: string | null
          id: string
          last_restocked_date: string | null
          managed_by: string | null
          minimum_threshold: number | null
          resource_type: string
          total_available: number
          updated_at: string
          village: string
        }
        Insert: {
          created_at?: string
          current_stock?: number
          expiry_date?: string | null
          id?: string
          last_restocked_date?: string | null
          managed_by?: string | null
          minimum_threshold?: number | null
          resource_type: string
          total_available?: number
          updated_at?: string
          village: string
        }
        Update: {
          created_at?: string
          current_stock?: number
          expiry_date?: string | null
          id?: string
          last_restocked_date?: string | null
          managed_by?: string | null
          minimum_threshold?: number | null
          resource_type?: string
          total_available?: number
          updated_at?: string
          village?: string
        }
        Relationships: []
      }
      rrt_deployments: {
        Row: {
          alert_id: string | null
          completion_date: string | null
          created_at: string
          deployment_date: string
          deployment_reason: string | null
          id: string
          outcome_report: string | null
          status: string | null
          team_members: string[] | null
          village: string
        }
        Insert: {
          alert_id?: string | null
          completion_date?: string | null
          created_at?: string
          deployment_date: string
          deployment_reason?: string | null
          id?: string
          outcome_report?: string | null
          status?: string | null
          team_members?: string[] | null
          village: string
        }
        Update: {
          alert_id?: string | null
          completion_date?: string | null
          created_at?: string
          deployment_date?: string
          deployment_reason?: string | null
          id?: string
          outcome_report?: string | null
          status?: string | null
          team_members?: string[] | null
          village?: string
        }
        Relationships: [
          {
            foreignKeyName: "rrt_deployments_alert_id_fkey"
            columns: ["alert_id"]
            isOneToOne: false
            referencedRelation: "alerts"
            referencedColumns: ["id"]
          },
        ]
      }
      water_quality: {
        Row: {
          chlorine_level: number | null
          contamination_level: number | null
          created_at: string
          date: string
          id: string
          nitrates: number | null
          ph_level: number | null
          sample_location: string | null
          source_type: string | null
          sulphates: number | null
          tested_by: string | null
          turbidity: number | null
          village: string
        }
        Insert: {
          chlorine_level?: number | null
          contamination_level?: number | null
          created_at?: string
          date: string
          id?: string
          nitrates?: number | null
          ph_level?: number | null
          sample_location?: string | null
          source_type?: string | null
          sulphates?: number | null
          tested_by?: string | null
          turbidity?: number | null
          village: string
        }
        Update: {
          chlorine_level?: number | null
          contamination_level?: number | null
          created_at?: string
          date?: string
          id?: string
          nitrates?: number | null
          ph_level?: number | null
          sample_location?: string | null
          source_type?: string | null
          sulphates?: number | null
          tested_by?: string | null
          turbidity?: number | null
          village?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      get_current_user_role: {
        Args: Record<PropertyKey, never>
        Returns: string
      }
      get_user_access_level: {
        Args: Record<PropertyKey, never>
        Returns: {
          district: string
          role: string
          state: string
          village: string
        }[]
      }
    }
    Enums: {
      alert_severity: "low" | "medium" | "high" | "critical"
      alert_status: "active" | "acknowledged" | "resolved"
      user_role: "asha" | "phc" | "district" | "state"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      alert_severity: ["low", "medium", "high", "critical"],
      alert_status: ["active", "acknowledged", "resolved"],
      user_role: ["asha", "phc", "district", "state"],
    },
  },
} as const
