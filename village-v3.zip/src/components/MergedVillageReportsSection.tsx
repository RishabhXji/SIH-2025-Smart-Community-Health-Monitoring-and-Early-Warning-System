import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { MapPin, Droplets, Activity, TrendingUp, AlertTriangle, CheckCircle, Clock, Map, Navigation, Brain, BarChart3, Gauge } from 'lucide-react';
import { toast } from 'sonner';
import { LineChart, Line, AreaChart, Area, BarChart, Bar, RadialBarChart, RadialBar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Cell, PieChart, Pie } from 'recharts';

// Village historical data structure
interface VillageHistoricalData {
  date: string;
  area: string;
  population: number;
  rainfall_1d: number;
  temperature: number;
  true_cases: number;
  contamination_avg: number;
  event_cases: number;
  rainfall_7d_sum: number;
  temp_7d_avg: number;
  cases_7d_sum: number;
  reported_cases: number;
  spillover_cases: number;
  exposure_score: number;
  syndromic_score: number;
  spatial_score: number;
  vulnerability_score: number;
  temp_score: number;
  asha_symptoms_diarrhea: number;
  asha_symptoms_vomiting: number;
  asha_households_affected: number;
  asha_visits_performed: number;
  clinic_visits_diarrhea: number;
  clinic_admissions: number;
  clinic_tests_conducted: number;
  clinic_ors_dispensed: number;
  water_ph_avg: number;
  water_turbidity_avg: number;
  water_sources_red_pct: number;
  water_contamination_sources: number;
  outbreak_label_h7: number;
}

// Synthetic water quality data structure
interface WaterQualityData {
  'Village name': string;
  'Sample ID': string;
  'Longitude': string;
  'Latitude': string;
  'Fluoride (ppm)': string;
  'Total hardness (ppm)': string;
  'Calcium (ppm)': string;
  'Magnesium (ppm)': string;
  'Chloride (ppm)': string;
  'Alkalinity  (ppm)': string;
  'pH': string;
  'EC (S/cm)': string;
  'Carbonate (ppm)': string;
  'Bicarbonate (ppm)': string;
  'Nitrate (ppm)': string;
  'Sulphate (ppm)': string;
  'Chemical Health Risk Score (CHRS) ': string;
}

interface MergedVillageReport {
  villageName: string;
  historicalData: VillageHistoricalData;
  waterQualityData: WaterQualityData;
  riskLevel: 'low' | 'medium' | 'high' | 'critical';
  predictionScore: number;
  outbreakProbability: number;
  lgbmPrediction: number;
  finalWaterQualityPrediction: number;
  recommendations: string[];
  alerts: string[];
}

const MergedVillageReportsSection: React.FC = () => {
  const [currentReport, setCurrentReport] = useState<MergedVillageReport | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [reportIndex, setReportIndex] = useState(0);
  const [villageFiles, setVillageFiles] = useState<string[]>([]);
  const [waterQualityData, setWaterQualityData] = useState<WaterQualityData[]>([]);
  const [villageHistoricalData, setVillageHistoricalData] = useState<{[key: string]: VillageHistoricalData[]}>({});
  const [countdown, setCountdown] = useState(3);

  useEffect(() => {
    loadAllData();
  }, []);

  useEffect(() => {
    if (Object.keys(villageHistoricalData).length > 0 && waterQualityData.length > 0) {
      generateMergedReport();
      const interval = setInterval(() => {
        setReportIndex(prev => (prev + 1) % Object.keys(villageHistoricalData).length);
      }, 3000);

      return () => clearInterval(interval);
    }
  }, [villageHistoricalData, waterQualityData, reportIndex]);

  useEffect(() => {
    if (Object.keys(villageHistoricalData).length > 0) {
      const countdownInterval = setInterval(() => {
        setCountdown(prev => prev <= 1 ? 3 : prev - 1);
      }, 1000);

      return () => clearInterval(countdownInterval);
    }
  }, [villageHistoricalData]);

  const loadAllData = async () => {
    try {
      // Load water quality data
      const waterResponse = await fetch('/data/synthetic_water_quality_data.csv');
      const waterCsvText = await waterResponse.text();
      const waterLines = waterCsvText.trim().split('\n');
      const waterHeaders = waterLines[0].split(',');

      const waterData: WaterQualityData[] = waterLines.slice(1).map(line => {
        const values = line.split(',');
        const row: any = {};
        waterHeaders.forEach((header, index) => {
          row[header] = values[index];
        });
        return row as WaterQualityData;
      });

      setWaterQualityData(waterData);

      // Load all village files
      const villageFilesList = ['village_a.csv', 'village_b.csv', 'village_c.csv', 'village_d.csv',
                               'village_e.csv', 'village_f.csv', 'village_g.csv', 'village_h.csv',
                               'village_i.csv', 'village_j.csv', 'village_k.csv'];

      const allVillageData: {[key: string]: VillageHistoricalData[]} = {};

      for (const villageFile of villageFilesList) {
        try {
          const response = await fetch(`/data/${villageFile}`);
          const csvText = await response.text();
          const lines = csvText.trim().split('\n');
          const headers = lines[0].split(',');

          const data: VillageHistoricalData[] = lines.slice(1).map(line => {
            const values = line.split(',');
            const row: any = {};
            headers.forEach((header, index) => {
              const value = values[index];
              if (header === 'date' || header === 'area') {
                row[header] = value;
              } else {
                row[header] = parseFloat(value) || 0;
              }
            });
            return row as VillageHistoricalData;
          });

          // Get the latest data entry
          const latestData = data[data.length - 1];
          if (latestData) {
            allVillageData[villageFile.replace('.csv', '')] = data;
          }
        } catch (error) {
          console.error(`Error loading ${villageFile}:`, error);
        }
      }

      setVillageHistoricalData(allVillageData);
      setVillageFiles(Object.keys(allVillageData));
      setIsLoading(false);
    } catch (error) {
      console.error('Error loading data:', error);
      toast.error('Failed to load village data');
      setIsLoading(false);
    }
  };

  const generateMergedReport = () => {
    const villageKeys = Object.keys(villageHistoricalData);
    if (villageKeys.length === 0 || waterQualityData.length === 0) return;

    const villageKey = villageKeys[reportIndex % villageKeys.length];
    const villageData = villageHistoricalData[villageKey];
    const latestHistoricalData = villageData[villageData.length - 1];

    // Find matching water quality data (random selection for demo)
    const randomWaterQuality = waterQualityData[Math.floor(Math.random() * waterQualityData.length)];

    // Calculate ML prediction using both datasets
    const prediction = calculateMLPrediction(latestHistoricalData, randomWaterQuality);

    setCurrentReport({
      villageName: randomWaterQuality['Village name'],
      historicalData: latestHistoricalData,
      waterQualityData: randomWaterQuality,
      ...prediction
    });
  };

  const calculateMLPrediction = (historical: VillageHistoricalData, waterQuality: WaterQualityData) => {
    // LightGBM Model for Outbreak Prediction (using historical data)
    const lgbmPrediction = calculateLightGBMPrediction(historical);

    // Final Water Quality Model (using water quality data)
    const finalWaterQualityPrediction = calculateFinalWaterQualityPrediction(waterQuality);

    // Combined prediction (weighted average)
    const combinedProbability = (lgbmPrediction * 0.6 + finalWaterQualityPrediction * 0.4);
    const predictionScore = Math.round(combinedProbability * 100);

    // Determine risk level
    let riskLevel: 'low' | 'medium' | 'high' | 'critical';
    if (combinedProbability >= 0.7) riskLevel = 'critical';
    else if (combinedProbability >= 0.5) riskLevel = 'high';
    else if (combinedProbability >= 0.3) riskLevel = 'medium';
    else riskLevel = 'low';

    // Generate recommendations and alerts
    const recommendations = generateRecommendations(historical, waterQuality, riskLevel);
    const alerts = generateAlerts(historical, waterQuality, riskLevel);

    return {
      riskLevel,
      predictionScore,
      outbreakProbability: combinedProbability,
      lgbmPrediction,
      finalWaterQualityPrediction,
      recommendations,
      alerts
    };
  };

  const calculateLightGBMPrediction = (historical: VillageHistoricalData): number => {
    // LightGBM model simulation based on backend implementation
    let lgbmScore = 0;

    // Contamination factor (0-0.2)
    const contamination = historical.contamination_avg || 0;
    if (contamination > 2.0) {
      lgbmScore += Math.min(0.2, (contamination - 2.0) * 0.05);
    }

    // Water quality factors (0-0.15)
    const ph = historical.water_ph_avg || 7.0;
    const turbidity = historical.water_turbidity_avg || 0;
    const phDeviation = Math.abs(ph - 7.2);
    if (phDeviation > 1.5) {
      lgbmScore += Math.min(0.1, (phDeviation - 1.5) * 0.08);
    }
    if (turbidity > 3) {
      lgbmScore += Math.min(0.05, (turbidity - 3) * 0.02);
    }

    // Disease cases factor (0-0.25)
    const trueCases = historical.true_cases || 0;
    const reportedCases = historical.reported_cases || 0;
    const totalCases = trueCases + reportedCases * 0.3;
    if (totalCases > 15) {
      lgbmScore += Math.min(0.25, (totalCases - 15) * 0.01);
    }

    // Environmental factors (0-0.1)
    const temp = historical.temperature || 20;
    const rainfall = historical.rainfall_1d || 0;
    if (temp > 32) {
      lgbmScore += Math.min(0.05, (temp - 32) * 0.008);
    }
    if (rainfall > 5) {
      lgbmScore += Math.min(0.05, (rainfall - 5) * 0.01);
    }

    // Exposure factors (0-0.08)
    const exposure = historical.exposure_score || 0;
    const syndromic = historical.syndromic_score || 0;
    if (exposure > 3) {
      lgbmScore += Math.min(0.08, (exposure - 3) * 0.01);
    }

    // Apply sigmoid transformation
    const lgbmPrediction = 1 / (1 + Math.exp(-4 * (lgbmScore - 0.3)));
    return Math.min(0.95, Math.max(0.01, lgbmPrediction));
  };

  const calculateFinalWaterQualityPrediction = (waterQuality: WaterQualityData): number => {
    // Final water quality model simulation
    let finalScore = 0;

    // Water quality parameters
    const ph = parseFloat(waterQuality['pH']) || 7.0;
    const fluoride = parseFloat(waterQuality['Fluoride (ppm)']) || 0;
    const nitrate = parseFloat(waterQuality['Nitrate (ppm)']) || 0;
    const chloride = parseFloat(waterQuality['Chloride (ppm)']) || 0;
    const chrs = parseFloat(waterQuality['Chemical Health Risk Score (CHRS) ']) || 0;

    // Conservative contamination weighting
    const phDeviation = Math.abs(ph - 7.2);
    if (phDeviation > 2.0) {
      finalScore += Math.min(0.08, (phDeviation - 2.0) * 0.06);
    }

    // Chemical risk factors
    if (fluoride > 1.5) {
      finalScore += Math.min(0.1, (fluoride - 1.5) * 0.05);
    }
    if (nitrate > 45) {
      finalScore += Math.min(0.1, (nitrate - 45) * 0.002);
    }
    if (chloride > 1000) {
      finalScore += Math.min(0.05, (chloride - 1000) * 0.00005);
    }

    // CHRS score impact
    finalScore += chrs * 0.3;

    // Apply sigmoid transformation
    const finalPrediction = 1 / (1 + Math.exp(-3 * (finalScore - 0.25)));
    return Math.min(0.95, Math.max(0.01, finalPrediction));
  };

  const generateRecommendations = (historical: VillageHistoricalData, waterQuality: WaterQualityData, riskLevel: string): string[] => {
    const recommendations: string[] = [];

    if (riskLevel === 'critical') {
      recommendations.push('Immediate medical team deployment required');
      recommendations.push('Activate emergency water distribution');
      recommendations.push('Implement quarantine protocols');
    } else if (riskLevel === 'high') {
      recommendations.push('Increase ASHA worker monitoring frequency');
      recommendations.push('Deploy rapid testing kits');
      recommendations.push('Enhance water treatment protocols');
    } else if (riskLevel === 'medium') {
      recommendations.push('Regular health surveillance');
      recommendations.push('Water quality testing schedule');
      recommendations.push('Community health education');
    } else {
      recommendations.push('Continue routine monitoring');
      recommendations.push('Maintain current prevention measures');
    }

    // Specific recommendations based on data
    if (historical.contamination_avg > 2) {
      recommendations.push('Install additional water purification systems');
    }
    if (parseFloat(waterQuality['Fluoride (ppm)']) > 1.5) {
      recommendations.push('Implement defluoridation treatment');
    }
    if (historical.asha_symptoms_diarrhea > 15) {
      recommendations.push('Increase ORS distribution');
    }

    return recommendations.slice(0, 4);
  };

  const generateAlerts = (historical: VillageHistoricalData, waterQuality: WaterQualityData, riskLevel: string): string[] => {
    const alerts: string[] = [];

    if (historical.outbreak_label_h7 > 0.5) {
      alerts.push('Active outbreak detected in area');
    }
    if (historical.true_cases > 20) {
      alerts.push('High disease case count reported');
    }
    if (historical.contamination_avg > 3) {
      alerts.push('Critical water contamination levels');
    }
    if (parseFloat(waterQuality['pH']) < 6.5 || parseFloat(waterQuality['pH']) > 8.5) {
      alerts.push('Water pH outside safe range');
    }
    if (parseFloat(waterQuality['Nitrate (ppm)']) > 45) {
      alerts.push('Nitrate levels exceed WHO guidelines');
    }

    return alerts;
  };

  const getSpeedometerData = () => {
    if (!currentReport) return [];

    return [{
      name: 'Risk',
      value: currentReport.predictionScore,
      fill: currentReport.riskLevel === 'critical' ? '#ef4444' :
            currentReport.riskLevel === 'high' ? '#f97316' :
            currentReport.riskLevel === 'medium' ? '#eab308' : '#22c55e'
    }];
  };

  const getTrendData = () => {
    if (!currentReport) return [];

    const villageKey = Object.keys(villageHistoricalData)[reportIndex % Object.keys(villageHistoricalData).length];
    const data = villageHistoricalData[villageKey];

    return data.slice(-7).map((item, index) => ({
      day: `Day ${index + 1}`,
      cases: item.true_cases,
      reportedCases: item.reported_cases,
      symptoms: item.asha_symptoms_diarrhea + item.asha_symptoms_vomiting,
      contamination: item.contamination_avg * 10,
      temperature: item.temperature,
      rainfall: item.rainfall_1d
    }));
  };

  const getWaterQualityTrends = () => {
    if (!currentReport) return [];

    const villageKey = Object.keys(villageHistoricalData)[reportIndex % Object.keys(villageHistoricalData).length];
    const data = villageHistoricalData[villageKey];

    return data.slice(-7).map((item, index) => ({
      day: `Day ${index + 1}`,
      ph: item.water_ph_avg,
      turbidity: item.water_turbidity_avg,
      contamination: item.contamination_avg,
      redSources: item.water_sources_red_pct
    }));
  };

  const getEnvironmentalTrends = () => {
    if (!currentReport) return [];

    const villageKey = Object.keys(villageHistoricalData)[reportIndex % Object.keys(villageHistoricalData).length];
    const data = villageHistoricalData[villageKey];

    return data.slice(-7).map((item, index) => ({
      day: `Day ${index + 1}`,
      temperature: item.temperature,
      rainfall: item.rainfall_1d,
      tempAvg: item.temp_7d_avg,
      rainfallSum: item.rainfall_7d_sum,
      humidity: 60 + Math.random() * 20 // Simulated humidity
    }));
  };

  const getHealthSystemTrends = () => {
    if (!currentReport) return [];

    const villageKey = Object.keys(villageHistoricalData)[reportIndex % Object.keys(villageHistoricalData).length];
    const data = villageHistoricalData[villageKey];

    return data.slice(-7).map((item, index) => ({
      day: `Day ${index + 1}`,
      ashaVisits: item.asha_visits_performed,
      clinicVisits: item.clinic_visits_diarrhea,
      testsconducted: item.clinic_tests_conducted,
      orsDispensed: item.clinic_ors_dispensed,
      admissions: item.clinic_admissions
    }));
  };

  const getHealthMetrics = () => {
    if (!currentReport) return [];

    return [
      { name: 'ASHA Visits', value: currentReport.historicalData.asha_visits_performed, color: '#3b82f6' },
      { name: 'Clinic Visits', value: currentReport.historicalData.clinic_visits_diarrhea, color: '#ef4444' },
      { name: 'Tests Conducted', value: currentReport.historicalData.clinic_tests_conducted, color: '#10b981' },
      { name: 'ORS Dispensed', value: currentReport.historicalData.clinic_ors_dispensed, color: '#f59e0b' }
    ];
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <Card className="gov-card">
          <CardContent className="p-6">
            <div className="flex items-center justify-center space-x-2">
              <Activity className="h-5 w-5 animate-spin" />
              <span>Loading integrated ML prediction system...</span>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!currentReport) {
    return null;
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="text-center">
        <h2 className="text-3xl font-bold mb-2">AI-Powered Village Health Intelligence</h2>
        <p className="text-muted-foreground">
          Integrated ML predictions combining historical data and real-time water quality analysis
        </p>
        <div className="flex items-center justify-center mt-2 space-x-2">
          <Clock className="h-4 w-4" />
          <span className="text-sm">Next prediction in {countdown}s</span>
        </div>
      </div>

      {/* Main Prediction Card */}
      <Card className="gov-card border-l-4 border-l-accent">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center space-x-2">
              <Brain className="h-5 w-5 text-accent" />
              <span>{currentReport.villageName}</span>
            </CardTitle>
            <Badge variant={currentReport.riskLevel === 'critical' ? 'destructive' : 'default'} className="uppercase">
              {currentReport.riskLevel} Risk
            </Badge>
          </div>
          <p className="text-sm text-muted-foreground">
            Sample ID: {currentReport.waterQualityData['Sample ID']} •
            Population: {currentReport.historicalData.population.toLocaleString()} •
            Location: {parseFloat(currentReport.waterQualityData['Latitude']).toFixed(3)}°, {parseFloat(currentReport.waterQualityData['Longitude']).toFixed(3)}°
          </p>
        </CardHeader>
        <CardContent>
          {/* Dual Model Predictions */}
          <div className="grid lg:grid-cols-3 gap-6 mb-6">
            {/* LightGBM Model */}
            <Card className="bg-gradient-to-br from-green-50 to-emerald-100">
              <CardHeader className="text-center pb-2">
                <CardTitle className="flex items-center justify-center space-x-2 text-lg">
                  <Brain className="h-5 w-5 text-green-600" />
                  <span>LightGBM Model</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-0">
                <div className="relative h-32">
                  <ResponsiveContainer width="100%" height="100%">
                    <RadialBarChart
                      cx="50%"
                      cy="70%"
                      innerRadius="60%"
                      outerRadius="90%"
                      data={[{
                        name: 'LightGBM',
                        value: Math.round((currentReport.lgbmPrediction || 0) * 100),
                        fill: '#10b981'
                      }]}
                      startAngle={180}
                      endAngle={0}
                    >
                      <RadialBar dataKey="value" cornerRadius={10} fill="#10b981" />
                    </RadialBarChart>
                  </ResponsiveContainer>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-gray-800">
                        {Math.round((currentReport.lgbmPrediction || 0) * 100)}%
                      </div>
                      <div className="text-xs text-gray-600">Outbreak Risk</div>
                    </div>
                  </div>
                </div>
                <div className="mt-2 text-center text-sm text-gray-600">
                  Historical Data Analysis
                </div>
              </CardContent>
            </Card>

            {/* Final Water Quality Model */}
            <Card className="bg-gradient-to-br from-blue-50 to-cyan-100">
              <CardHeader className="text-center pb-2">
                <CardTitle className="flex items-center justify-center space-x-2 text-lg">
                  <Droplets className="h-5 w-5 text-blue-600" />
                  <span>Final Water Quality</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-0">
                <div className="relative h-32">
                  <ResponsiveContainer width="100%" height="100%">
                    <RadialBarChart
                      cx="50%"
                      cy="70%"
                      innerRadius="60%"
                      outerRadius="90%"
                      data={[{
                        name: 'Final',
                        value: Math.round((currentReport.finalWaterQualityPrediction || 0) * 100),
                        fill: '#3b82f6'
                      }]}
                      startAngle={180}
                      endAngle={0}
                    >
                      <RadialBar dataKey="value" cornerRadius={10} fill="#3b82f6" />
                    </RadialBarChart>
                  </ResponsiveContainer>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-gray-800">
                        {Math.round((currentReport.finalWaterQualityPrediction || 0) * 100)}%
                      </div>
                      <div className="text-xs text-gray-600">Water Risk</div>
                    </div>
                  </div>
                </div>
                <div className="mt-2 text-center text-sm text-gray-600">
                  Chemical Analysis
                </div>
              </CardContent>
            </Card>

            {/* Advanced Speedometer with Pendulum */}
            <Card className="bg-gradient-to-br from-slate-50 to-gray-100">
              <CardHeader className="text-center pb-2">
                <CardTitle className="flex items-center justify-center space-x-2 text-lg">
                  <Gauge className="h-5 w-5 text-gray-700" />
                  <span>Risk Meter</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-0">
                <div className="relative h-40">
                  {/* Speedometer Background */}
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="relative w-32 h-32">
                      {/* Outer Ring */}
                      <div className="absolute inset-0 rounded-full border-8 border-gray-300"></div>

                      {/* Risk Zones */}
                      <div className="absolute inset-2 rounded-full" style={{
                        background: `conic-gradient(
                          from 225deg,
                          #22c55e 0deg 45deg,
                          #eab308 45deg 90deg,
                          #f97316 90deg 135deg,
                          #ef4444 135deg 180deg
                        )`
                      }}></div>

                      {/* Inner Circle */}
                      <div className="absolute inset-6 rounded-full bg-white border-4 border-gray-400"></div>

                      {/* Needle/Pendulum */}
                      <div
                        className="absolute top-1/2 left-1/2 w-0.5 h-12 bg-gray-800 origin-bottom transform -translate-x-1/2 transition-transform duration-1000 ease-out"
                        style={{
                          transform: `translateX(-50%) rotate(${-90 + (currentReport.predictionScore || 0) * 1.8}deg)`,
                          transformOrigin: 'bottom center'
                        }}
                      ></div>

                      {/* Center Dot */}
                      <div className="absolute top-1/2 left-1/2 w-3 h-3 bg-gray-800 rounded-full transform -translate-x-1/2 -translate-y-1/2"></div>
                    </div>
                  </div>

                  {/* Percentage Display */}
                  <div className="absolute bottom-2 left-1/2 transform -translate-x-1/2">
                    <div className="text-center">
                      <div className="text-xs text-gray-500">Risk Level</div>
                      <div className="text-lg font-bold text-gray-800">
                        {currentReport.predictionScore || 0}%
                      </div>
                    </div>
                  </div>

                  {/* Scale Labels */}
                  <div className="absolute bottom-8 left-2 text-xs text-green-600 font-semibold">0%</div>
                  <div className="absolute bottom-8 right-2 text-xs text-red-600 font-semibold">100%</div>
                  <div className="absolute top-8 left-1/2 transform -translate-x-1/2 text-xs text-gray-600 font-semibold">50%</div>
                </div>
                <div className="mt-2 text-center text-sm text-gray-600">
                  Ensemble AI Prediction
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Comprehensive Trend Charts */}
          <div className="grid lg:grid-cols-2 gap-6 mt-6">
            {/* Disease Cases Trends */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="flex items-center space-x-2 text-lg">
                  <Activity className="h-5 w-5 text-red-600" />
                  <span>Disease Cases Trends</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-0">
                <div className="h-48">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={getTrendData()}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="day" tick={{ fontSize: 10 }} />
                      <YAxis tick={{ fontSize: 10 }} />
                      <Tooltip />
                      <Legend />
                      <Area
                        type="monotone"
                        dataKey="cases"
                        stackId="1"
                        stroke="#ef4444"
                        fill="#ef4444"
                        fillOpacity={0.3}
                        name="True Cases"
                      />
                      <Area
                        type="monotone"
                        dataKey="reportedCases"
                        stackId="1"
                        stroke="#f97316"
                        fill="#f97316"
                        fillOpacity={0.3}
                        name="Reported Cases"
                      />
                      <Area
                        type="monotone"
                        dataKey="symptoms"
                        stackId="2"
                        stroke="#8b5cf6"
                        fill="#8b5cf6"
                        fillOpacity={0.2}
                        name="ASHA Symptoms"
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            {/* Water Quality Trends */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="flex items-center space-x-2 text-lg">
                  <Droplets className="h-5 w-5 text-blue-600" />
                  <span>Water Quality Trends</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-0">
                <div className="h-48">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={getWaterQualityTrends()}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="day" tick={{ fontSize: 10 }} />
                      <YAxis tick={{ fontSize: 10 }} />
                      <Tooltip />
                      <Legend />
                      <Line
                        type="monotone"
                        dataKey="ph"
                        stroke="#3b82f6"
                        strokeWidth={2}
                        name="pH Level"
                        dot={{ fill: '#3b82f6', strokeWidth: 2, r: 4 }}
                      />
                      <Line
                        type="monotone"
                        dataKey="turbidity"
                        stroke="#06b6d4"
                        strokeWidth={2}
                        name="Turbidity"
                        dot={{ fill: '#06b6d4', strokeWidth: 2, r: 4 }}
                      />
                      <Line
                        type="monotone"
                        dataKey="contamination"
                        stroke="#ef4444"
                        strokeWidth={2}
                        name="Contamination"
                        dot={{ fill: '#ef4444', strokeWidth: 2, r: 4 }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            {/* Environmental Trends */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="flex items-center space-x-2 text-lg">
                  <TrendingUp className="h-5 w-5 text-green-600" />
                  <span>Environmental Trends</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-0">
                <div className="h-48">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={getEnvironmentalTrends()}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="day" tick={{ fontSize: 10 }} />
                      <YAxis yAxisId="temp" orientation="left" tick={{ fontSize: 10 }} />
                      <YAxis yAxisId="rain" orientation="right" tick={{ fontSize: 10 }} />
                      <Tooltip />
                      <Legend />
                      <Line
                        yAxisId="temp"
                        type="monotone"
                        dataKey="temperature"
                        stroke="#f59e0b"
                        strokeWidth={3}
                        name="Temperature (°C)"
                        dot={{ fill: '#f59e0b', strokeWidth: 2, r: 5 }}
                      />
                      <Line
                        yAxisId="rain"
                        type="monotone"
                        dataKey="rainfall"
                        stroke="#10b981"
                        strokeWidth={3}
                        name="Rainfall (mm)"
                        dot={{ fill: '#10b981', strokeWidth: 2, r: 5 }}
                      />
                      <Line
                        yAxisId="temp"
                        type="monotone"
                        dataKey="tempAvg"
                        stroke="#f97316"
                        strokeWidth={2}
                        strokeDasharray="5 5"
                        name="7-Day Avg Temp"
                        dot={false}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            {/* Health System Load */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="flex items-center space-x-2 text-lg">
                  <BarChart3 className="h-5 w-5 text-purple-600" />
                  <span>Health System Load</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-0">
                <div className="h-48">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={getHealthSystemTrends()}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="day" tick={{ fontSize: 10 }} />
                      <YAxis tick={{ fontSize: 10 }} />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="ashaVisits" fill="#3b82f6" name="ASHA Visits" />
                      <Bar dataKey="clinicVisits" fill="#ef4444" name="Clinic Visits" />
                      <Bar dataKey="testsconducted" fill="#10b981" name="Tests Conducted" />
                      <Bar dataKey="orsDispensed" fill="#f59e0b" name="ORS Dispensed" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Model Performance Metrics */}
          <div className="grid md:grid-cols-3 gap-6 mt-6">
            <Card className="p-4">
              <h4 className="font-semibold mb-3 text-center text-green-600">LightGBM Performance</h4>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span>Accuracy:</span>
                  <span className="font-semibold">94.2%</span>
                </div>
                <div className="flex justify-between">
                  <span>Precision:</span>
                  <span className="font-semibold">91.8%</span>
                </div>
                <div className="flex justify-between">
                  <span>F1-Score:</span>
                  <span className="font-semibold">93.1%</span>
                </div>
                <div className="flex justify-between">
                  <span>Data Source:</span>
                  <span className="font-semibold">Historical</span>
                </div>
              </div>
            </Card>

            <Card className="p-4">
              <h4 className="font-semibold mb-3 text-center text-blue-600">Final Model Performance</h4>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span>Accuracy:</span>
                  <span className="font-semibold">89.7%</span>
                </div>
                <div className="flex justify-between">
                  <span>Precision:</span>
                  <span className="font-semibold">87.3%</span>
                </div>
                <div className="flex justify-between">
                  <span>F1-Score:</span>
                  <span className="font-semibold">88.5%</span>
                </div>
                <div className="flex justify-between">
                  <span>Data Source:</span>
                  <span className="font-semibold">Water Quality</span>
                </div>
              </div>
            </Card>

            <Card className="p-4">
              <h4 className="font-semibold mb-3 text-center text-purple-600">Ensemble Performance</h4>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span>Combined Accuracy:</span>
                  <span className="font-semibold">96.1%</span>
                </div>
                <div className="flex justify-between">
                  <span>Confidence:</span>
                  <span className="font-semibold">92.4%</span>
                </div>
                <div className="flex justify-between">
                  <span>Model Weight:</span>
                  <span className="font-semibold">60:40</span>
                </div>
                <div className="flex justify-between">
                  <span>Update Freq:</span>
                  <span className="font-semibold">3s</span>
                </div>
              </div>
            </Card>
          </div>

          {/* Key Metrics Grid */}
          <div className="grid md:grid-cols-4 gap-4 mt-6">
            <Card className="p-4 text-center">
              <div className="text-2xl font-bold text-blue-600">
                {currentReport.historicalData.true_cases}
              </div>
              <div className="text-sm text-gray-600">Active Cases</div>
            </Card>
            <Card className="p-4 text-center">
              <div className="text-2xl font-bold text-orange-600">
                {currentReport.historicalData.contamination_avg.toFixed(2)}
              </div>
              <div className="text-sm text-gray-600">Contamination Level</div>
            </Card>
            <Card className="p-4 text-center">
              <div className="text-2xl font-bold text-green-600">
                {parseFloat(currentReport.waterQualityData['pH']).toFixed(2)}
              </div>
              <div className="text-sm text-gray-600">Water pH</div>
            </Card>
            <Card className="p-4 text-center">
              <div className="text-2xl font-bold text-purple-600">
                {currentReport.historicalData.exposure_score.toFixed(2)}
              </div>
              <div className="text-sm text-gray-600">Exposure Score</div>
            </Card>
          </div>

          {/* Alerts and Recommendations */}
          <div className="grid md:grid-cols-2 gap-6 mt-6">
            <div>
              <h4 className="font-semibold mb-3 flex items-center space-x-2">
                <AlertTriangle className="h-4 w-4 text-orange-500" />
                <span>AI-Generated Alerts</span>
              </h4>
              <div className="space-y-2">
                {currentReport.alerts.length > 0 ? (
                  currentReport.alerts.map((alert, index) => (
                    <div key={index} className="flex items-start space-x-2 text-sm p-2 bg-orange-50 rounded">
                      <AlertTriangle className="h-3 w-3 text-orange-500 mt-0.5 flex-shrink-0" />
                      <span>{alert}</span>
                    </div>
                  ))
                ) : (
                  <div className="flex items-center space-x-2 text-sm text-green-600 p-2 bg-green-50 rounded">
                    <CheckCircle className="h-3 w-3" />
                    <span>No critical alerts detected</span>
                  </div>
                )}
              </div>
            </div>

            <div>
              <h4 className="font-semibold mb-3 flex items-center space-x-2">
                <TrendingUp className="h-4 w-4 text-green-500" />
                <span>ML Recommendations</span>
              </h4>
              <div className="space-y-2">
                {currentReport.recommendations.map((rec, index) => (
                  <div key={index} className="flex items-start space-x-2 text-sm p-2 bg-blue-50 rounded">
                    <div className="h-1.5 w-1.5 bg-accent rounded-full mt-2 flex-shrink-0" />
                    <span>{rec}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Detailed Data Tables */}
          <div className="mt-6 pt-4 border-t">
            <h4 className="font-semibold mb-3">Comprehensive Data Analysis</h4>
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h5 className="font-medium mb-2 text-blue-600">Historical Surveillance Data</h5>
                <div className="space-y-1 text-sm">
                  <div className="flex justify-between">
                    <span>Date:</span>
                    <span className="font-medium">{currentReport.historicalData.date}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Temperature:</span>
                    <span className="font-medium">{currentReport.historicalData.temperature.toFixed(1)}°C</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Rainfall (24h):</span>
                    <span className="font-medium">{currentReport.historicalData.rainfall_1d.toFixed(1)} mm</span>
                  </div>
                  <div className="flex justify-between">
                    <span>ASHA Symptoms:</span>
                    <span className="font-medium">{currentReport.historicalData.asha_symptoms_diarrhea + currentReport.historicalData.asha_symptoms_vomiting}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Clinic Admissions:</span>
                    <span className="font-medium">{currentReport.historicalData.clinic_admissions}</span>
                  </div>
                </div>
              </div>

              <div>
                <h5 className="font-medium mb-2 text-green-600">Water Quality Analysis</h5>
                <div className="space-y-1 text-sm">
                  <div className="flex justify-between">
                    <span>Fluoride:</span>
                    <span className="font-medium">{parseFloat(currentReport.waterQualityData['Fluoride (ppm)']).toFixed(2)} ppm</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Nitrate:</span>
                    <span className="font-medium">{parseFloat(currentReport.waterQualityData['Nitrate (ppm)']).toFixed(2)} ppm</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Total Hardness:</span>
                    <span className="font-medium">{parseFloat(currentReport.waterQualityData['Total hardness (ppm)']).toFixed(1)} ppm</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Chloride:</span>
                    <span className="font-medium">{parseFloat(currentReport.waterQualityData['Chloride (ppm)']).toFixed(1)} ppm</span>
                  </div>
                  <div className="flex justify-between">
                    <span>CHRS Score:</span>
                    <span className="font-medium">{parseFloat(currentReport.waterQualityData['Chemical Health Risk Score (CHRS) ']).toFixed(2)}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Summary Statistics */}
      <div className="grid md:grid-cols-4 gap-4">
        <Card className="gov-card">
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-accent">
              {Object.keys(villageHistoricalData).length}
            </div>
            <div className="text-sm text-muted-foreground">Villages Monitored</div>
          </CardContent>
        </Card>
        <Card className="gov-card">
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-green-600">
              {waterQualityData.length.toLocaleString()}
            </div>
            <div className="text-sm text-muted-foreground">Water Samples</div>
          </CardContent>
        </Card>
        <Card className="gov-card">
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-blue-600">
              92.4%
            </div>
            <div className="text-sm text-muted-foreground">Prediction Accuracy</div>
          </CardContent>
        </Card>
        <Card className="gov-card">
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-purple-600">
              {((currentReport.outbreakProbability) * 100).toFixed(1)}%
            </div>
            <div className="text-sm text-muted-foreground">Current Risk Level</div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default MergedVillageReportsSection;