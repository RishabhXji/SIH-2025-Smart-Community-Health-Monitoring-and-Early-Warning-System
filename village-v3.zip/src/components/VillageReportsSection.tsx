import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { MapPin, Droplets, Activity, TrendingUp, AlertTriangle, CheckCircle, Clock, Map, Navigation } from 'lucide-react';
import { toast } from 'sonner';

interface VillageData {
  'Village name': string;
  'Sample ID': string;
  'Longitude': string;
  'Latitude': string;
  'Fluoride (ppm)': string;
  'Total hardness (ppm)': string;
  'Calcium (ppm)': string;
  'Magnesium (ppm)': string;
  'Chloride (ppm)': string;
  'Alkalinity  (ppm)': string;
  'pH': string;
  'EC (S/cm)': string;
  'Carbonate (ppm)': string;
  'Bicarbonate (ppm)': string;
  'Nitrate (ppm)': string;
  'Sulphate (ppm)': string;
  'Chemical Health Risk Score (CHRS) ': string;
}

interface VillageReport {
  village: VillageData;
  riskLevel: 'low' | 'medium' | 'high' | 'critical';
  statusColor: string;
  overallScore: number;
  alerts: string[];
  recommendations: string[];
}


const VillageReportsSection: React.FC = () => {
  const [currentReport, setCurrentReport] = useState<VillageReport | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [reportIndex, setReportIndex] = useState(0);
  const [villageData, setVillageData] = useState<VillageData[]>([]);
  const [countdown, setCountdown] = useState(3);

  useEffect(() => {
    fetchVillageData();
  }, []);

  useEffect(() => {
    if (villageData.length > 0) {
      generateReport();
      const interval = setInterval(() => {
        setReportIndex(prev => (prev + 1) % villageData.length);
      }, 3000);

      return () => clearInterval(interval);
    }
  }, [villageData, reportIndex]);

  useEffect(() => {
    if (villageData.length > 0) {
      const countdownInterval = setInterval(() => {
        setCountdown(prev => {
          if (prev <= 1) {
            return 3;
          }
          return prev - 1;
        });
      }, 1000);

      return () => clearInterval(countdownInterval);
    }
  }, [villageData]);

  const fetchVillageData = async () => {
    try {
      const response = await fetch('/data/synthetic_water_quality_data.csv');
      const csvText = await response.text();

      const lines = csvText.trim().split('\n');
      const headers = lines[0].split(',');

      const data: VillageData[] = lines.slice(1).map(line => {
        const values = line.split(',');
        const row: any = {};
        headers.forEach((header, index) => {
          row[header] = values[index];
        });
        return row as VillageData;
      });

      setVillageData(data);
      setIsLoading(false);
    } catch (error) {
      console.error('Error loading village data:', error);
      toast.error('Failed to load village data');
      setIsLoading(false);
    }
  };

  const calculateRiskLevel = (village: VillageData): VillageReport['riskLevel'] => {
    const chrs = parseFloat(village['Chemical Health Risk Score (CHRS) '] || '0');
    const ph = parseFloat(village['pH'] || '7');
    const fluoride = parseFloat(village['Fluoride (ppm)'] || '0');
    const nitrate = parseFloat(village['Nitrate (ppm)'] || '0');

    let riskScore = chrs;

    // Add risk factors
    if (ph < 6.5 || ph > 8.5) riskScore += 0.2;
    if (fluoride > 1.5) riskScore += 0.1;
    if (nitrate > 45) riskScore += 0.15;

    if (riskScore >= 0.8) return 'critical';
    if (riskScore >= 0.6) return 'high';
    if (riskScore >= 0.4) return 'medium';
    return 'low';
  };

  const generateAlerts = (village: VillageData): string[] => {
    const alerts: string[] = [];
    const ph = parseFloat(village['pH'] || '7');
    const fluoride = parseFloat(village['Fluoride (ppm)'] || '0');
    const nitrate = parseFloat(village['Nitrate (ppm)'] || '0');
    const chloride = parseFloat(village['Chloride (ppm)'] || '0');

    if (ph < 6.5) alerts.push('pH below safe range (acidic water)');
    if (ph > 8.5) alerts.push('pH above safe range (alkaline water)');
    if (fluoride > 1.5) alerts.push('High fluoride levels detected');
    if (nitrate > 45) alerts.push('Nitrate levels exceed WHO guidelines');
    if (chloride > 1000) alerts.push('High chloride concentration');

    return alerts;
  };

  const generateRecommendations = (village: VillageData): string[] => {
    const recommendations: string[] = [];
    const alerts = generateAlerts(village);

    if (alerts.length === 0) {
      recommendations.push('Water quality within acceptable ranges');
      recommendations.push('Continue regular monitoring');
    } else {
      if (alerts.some(alert => alert.includes('pH'))) {
        recommendations.push('Install pH correction systems');
      }
      if (alerts.some(alert => alert.includes('fluoride'))) {
        recommendations.push('Implement defluoridation treatment');
      }
      if (alerts.some(alert => alert.includes('nitrate'))) {
        recommendations.push('Check for agricultural contamination sources');
      }
      recommendations.push('Increase monitoring frequency');
    }

    return recommendations;
  };

  const generateReport = () => {
    if (villageData.length === 0) return;

    const village = villageData[reportIndex];
    const riskLevel = calculateRiskLevel(village);
    const alerts = generateAlerts(village);
    const recommendations = generateRecommendations(village);

    const statusColors = {
      low: 'text-green-600',
      medium: 'text-yellow-600',
      high: 'text-orange-600',
      critical: 'text-red-600'
    };

    const overallScore = Math.round((1 - parseFloat(village['Chemical Health Risk Score (CHRS) '] || '0')) * 100);

    setCurrentReport({
      village,
      riskLevel,
      statusColor: statusColors[riskLevel],
      overallScore,
      alerts,
      recommendations
    });
  };

  const getRiskBadgeVariant = (risk: VillageReport['riskLevel']) => {
    switch (risk) {
      case 'low': return 'default';
      case 'medium': return 'secondary';
      case 'high': return 'destructive';
      case 'critical': return 'destructive';
      default: return 'default';
    }
  };


  if (isLoading) {
    return (
      <div className="space-y-6">
        <Card className="gov-card">
          <CardContent className="p-6">
            <div className="flex items-center justify-center space-x-2">
              <Activity className="h-5 w-5 animate-spin" />
              <span>Loading village reports...</span>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!currentReport) {
    return null;
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="text-center">
        <h2 className="text-3xl font-bold mb-2">Live Village Water Quality Reports</h2>
        <p className="text-muted-foreground">
          Automated monitoring system • Updates every 3 seconds
        </p>
        <div className="flex items-center justify-center mt-2 space-x-2">
          <Clock className="h-4 w-4" />
          <span className="text-sm">Next update in {countdown}s</span>
        </div>
      </div>

      {/* Main Report Card */}
      <Card className="gov-card border-l-4 border-l-accent">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center space-x-2">
              <MapPin className="h-5 w-5 text-accent" />
              <span>{currentReport.village['Village name']}</span>
            </CardTitle>
            <Badge variant={getRiskBadgeVariant(currentReport.riskLevel)} className="uppercase">
              {currentReport.riskLevel} Risk
            </Badge>
          </div>
          <p className="text-sm text-muted-foreground">
            Sample ID: {currentReport.village['Sample ID']} •
            Location: {parseFloat(currentReport.village['Latitude']).toFixed(3)}°, {parseFloat(currentReport.village['Longitude']).toFixed(3)}°
          </p>
        </CardHeader>
        <CardContent>
          {/* Village Location & Risk Zone */}
          <div className="mb-6">
            <h4 className="font-semibold mb-3 flex items-center space-x-2">
              <Map className="h-4 w-4 text-blue-500" />
              <span>Village Location & Risk Zone</span>
            </h4>
            <Card className="p-4 bg-gradient-to-br from-blue-50 to-indigo-100">
              <div className="grid md:grid-cols-2 gap-6">
                {/* Coordinates & Location */}
                <div>
                  <h5 className="font-semibold mb-3 flex items-center space-x-2">
                    <Navigation className="h-4 w-4 text-green-600" />
                    <span>GPS Coordinates</span>
                  </h5>
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Latitude:</span>
                      <Badge variant="outline" className="font-mono">
                        {parseFloat(currentReport.village['Latitude']).toFixed(6)}°N
                      </Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Longitude:</span>
                      <Badge variant="outline" className="font-mono">
                        {parseFloat(currentReport.village['Longitude']).toFixed(6)}°E
                      </Badge>
                    </div>
                    <div className="flex justify-between items-center pt-2 border-t">
                      <span className="text-sm text-gray-600">Region:</span>
                      <span className="text-sm font-medium">
                        {Math.abs(parseFloat(currentReport.village['Latitude'])) > 30 ? 'Northern India' :
                         Math.abs(parseFloat(currentReport.village['Latitude'])) > 15 ? 'Central India' : 'Southern India'}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Risk Zone Visualization */}
                <div>
                  <h5 className="font-semibold mb-3 flex items-center space-x-2">
                    <AlertTriangle className={`h-4 w-4 ${
                      currentReport.riskLevel === 'critical' ? 'text-red-500' :
                      currentReport.riskLevel === 'high' ? 'text-orange-500' :
                      currentReport.riskLevel === 'medium' ? 'text-yellow-500' : 'text-green-500'
                    }`} />
                    <span>Risk Assessment</span>
                  </h5>

                  {/* Visual Risk Indicator */}
                  <div className="relative">
                    <div className="w-full h-24 bg-gray-200 rounded-lg relative overflow-hidden">
                      {/* Risk Zone Animation */}
                      <div
                        className={`absolute inset-0 opacity-30 animate-pulse ${
                          currentReport.riskLevel === 'critical' ? 'bg-red-500' :
                          currentReport.riskLevel === 'high' ? 'bg-orange-500' :
                          currentReport.riskLevel === 'medium' ? 'bg-yellow-500' : 'bg-green-500'
                        }`}
                      />

                      {/* Village Marker */}
                      <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
                        <div className={`w-8 h-8 rounded-full border-4 border-white shadow-lg ${
                          currentReport.riskLevel === 'critical' ? 'bg-red-500' :
                          currentReport.riskLevel === 'high' ? 'bg-orange-500' :
                          currentReport.riskLevel === 'medium' ? 'bg-yellow-500' : 'bg-green-500'
                        }`}>
                          <div className="w-full h-full flex items-center justify-center">
                            <MapPin className="h-4 w-4 text-white" />
                          </div>
                        </div>
                      </div>

                      {/* Ripple Effect */}
                      <div className={`absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-16 h-16 rounded-full border-2 animate-ping ${
                        currentReport.riskLevel === 'critical' ? 'border-red-400' :
                        currentReport.riskLevel === 'high' ? 'border-orange-400' :
                        currentReport.riskLevel === 'medium' ? 'border-yellow-400' : 'border-green-400'
                      }`} />
                    </div>

                    {/* Risk Level Badge */}
                    <div className="mt-3 text-center">
                      <Badge variant={getRiskBadgeVariant(currentReport.riskLevel)} className="text-xs">
                        {currentReport.riskLevel.toUpperCase()} RISK ZONE
                      </Badge>
                      <p className="text-xs text-gray-500 mt-1">
                        Health Score: {currentReport.overallScore}%
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Quick Actions */}
              <div className="mt-4 pt-4 border-t border-blue-200">
                <div className="flex items-center justify-between text-xs">
                  <button className="flex items-center space-x-1 text-blue-600 hover:text-blue-800 transition-colors">
                    <Map className="h-3 w-3" />
                    <span>View in Google Maps</span>
                  </button>
                  <button className="flex items-center space-x-1 text-blue-600 hover:text-blue-800 transition-colors">
                    <Navigation className="h-3 w-3" />
                    <span>Get Directions</span>
                  </button>
                  <span className="text-gray-500">Updated: {countdown}s</span>
                </div>
              </div>
            </Card>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {/* Water Quality Metrics */}
            <div>
              <h4 className="font-semibold mb-3 flex items-center space-x-2">
                <Droplets className="h-4 w-4 text-blue-500" />
                <span>Key Metrics</span>
              </h4>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span>pH Level:</span>
                  <span className="font-medium">{currentReport.village['pH']}</span>
                </div>
                <div className="flex justify-between">
                  <span>Fluoride:</span>
                  <span className="font-medium">{currentReport.village['Fluoride (ppm)']} ppm</span>
                </div>
                <div className="flex justify-between">
                  <span>Nitrate:</span>
                  <span className="font-medium">{currentReport.village['Nitrate (ppm)']} ppm</span>
                </div>
                <div className="flex justify-between">
                  <span>Total Hardness:</span>
                  <span className="font-medium">{currentReport.village['Total hardness (ppm)']} ppm</span>
                </div>
                <div className="flex justify-between border-t pt-2 mt-2">
                  <span>Overall Score:</span>
                  <span className={`font-bold ${currentReport.statusColor}`}>
                    {currentReport.overallScore}%
                  </span>
                </div>
              </div>
            </div>

            {/* Alerts */}
            <div>
              <h4 className="font-semibold mb-3 flex items-center space-x-2">
                <AlertTriangle className="h-4 w-4 text-orange-500" />
                <span>Alerts</span>
              </h4>
              <div className="space-y-2">
                {currentReport.alerts.length > 0 ? (
                  currentReport.alerts.map((alert, index) => (
                    <div key={index} className="flex items-start space-x-2 text-sm">
                      <AlertTriangle className="h-3 w-3 text-orange-500 mt-0.5 flex-shrink-0" />
                      <span>{alert}</span>
                    </div>
                  ))
                ) : (
                  <div className="flex items-center space-x-2 text-sm text-green-600">
                    <CheckCircle className="h-3 w-3" />
                    <span>No active alerts</span>
                  </div>
                )}
              </div>
            </div>

            {/* Recommendations */}
            <div>
              <h4 className="font-semibold mb-3 flex items-center space-x-2">
                <TrendingUp className="h-4 w-4 text-green-500" />
                <span>Recommendations</span>
              </h4>
              <div className="space-y-2">
                {currentReport.recommendations.map((rec, index) => (
                  <div key={index} className="flex items-start space-x-2 text-sm">
                    <div className="h-1.5 w-1.5 bg-accent rounded-full mt-2 flex-shrink-0" />
                    <span>{rec}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Additional Details */}
          <div className="mt-6 pt-4 border-t">
            <h4 className="font-semibold mb-2">Detailed Analysis</h4>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
              <div>
                <span className="text-muted-foreground">Calcium:</span>
                <div className="font-medium">{currentReport.village['Calcium (ppm)']} ppm</div>
              </div>
              <div>
                <span className="text-muted-foreground">Magnesium:</span>
                <div className="font-medium">{currentReport.village['Magnesium (ppm)']} ppm</div>
              </div>
              <div>
                <span className="text-muted-foreground">Chloride:</span>
                <div className="font-medium">{currentReport.village['Chloride (ppm)']} ppm</div>
              </div>
              <div>
                <span className="text-muted-foreground">Sulphate:</span>
                <div className="font-medium">{currentReport.village['Sulphate (ppm)']} ppm</div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Stats Summary */}
      <div className="grid md:grid-cols-4 gap-4">
        <Card className="gov-card">
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-accent">
              {villageData.length.toLocaleString()}
            </div>
            <div className="text-sm text-muted-foreground">Total Villages Monitored</div>
          </CardContent>
        </Card>
        <Card className="gov-card">
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-green-600">
              {villageData.filter(v => calculateRiskLevel(v) === 'low').length}
            </div>
            <div className="text-sm text-muted-foreground">Low Risk Villages</div>
          </CardContent>
        </Card>
        <Card className="gov-card">
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-orange-600">
              {villageData.filter(v => ['medium', 'high'].includes(calculateRiskLevel(v))).length}
            </div>
            <div className="text-sm text-muted-foreground">Medium/High Risk</div>
          </CardContent>
        </Card>
        <Card className="gov-card">
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-red-600">
              {villageData.filter(v => calculateRiskLevel(v) === 'critical').length}
            </div>
            <div className="text-sm text-muted-foreground">Critical Risk Villages</div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default VillageReportsSection;