import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  Brain,
  Calendar as CalendarIcon,
  MapPin,
  TrendingUp,
  Droplets,
  Thermometer,
  AlertTriangle,
  Activity,
  Gauge,
  Loader2
} from 'lucide-react';
import { format } from 'date-fns';
// Removed Supabase dependency - using direct API calls
import { useToast } from '@/hooks/use-toast';
import {
  LineChart,
  Line,
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from 'recharts';

interface PredictionData {
  date: string;
  village: string;
  outbreak_probability: number;
  risk_level: string;
  top_contributing_factors: Array<{
    factor: string;
    contribution: number;
    percentage: string;
  }>;
  feature_importance: Record<string, number>;
  confidence_score: number;
  model_used: string;
  data_sources: string;
}

interface ModelPrediction {
  outbreak_probability: number;
  risk_level: string;
  model_name: string;
}

interface CombinedPredictions {
  date: string;
  data_points_analyzed: number;
  lgbm_model: ModelPrediction;
  final_model: ModelPrediction;
  combined: {
    outbreak_probability: number;
    risk_level: string;
    confidence_score: number;
  };
  risk_factors: Array<{
    factor: string;
    value: number;
    impact: string;
  }>;
  environmental_data: {
    temperature: number;
    rainfall_1d: number;
    contamination_avg: number;
    water_ph_avg: number;
    water_turbidity_avg: number;
    true_cases: number;
    reported_cases: number;
  };
}

const MLPredictionSection = () => {
  const { toast } = useToast();
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [predictions, setPredictions] = useState<CombinedPredictions | null>(null);
  const [loading, setLoading] = useState(false);

  const runPrediction = async () => {
    if (!selectedDate) {
      toast({
        title: "Missing Information",
        description: "Please select a date for prediction",
        variant: "destructive"
      });
      return;
    }

    setLoading(true);
    console.log('Running ML prediction for date:', format(selectedDate, 'yyyy-MM-dd'));

    try {
      const response = await fetch('http://localhost:5000/api/predict', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          date: format(selectedDate, 'yyyy-MM-dd')
        })
      });

      const data = await response.json();
      console.log('ML prediction response:', data);

      if (!response.ok) {
        throw new Error(data.error || `HTTP error! status: ${response.status}`);
      }

      if (data.success) {
        setPredictions(data.predictions);
        toast({
          title: "Prediction Complete",
          description: `Combined Risk: ${data.predictions.combined.risk_level.toUpperCase()} - ${(data.predictions.combined.outbreak_probability * 100).toFixed(1)}%`,
          variant: data.predictions.combined.risk_level === 'high' || data.predictions.combined.risk_level === 'critical' ? "destructive" : "default"
        });
      } else {
        throw new Error(data.error || 'Failed to run prediction');
      }
    } catch (error) {
      console.error('Error running prediction:', error);
      toast({
        title: "Prediction Failed",
        description: error instanceof Error ? error.message : "Failed to run prediction. Please ensure the Python backend is running on http://localhost:5000",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const getRiskColor = (riskLevel: string) => {
    switch (riskLevel) {
      case 'critical': return 'bg-red-500 text-white';
      case 'high': return 'bg-red-400 text-white';
      case 'medium': return 'bg-yellow-500 text-white';
      case 'low': return 'bg-green-500 text-white';
      default: return 'bg-gray-500 text-white';
    }
  };

  const getRiskDescription = (probability: number) => {
    if (probability > 0.7) return 'Critical - Immediate Action Required';
    if (probability > 0.5) return 'High Risk - Enhanced Monitoring';
    if (probability >= 0.3) return 'Medium Risk - Close Monitoring';
    return 'Low Risk - Continue Regular Monitoring';
  };

  const getGaugeColor = (probability: number) => {
    if (probability > 0.7) return '#dc2626'; // red-600
    if (probability > 0.5) return '#ea580c'; // orange-600
    if (probability >= 0.3) return '#d97706'; // amber-600
    return '#16a34a'; // green-600
  };

  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8'];

  // Sample chart data for demonstration
  const temperatureData = [
    { date: '01/27', temperature: 18.5, rainfall: 2.1 },
    { date: '01/28', temperature: 19.2, rainfall: 0.8 },
    { date: '01/29', temperature: 20.1, rainfall: 3.2 },
    { date: '01/30', temperature: 19.8, rainfall: 1.5 },
    { date: '01/31', temperature: 18.9, rainfall: 0.3 },
    { date: '02/01', temperature: 17.6, rainfall: 4.1 },
    { date: '02/02', temperature: 16.8, rainfall: 2.7 },
  ];

  const waterQualityData = [
    { date: '01/27', ph: 7.2, turbidity: 1.8, contamination: 0.3 },
    { date: '01/28', ph: 7.0, turbidity: 2.1, contamination: 0.5 },
    { date: '01/29', ph: 6.9, turbidity: 2.8, contamination: 0.8 },
    { date: '01/30', ph: 7.1, turbidity: 2.3, contamination: 0.6 },
    { date: '01/31', ph: 7.3, turbidity: 1.9, contamination: 0.4 },
    { date: '02/01', ph: 6.8, turbidity: 3.2, contamination: 1.2 },
    { date: '02/02', ph: 7.0, turbidity: 2.5, contamination: 0.9 },
  ];

  const casesData = [
    { date: '01/27', reported: 8, confirmed: 5 },
    { date: '01/28', reported: 12, confirmed: 8 },
    { date: '01/29', reported: 15, confirmed: 11 },
    { date: '01/30', reported: 18, confirmed: 13 },
    { date: '01/31', reported: 14, confirmed: 10 },
    { date: '02/01', reported: 22, confirmed: 16 },
    { date: '02/02', reported: 19, confirmed: 14 },
  ];

  return (
    <section className="container mx-auto px-4 py-16">
      <div className="text-center mb-12">
        <Badge variant="secondary" className="mb-4 px-4 py-2">
          <Brain className="h-4 w-4 mr-2" />
          AI-Powered Analytics
        </Badge>
        <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
          Water Quality & Disease Outbreak Prediction
        </h2>
        <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
          Select a village and date to generate comprehensive outbreak probability analysis using machine learning models trained on historical health surveillance data.
        </p>
      </div>

      {/* Prediction Controls */}
      <Card className="gov-card mb-8">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Gauge className="h-5 w-5 text-primary" />
            <span>ML Prediction Configuration</span>
          </CardTitle>
          <CardDescription>
            Select a village and date to analyze outbreak risk using our trained LightGBM model
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-6 mb-6">
            {/* Date Selection */}
            <div className="space-y-2">
              <label className="text-sm font-medium">Select Date for Analysis</label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className="w-full justify-start text-left font-normal"
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {selectedDate ? format(selectedDate, 'PPP') : 'Pick a date'}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={selectedDate}
                    onSelect={setSelectedDate}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>

            {/* Prediction Button */}
            <div className="space-y-2">
              <label className="text-sm font-medium">Run Both Models</label>
              <Button
                onClick={runPrediction}
                disabled={!selectedDate || loading}
                className="w-full btn-government"
                size="default"
              >
                {loading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Processing Both Models...
                  </>
                ) : (
                  <>
                    <Brain className="mr-2 h-4 w-4" />
                    Generate Dual Model Prediction
                  </>
                )}
              </Button>
            </div>
          </div>

          {selectedDate && (
            <div className="text-sm text-muted-foreground p-4 bg-muted rounded-lg">
              <p><strong>Selected Date:</strong> {format(selectedDate, 'PPP')}</p>
              <p><strong>Data Sources:</strong> All village CSV files (combined analysis)</p>
              <p><strong>Models:</strong> Both LightGBM and Final models from model/ directory</p>
              <p><strong>Analysis:</strong> Multi-village data within ±7 days of selected date</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Prediction Results */}
      {predictions && (
        <div className="space-y-6">
          {/* Model Comparison Results */}
          <div className="grid lg:grid-cols-3 gap-6">
            {/* LightGBM Model */}
            <Card className="gov-card-elevated">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Brain className="h-5 w-5 text-primary" />
                  <span>LightGBM Model</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <div className="mb-4">
                  <div
                    className="text-5xl font-bold mb-2"
                    style={{color: getGaugeColor(predictions.lgbm_model.outbreak_probability)}}
                  >
                    {(predictions.lgbm_model.outbreak_probability * 100).toFixed(1)}%
                  </div>
                  <Badge className={getRiskColor(predictions.lgbm_model.risk_level)} variant="outline">
                    {predictions.lgbm_model.risk_level.toUpperCase()}
                  </Badge>
                  <p className="text-xs text-muted-foreground mt-2">
                    {predictions.lgbm_model.model_name}
                  </p>
                </div>
              </CardContent>
            </Card>

            {/* Final Model */}
            <Card className="gov-card-elevated">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Gauge className="h-5 w-5 text-secondary" />
                  <span>Final Model</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <div className="mb-4">
                  <div
                    className="text-5xl font-bold mb-2"
                    style={{color: getGaugeColor(predictions.final_model.outbreak_probability)}}
                  >
                    {(predictions.final_model.outbreak_probability * 100).toFixed(1)}%
                  </div>
                  <Badge className={getRiskColor(predictions.final_model.risk_level)} variant="outline">
                    {predictions.final_model.risk_level.toUpperCase()}
                  </Badge>
                  <p className="text-xs text-muted-foreground mt-2">
                    {predictions.final_model.model_name}
                  </p>
                </div>
              </CardContent>
            </Card>

            {/* Combined Result */}
            <Card className="gov-card-elevated border-2 border-primary">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Activity className="h-5 w-5 text-accent" />
                  <span>Combined Result</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <div className="mb-4">
                  <div
                    className="text-6xl font-bold mb-2"
                    style={{color: getGaugeColor(predictions.combined.outbreak_probability)}}
                  >
                    {(predictions.combined.outbreak_probability * 100).toFixed(1)}%
                  </div>
                  <Badge className={getRiskColor(predictions.combined.risk_level)} variant="outline">
                    {predictions.combined.risk_level.toUpperCase()}
                  </Badge>
                  <p className="text-sm text-muted-foreground mt-2">
                    {getRiskDescription(predictions.combined.outbreak_probability)}
                  </p>
                </div>
                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <span>Confidence: {(predictions.combined.confidence_score * 100).toFixed(1)}%</span>
                  <span>Data points: {predictions.data_points_analyzed}</span>
                </div>
              </CardContent>
            </Card>

          </div>

          {/* Risk Factors and Actions */}
          <div className="grid lg:grid-cols-2 gap-6">
            {/* Risk Factors */}
            <Card className="gov-card">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <TrendingUp className="h-5 w-5 text-accent" />
                  <span>Key Risk Factors</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {predictions.risk_factors?.length > 0 ? (
                    predictions.risk_factors.map((factor, index) => (
                      <div key={index} className="flex items-center justify-between p-3 bg-muted rounded-lg">
                        <div>
                          <span className="text-sm font-medium">{factor.factor}</span>
                          <p className="text-xs text-muted-foreground">Value: {factor.value.toFixed(2)}</p>
                        </div>
                        <Badge variant={factor.impact === 'High' ? 'destructive' : 'secondary'}>
                          {factor.impact}
                        </Badge>
                      </div>
                    ))
                  ) : (
                    <p className="text-sm text-muted-foreground">No significant risk factors detected</p>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Action Items */}
            <Card className="gov-card">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <AlertTriangle className="h-5 w-5 text-warning" />
                  <span>Recommended Actions</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {predictions.combined.outbreak_probability > 0.7 ? (
                    <ul className="text-xs space-y-2 text-destructive">
                      <li>🚨 Deploy Rapid Response Team immediately</li>
                      <li>💧 Increase water quality testing frequency</li>
                      <li>📢 Alert all community health workers</li>
                      <li>📦 Prepare emergency medical supplies</li>
                      <li>📊 Activate enhanced surveillance protocols</li>
                    </ul>
                  ) : predictions.combined.outbreak_probability > 0.5 ? (
                    <ul className="text-xs space-y-2 text-warning">
                      <li>⚠️ Activate enhanced monitoring</li>
                      <li>🔍 Inspect water sources and quality</li>
                      <li>📋 Review ASHA worker reports</li>
                      <li>🏥 Alert nearby healthcare facilities</li>
                      <li>📈 Monitor symptom patterns closely</li>
                    </ul>
                  ) : predictions.combined.outbreak_probability > 0.3 ? (
                    <ul className="text-xs space-y-2 text-warning">
                      <li>👀 Maintain vigilant monitoring</li>
                      <li>🔄 Continue regular data collection</li>
                      <li>📊 Review trends weekly</li>
                      <li>💡 Implement preventive measures</li>
                    </ul>
                  ) : (
                    <ul className="text-xs space-y-2 text-success">
                      <li>✅ Continue routine monitoring</li>
                      <li>🛡️ Maintain preventive measures</li>
                      <li>📊 Regular data collection sufficient</li>
                      <li>📅 Schedule next assessment</li>
                    </ul>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Environmental Data Display */}
          <Card className="gov-card">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Droplets className="h-5 w-5 text-primary" />
                <span>Environmental Data Summary</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-4 gap-4">
                <div className="text-center p-4 bg-muted rounded-lg">
                  <div className="text-2xl font-bold text-primary">{predictions.environmental_data.temperature.toFixed(1)}°C</div>
                  <div className="text-xs text-muted-foreground">Temperature</div>
                </div>
                <div className="text-center p-4 bg-muted rounded-lg">
                  <div className="text-2xl font-bold text-primary">{predictions.environmental_data.rainfall_1d.toFixed(1)}mm</div>
                  <div className="text-xs text-muted-foreground">Daily Rainfall</div>
                </div>
                <div className="text-center p-4 bg-muted rounded-lg">
                  <div className="text-2xl font-bold text-primary">{predictions.environmental_data.water_ph_avg.toFixed(1)}</div>
                  <div className="text-xs text-muted-foreground">Water pH</div>
                </div>
                <div className="text-center p-4 bg-muted rounded-lg">
                  <div className="text-2xl font-bold text-primary">{predictions.environmental_data.contamination_avg.toFixed(2)}</div>
                  <div className="text-xs text-muted-foreground">Contamination</div>
                </div>
              </div>
              <div className="grid md:grid-cols-3 gap-4 mt-4">
                <div className="text-center p-4 bg-muted rounded-lg">
                  <div className="text-lg font-bold text-secondary">{predictions.environmental_data.true_cases.toFixed(0)}</div>
                  <div className="text-xs text-muted-foreground">Confirmed Cases</div>
                </div>
                <div className="text-center p-4 bg-muted rounded-lg">
                  <div className="text-lg font-bold text-secondary">{predictions.environmental_data.reported_cases.toFixed(0)}</div>
                  <div className="text-xs text-muted-foreground">Reported Cases</div>
                </div>
                <div className="text-center p-4 bg-muted rounded-lg">
                  <div className="text-lg font-bold text-secondary">{predictions.environmental_data.water_turbidity_avg.toFixed(2)}</div>
                  <div className="text-xs text-muted-foreground">Turbidity (NTU)</div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Data Visualization Charts */}
          <div className="grid lg:grid-cols-2 gap-6">
            {/* Temperature & Rainfall Trends */}
            <Card className="gov-card">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Thermometer className="h-5 w-5 text-destructive" />
                  <span>Environmental Trends (7 days)</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={temperatureData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis yAxisId="temp" orientation="left" />
                    <YAxis yAxisId="rain" orientation="right" />
                    <Tooltip />
                    <Line
                      yAxisId="temp"
                      type="monotone"
                      dataKey="temperature"
                      stroke="#dc2626"
                      strokeWidth={2}
                      name="Temperature (°C)"
                    />
                    <Line
                      yAxisId="rain"
                      type="monotone"
                      dataKey="rainfall"
                      stroke="#2563eb"
                      strokeWidth={2}
                      name="Rainfall (mm)"
                    />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Water Quality Indicators */}
            <Card className="gov-card">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Droplets className="h-5 w-5 text-primary" />
                  <span>Water Quality Trends</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={waterQualityData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis yAxisId="ph" orientation="left" domain={[6, 8]} />
                    <YAxis yAxisId="other" orientation="right" />
                    <Tooltip />
                    <Line
                      yAxisId="ph"
                      type="monotone"
                      dataKey="ph"
                      stroke="#16a34a"
                      strokeWidth={2}
                      name="pH Level"
                    />
                    <Line
                      yAxisId="other"
                      type="monotone"
                      dataKey="turbidity"
                      stroke="#eab308"
                      strokeWidth={2}
                      name="Turbidity (NTU)"
                    />
                    <Line
                      yAxisId="other"
                      type="monotone"
                      dataKey="contamination"
                      stroke="#dc2626"
                      strokeWidth={2}
                      name="Contamination Level"
                    />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          {/* Case Reports Trend */}
          <Card className="gov-card">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Activity className="h-5 w-5 text-secondary" />
                <span>Disease Cases Trend (7 days)</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <AreaChart data={casesData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis />
                  <Tooltip />
                  <Area
                    type="monotone"
                    dataKey="reported"
                    stackId="1"
                    stroke="#2563eb"
                    fill="#2563eb"
                    fillOpacity={0.3}
                    name="Reported Cases"
                  />
                  <Area
                    type="monotone"
                    dataKey="confirmed"
                    stackId="2"
                    stroke="#dc2626"
                    fill="#dc2626"
                    fillOpacity={0.3}
                    name="Confirmed Cases"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Model Information */}
          <Card className="gov-card">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Brain className="h-5 w-5 text-accent" />
                <span>Model Information</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-3 gap-6 text-sm">
                <div>
                  <h4 className="font-semibold mb-2">Model Details</h4>
                  <p className="text-muted-foreground">Dual Model Analysis (LightGBM + Final)</p>
                  <p className="text-muted-foreground">Confidence: {(predictions.combined.confidence_score * 100).toFixed(1)}%</p>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Data Sources</h4>
                  <p className="text-muted-foreground">{predictions.data_points_analyzed} data points analyzed</p>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Analysis Date</h4>
                  <p className="text-muted-foreground">{format(new Date(), 'PPP')}</p>
                  <p className="text-muted-foreground">Target: {format(selectedDate, 'PPP')}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* No Prediction State */}
      {!predictions && !loading && (
        <Card className="gov-card">
          <CardContent className="flex flex-col items-center justify-center py-16">
            <Brain className="h-16 w-16 text-primary mb-4 pulse-government" />
            <h3 className="text-xl font-semibold mb-2">Dual Model Prediction System Ready</h3>
            <p className="text-muted-foreground text-center max-w-md mb-4">
              Select a date above and click "Generate Dual Model Prediction" to run both LightGBM and Final models simultaneously on combined village data.
            </p>
            <div className="grid grid-cols-2 gap-4 text-sm text-muted-foreground">
              <div className="text-center p-4 bg-muted rounded-lg">
                <Brain className="h-8 w-8 mx-auto mb-2 text-primary" />
                <strong>Models:</strong> LightGBM + Final
              </div>
              <div className="text-center p-4 bg-muted rounded-lg">
                <CalendarIcon className="h-8 w-8 mx-auto mb-2 text-secondary" />
                <strong>Data:</strong> All villages combined
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </section>
  );
};

export default MLPredictionSection;