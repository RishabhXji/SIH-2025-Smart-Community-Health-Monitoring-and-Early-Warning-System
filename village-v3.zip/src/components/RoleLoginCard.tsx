import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { LucideIcon } from 'lucide-react';

interface RoleLoginCardProps {
  title: string;
  description: string;
  icon: LucideIcon;
  role: string;
  features: string[];
  color: 'primary' | 'secondary' | 'accent' | 'success';
}

const RoleLoginCard: React.FC<RoleLoginCardProps> = ({
  title,
  description,
  icon: Icon,
  role,
  features,
  color
}) => {
  const navigate = useNavigate();

  const handleLogin = () => {
    navigate(`/login/${role}`);
  };

  const colorClasses = {
    primary: 'border-primary/20 hover:border-primary/40',
    secondary: 'border-secondary/20 hover:border-secondary/40',
    accent: 'border-accent/20 hover:border-accent/40',
    success: 'border-success/20 hover:border-success/40'
  };

  const iconColorClasses = {
    primary: 'text-primary',
    secondary: 'text-secondary',
    accent: 'text-accent',
    success: 'text-success'
  };

  return (
    <Card className={`gov-card-elevated scale-hover transition-all duration-300 ${colorClasses[color]}`}>
      <CardHeader className="text-center pb-4">
        <div className={`mx-auto mb-4 p-4 rounded-full bg-${color}-light`}>
          <Icon className={`h-8 w-8 ${iconColorClasses[color]}`} />
        </div>
        <CardTitle className="text-xl font-bold text-foreground">{title}</CardTitle>
        <CardDescription className="text-muted-foreground">{description}</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <h4 className="font-semibold text-sm text-muted-foreground uppercase tracking-wide">
            Key Features:
          </h4>
          <ul className="space-y-1">
            {features.map((feature, index) => (
              <li key={index} className="text-sm text-foreground flex items-start">
                <span className={`mr-2 mt-1 h-1.5 w-1.5 rounded-full bg-${color} flex-shrink-0`} />
                {feature}
              </li>
            ))}
          </ul>
        </div>
        <Button 
          onClick={handleLogin}
          className={`w-full btn-${color === 'primary' ? 'government' : color === 'secondary' ? 'secondary-gov' : 'government'}`}
        >
          Access Dashboard
        </Button>
      </CardContent>
    </Card>
  );
};

export default RoleLoginCard;