import React, { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import heroContaminated from '@/assets/hero-contaminated-water.jpg';
import heroPrevention from '@/assets/hero-disease-prevention.jpg';
import heroSanitation from '@/assets/hero-sanitation-awareness.jpg';
import heroSurveillance from '@/assets/hero-health-surveillance.jpg';

const slides = [
  {
    image: heroContaminated,
    title: "Real-time Water Quality Monitoring",
    subtitle: "Detecting contamination sources before they cause outbreaks",
    overlay: "hero-overlay"
  },
  {
    image: heroPrevention,
    title: "Community Health Education",
    subtitle: "Empowering ASHA workers and communities with prevention knowledge",
    overlay: "hero-overlay"
  },
  {
    image: heroSanitation,
    title: "Sanitation Infrastructure Success",
    subtitle: "Building healthier communities through improved sanitation",
    overlay: "hero-overlay"
  },
  {
    image: heroSurveillance,
    title: "Smart Health Surveillance",
    subtitle: "AI-powered early warning systems for waterborne diseases",
    overlay: "hero-overlay"
  }
];

const HeroSlider = () => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isAutoPlaying, setIsAutoPlaying] = useState(true);

  useEffect(() => {
    if (!isAutoPlaying) return;
    
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length);
    }, 5000);

    return () => clearInterval(interval);
  }, [isAutoPlaying]);

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % slides.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + slides.length) % slides.length);
  };

  const goToSlide = (index: number) => {
    setCurrentSlide(index);
  };

  return (
    <div 
      className="relative h-[600px] w-full overflow-hidden rounded-lg shadow-government"
      onMouseEnter={() => setIsAutoPlaying(false)}
      onMouseLeave={() => setIsAutoPlaying(true)}
    >
      {/* Slides */}
      {slides.map((slide, index) => (
        <div
          key={index}
          className={`absolute inset-0 transition-opacity duration-1000 ${
            index === currentSlide ? 'opacity-100 z-10' : 'opacity-0 z-0'
          }`}
        >
          <div
            className="h-full w-full bg-cover bg-center bg-no-repeat"
            style={{ backgroundImage: `url(${slide.image})` }}
          >
            <div className={`${slide.overlay} h-full w-full flex items-center justify-center`}>
              <div className="text-center text-white px-4 max-w-4xl">
                <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-4 slide-up">
                  {slide.title}
                </h2>
                <p className="text-xl md:text-2xl lg:text-3xl font-light fade-in-delay">
                  {slide.subtitle}
                </p>
              </div>
            </div>
          </div>
        </div>
      ))}

      {/* Navigation Arrows */}
      <Button
        variant="outline"
        size="icon"
        className="absolute left-4 top-1/2 -translate-y-1/2 z-20 bg-white/20 border-white/30 text-white hover:bg-white/30 backdrop-blur-sm"
        onClick={prevSlide}
      >
        <ChevronLeft className="h-6 w-6" />
      </Button>
      
      <Button
        variant="outline"
        size="icon"
        className="absolute right-4 top-1/2 -translate-y-1/2 z-20 bg-white/20 border-white/30 text-white hover:bg-white/30 backdrop-blur-sm"
        onClick={nextSlide}
      >
        <ChevronRight className="h-6 w-6" />
      </Button>

      {/* Slide Indicators */}
      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 z-20 flex space-x-2">
        {slides.map((_, index) => (
          <button
            key={index}
            className={`w-3 h-3 rounded-full transition-all duration-300 ${
              index === currentSlide 
                ? 'bg-white scale-125' 
                : 'bg-white/50 hover:bg-white/75'
            }`}
            onClick={() => goToSlide(index)}
          />
        ))}
      </div>
    </div>
  );
};

export default HeroSlider;